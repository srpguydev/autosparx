import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MoreVertical, Plus, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ChannelPermission } from "@shared/schema";

export default function ChannelPermissionsCard() {
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: permissions = [], isLoading } = useQuery<ChannelPermission[]>({
    queryKey: ['/api/channel-permissions', guildId],
  });
  
  // Group permissions by channel
  const channelGroups = permissions.reduce((acc, perm) => {
    if (!acc[perm.channelId]) {
      acc[perm.channelId] = {
        id: perm.channelId,
        name: perm.channelName,
        permissions: []
      };
    }
    acc[perm.channelId].permissions.push(perm);
    return acc;
  }, {} as Record<string, { id: string; name: string; permissions: ChannelPermission[] }>);
  
  const channels = Object.values(channelGroups);

  return (
    <Card className="bg-[#2C2F33] text-white overflow-hidden">
      <CardHeader className="px-5 py-4 bg-[#23272A] flex flex-row justify-between items-center">
        <CardTitle className="text-lg font-medium">Channel Permissions</CardTitle>
        <Button variant="ghost" size="icon" className="text-[#99AAB5] hover:text-white">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </CardHeader>
      
      <div className="px-5 py-3 border-b border-gray-700">
        <p className="text-sm text-[#99AAB5]">
          Manage channel permissions based on user roles
        </p>
      </div>
      
      <CardContent className="px-5 py-3">
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#5865F2]"></div>
          </div>
        ) : channels.length === 0 ? (
          <div className="text-center py-6 text-[#99AAB5]">
            <p>No channel permissions configured yet.</p>
          </div>
        ) : (
          channels.map((channel) => (
            <div key={channel.id} className="flex items-center justify-between py-2">
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#99AAB5]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                </svg>
                <span className="ml-2 text-sm font-medium text-white">{channel.name}</span>
              </div>
              <div className="flex items-center">
                <span className="text-xs px-2 py-1 rounded-full bg-[#5865F2] text-white">
                  {channel.permissions.length} roles
                </span>
                <Button variant="ghost" size="icon" className="ml-2 text-[#99AAB5] hover:text-white">
                  <Edit2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))
        )}
      </CardContent>
      
      <CardFooter className="px-5 py-4 bg-[#23272A]">
        <Button 
          className="w-full justify-center bg-[#5865F2] hover:bg-opacity-90 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          Configure Channel Permissions
        </Button>
      </CardFooter>
    </Card>
  );
}
