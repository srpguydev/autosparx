import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Cog, Check, X } from "lucide-react";

export default function AutoChannelPermissionsCard() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [autoChannelPermissionsEnabled, setAutoChannelPermissionsEnabled] = useState(true);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  // Configuration for automatic channel permissions
  const [config, setConfig] = useState({
    premiumKeywords: ['premium', 'vip', 'exclusive'],
    premiumRoles: ['premium', 'vip', 'admin', 'staff', 'mod'],
    staffKeywords: ['staff', 'mod', 'admin', 'team'],
    staffRoles: ['staff', 'mod', 'admin']
  });
  
  const setupChannelPermissionsMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', `/api/setup-channel-permissions/${guildId}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/channel-permissions', guildId] });
      toast({
        title: "Permissions configured",
        description: "Channel permissions have been configured based on channel names.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to configure permissions",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const saveConfigMutation = useMutation({
    mutationFn: async (data: any) => {
      // This would be a real API endpoint in production
      // For now, we'll just simulate a successful API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true };
    },
    onSuccess: () => {
      setIsDialogOpen(false);
      toast({
        title: "Configuration saved",
        description: "Automatic channel permissions configuration has been updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to save configuration",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleOpenDialog = () => {
    setIsDialogOpen(true);
  };
  
  const handleSaveConfig = () => {
    saveConfigMutation.mutate(config);
  };
  
  const updateKeywords = (type: 'premiumKeywords' | 'staffKeywords', value: string) => {
    setConfig(prev => ({
      ...prev,
      [type]: value.split(',').map(k => k.trim())
    }));
  };
  
  const updateRoles = (type: 'premiumRoles' | 'staffRoles', value: string) => {
    setConfig(prev => ({
      ...prev,
      [type]: value.split(',').map(r => r.trim())
    }));
  };
  
  const handleRunNow = () => {
    setupChannelPermissionsMutation.mutate();
  };
  
  return (
    <>
      <Card className="bg-[#2C2F33] text-white">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg">Auto Channel Permissions</CardTitle>
              <CardDescription className="text-[#99AAB5]">
                Automatically configure permissions for channels based on their names
              </CardDescription>
            </div>
            <Switch
              checked={autoChannelPermissionsEnabled}
              onCheckedChange={setAutoChannelPermissionsEnabled}
              aria-label="Toggle auto channel permissions"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-[#23272A] p-4 rounded border border-gray-700">
            <h3 className="font-medium mb-2 flex items-center">
              <span className="bg-[#5865F2] p-1 rounded mr-2">
                <Check className="h-4 w-4" />
              </span>
              Premium Channels
            </h3>
            <p className="text-sm text-[#99AAB5] mb-3">
              Channels containing these keywords will be restricted to premium members and staff.
            </p>
            <div className="space-x-1 mt-2">
              {config.premiumKeywords.map((keyword, i) => (
                <span key={i} className="inline-block bg-[#5865F2] text-white text-xs px-2 py-1 rounded mr-1 mb-1">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
          
          <div className="bg-[#23272A] p-4 rounded border border-gray-700">
            <h3 className="font-medium mb-2 flex items-center">
              <span className="bg-[#ED4245] p-1 rounded mr-2">
                <X className="h-4 w-4" />
              </span>
              Staff Channels
            </h3>
            <p className="text-sm text-[#99AAB5] mb-3">
              Channels containing these keywords will be restricted to staff members only.
            </p>
            <div className="space-x-1 mt-2">
              {config.staffKeywords.map((keyword, i) => (
                <span key={i} className="inline-block bg-[#ED4245] text-white text-xs px-2 py-1 rounded mr-1 mb-1">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-[#23272A] justify-between">
          <Button 
            variant="outline" 
            className="border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]"
            onClick={handleOpenDialog}
          >
            <Cog className="h-4 w-4 mr-2" />
            Configure
          </Button>
          
          <Button 
            className="bg-[#5865F2] hover:bg-opacity-90 text-white"
            disabled={setupChannelPermissionsMutation.isPending || !autoChannelPermissionsEnabled}
            onClick={handleRunNow}
          >
            {setupChannelPermissionsMutation.isPending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>Run Now</>
            )}
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium text-white">
              Configure Auto Channel Permissions
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <h3 className="text-sm font-medium text-white mb-3">Premium Channel Settings</h3>
              
              <div className="grid gap-2">
                <Label htmlFor="premiumKeywords" className="text-xs text-[#99AAB5]">
                  Channel Name Keywords
                </Label>
                <Input 
                  id="premiumKeywords" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="premium, vip, exclusive"
                  value={config.premiumKeywords.join(', ')}
                  onChange={(e) => updateKeywords('premiumKeywords', e.target.value)}
                />
                <p className="text-xs text-[#99AAB5]">
                  Comma-separated list of keywords to identify premium channels
                </p>
              </div>
              
              <div className="grid gap-2 mt-3">
                <Label htmlFor="premiumRoles" className="text-xs text-[#99AAB5]">
                  Allowed Role Keywords
                </Label>
                <Input 
                  id="premiumRoles" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="premium, vip, admin, staff, mod"
                  value={config.premiumRoles.join(', ')}
                  onChange={(e) => updateRoles('premiumRoles', e.target.value)}
                />
                <p className="text-xs text-[#99AAB5]">
                  Comma-separated list of role name keywords that should have access
                </p>
              </div>
            </div>
            
            <Separator className="bg-gray-700" />
            
            <div>
              <h3 className="text-sm font-medium text-white mb-3">Staff Channel Settings</h3>
              
              <div className="grid gap-2">
                <Label htmlFor="staffKeywords" className="text-xs text-[#99AAB5]">
                  Channel Name Keywords
                </Label>
                <Input 
                  id="staffKeywords" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="staff, mod, admin, team"
                  value={config.staffKeywords.join(', ')}
                  onChange={(e) => updateKeywords('staffKeywords', e.target.value)}
                />
                <p className="text-xs text-[#99AAB5]">
                  Comma-separated list of keywords to identify staff channels
                </p>
              </div>
              
              <div className="grid gap-2 mt-3">
                <Label htmlFor="staffRoles" className="text-xs text-[#99AAB5]">
                  Allowed Role Keywords
                </Label>
                <Input 
                  id="staffRoles" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="staff, mod, admin"
                  value={config.staffRoles.join(', ')}
                  onChange={(e) => updateRoles('staffRoles', e.target.value)}
                />
                <p className="text-xs text-[#99AAB5]">
                  Comma-separated list of role name keywords that should have access
                </p>
              </div>
            </div>
          </div>
          
          <DialogFooter className="bg-[#23272A] px-6 py-4 -mx-6 -mb-6 flex justify-end space-x-3">
            <Button 
              type="button" 
              variant="secondary" 
              onClick={() => setIsDialogOpen(false)}
              className="bg-[#2C2F33] hover:bg-opacity-80 text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveConfig}
              className="bg-[#5865F2] hover:bg-opacity-90 text-white"
              disabled={saveConfigMutation.isPending}
            >
              {saveConfigMutation.isPending ? "Saving..." : "Save Config"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
