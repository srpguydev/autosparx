import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MoreVertical, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RolePattern } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

export default function AutoRoleCard() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: rolePatterns = [], isLoading } = useQuery<RolePattern[]>({
    queryKey: ['/api/role-patterns', guildId],
  });
  
  const addRoleMutation = useMutation({
    mutationFn: async (newPattern: Omit<RolePattern, 'id' | 'createdAt'>) => {
      const res = await apiRequest('POST', '/api/role-patterns', newPattern);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/role-patterns', guildId] });
      setIsDialogOpen(false);
      toast({
        title: "Role pattern added",
        description: "The new role pattern has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add role pattern",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleAddPattern = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const roleName = formData.get('roleName') as string;
    const roleId = formData.get('roleId') as string;
    const pattern = formData.get('pattern') as string;
    const patternType = formData.get('patternType') as string;
    const caseSensitive = formData.get('caseSensitive') === 'on';
    const roleColor = formData.get('roleColor') as string;
    
    if (!roleName || !roleId || !pattern || !patternType) {
      toast({
        title: "Invalid form data",
        description: "Please fill out all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    addRoleMutation.mutate({
      guildId,
      roleId,
      roleName,
      pattern,
      patternType,
      caseSensitive,
      roleColor,
    });
  };
  
  return (
    <>
      <Card className="bg-[#2C2F33] text-white overflow-hidden">
        <CardHeader className="px-5 py-4 bg-[#23272A] flex flex-row justify-between items-center">
          <CardTitle className="text-lg font-medium">Auto Role Assignment</CardTitle>
          <Button variant="ghost" size="icon" className="text-[#99AAB5] hover:text-white">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </CardHeader>
        
        <div className="px-5 py-3 border-b border-gray-700">
          <p className="text-sm text-[#99AAB5]">
            Configure roles that are automatically assigned based on username patterns
          </p>
        </div>
        
        <CardContent className="px-5 py-3">
          {isLoading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#5865F2]"></div>
            </div>
          ) : rolePatterns.length === 0 ? (
            <div className="text-center py-6 text-[#99AAB5]">
              <p>No role patterns configured yet.</p>
            </div>
          ) : (
            rolePatterns.map((pattern) => (
              <div key={pattern.id} className="flex items-center justify-between py-2">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: pattern.roleColor || '#3498db' }}
                  ></div>
                  <span className="ml-2 text-sm font-medium text-white">{pattern.roleName}</span>
                </div>
                <div className="text-sm text-[#99AAB5]">
                  Contains: {pattern.pattern}
                </div>
              </div>
            ))
          )}
        </CardContent>
        
        <CardFooter className="px-5 py-4 bg-[#23272A]">
          <Button 
            className="w-full justify-center bg-[#5865F2] hover:bg-opacity-90 text-white"
            onClick={() => setIsDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New Role Pattern
          </Button>
        </CardFooter>
      </Card>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium text-white">Add New Role Pattern</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleAddPattern}>
            <div className="space-y-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="roleName" className="text-sm font-medium text-[#99AAB5]">Role Name</Label>
                <Input 
                  id="roleName" 
                  name="roleName" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="Developer"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="roleId" className="text-sm font-medium text-[#99AAB5]">Role ID</Label>
                <Input 
                  id="roleId" 
                  name="roleId" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="123456789012345678"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="roleColor" className="text-sm font-medium text-[#99AAB5]">Role Color</Label>
                <div className="flex gap-2">
                  <Input 
                    type="color" 
                    id="roleColor" 
                    name="roleColor" 
                    className="w-12 h-10 p-1 bg-[#23272A] border-gray-700"
                    defaultValue="#3498db"
                  />
                  <Input 
                    id="roleColorHex" 
                    className="bg-[#23272A] border-gray-700 text-white"
                    placeholder="#3498db"
                    defaultValue="#3498db"
                    readOnly
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="pattern" className="text-sm font-medium text-[#99AAB5]">Username Pattern</Label>
                <Input 
                  id="pattern" 
                  name="pattern" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="dev,coder"
                  required
                />
                <p className="text-xs text-[#99AAB5]">Separate multiple patterns with commas</p>
              </div>
              
              <div className="grid gap-2">
                <Label className="text-sm font-medium text-[#99AAB5]">Pattern Type</Label>
                <RadioGroup defaultValue="contains" name="patternType">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="contains" id="contains" className="text-[#5865F2]" />
                    <Label htmlFor="contains" className="text-white">Contains</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="startsWith" id="startsWith" className="text-[#5865F2]" />
                    <Label htmlFor="startsWith" className="text-white">Starts With</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="regex" id="regex" className="text-[#5865F2]" />
                    <Label htmlFor="regex" className="text-white">Regex</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="caseSensitive" name="caseSensitive" className="text-[#5865F2]" />
                <Label htmlFor="caseSensitive" className="text-white">Enable case sensitivity</Label>
              </div>
            </div>
            
            <DialogFooter className="bg-[#23272A] px-6 py-4 -mx-6 -mb-6 flex justify-end space-x-3">
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => setIsDialogOpen(false)}
                className="bg-[#2C2F33] hover:bg-opacity-80 text-white"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-[#5865F2] hover:bg-opacity-90 text-white"
                disabled={addRoleMutation.isPending}
              >
                {addRoleMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
