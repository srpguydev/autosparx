import { useState } from "react";
import { PlusCircle, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

type HeaderProps = {
  title: string;
  version?: string;
};

export default function Header({ title, version = "v1.2.0" }: HeaderProps) {
  return (
    <header className="bg-[#2C2F33] border-b border-gray-700 flex items-center justify-between h-16 px-4 lg:px-6">
      <div className="flex items-center">
        <h1 className="text-lg lg:text-xl font-semibold text-white ml-8 lg:ml-0">{title}</h1>
        <span className="ml-2 px-2 py-0.5 text-xs font-medium rounded-full bg-[#5865F2] text-white">
          {version}
        </span>
      </div>

      <div className="flex items-center space-x-4">
        {/* Status Indicator */}
        <div className="hidden md:flex items-center px-3 py-1.5 rounded-full bg-[#23272A]">
          <div className="w-2 h-2 rounded-full bg-[#3BA55C]"></div>
          <span className="ml-2 text-xs font-medium text-[#99AAB5]">Bot Online</span>
        </div>
        
        {/* Quick Actions */}
        <Button variant="ghost" size="icon" className="text-[#f6f6f7] hover:bg-[#23272A]">
          <PlusCircle className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-[#f6f6f7] hover:bg-[#23272A]">
          <Bell className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
}
