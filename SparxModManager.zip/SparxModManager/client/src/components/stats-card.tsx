import { cn } from "@/lib/utils";

export type StatCardProps = {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  className?: string;
  iconClassName?: string;
};

export default function StatsCard({
  title,
  value,
  icon,
  className,
  iconClassName,
}: StatCardProps) {
  return (
    <div className={cn("bg-[#2C2F33] rounded-lg shadow p-4 flex items-center", className)}>
      <div className={cn("p-3 rounded-md bg-opacity-20", iconClassName)}>
        {icon}
      </div>
      <div className="ml-4">
        <h2 className="text-sm font-medium text-[#99AAB5]">{title}</h2>
        <p className="text-2xl font-semibold text-white">{value}</p>
      </div>
    </div>
  );
}
