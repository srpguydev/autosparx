import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MoreVertical, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { BotLog } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function LogsCard() {
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: logs = [], isLoading } = useQuery<BotLog[]>({
    queryKey: ['/api/logs', guildId],
  });
  
  const handleExportLogs = () => {
    if (!logs.length) return;
    
    // Format logs for export
    const formattedLogs = logs.map(log => {
      const time = new Date(log.createdAt).toLocaleString();
      const user = log.username ? ` by ${log.username}` : '';
      return `[${time}] [${log.type.toUpperCase()}]${user}: ${log.message}`;
    }).join('\n');
    
    // Create and download file
    const blob = new Blob([formattedLogs], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sparxcore-logs-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const getLogTypeColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-[#3BA55C]';
      case 'error':
        return 'bg-[#ED4245]';
      case 'warning':
        return 'bg-[#FEE75C]';
      case 'info':
      default:
        return 'bg-[#5865F2]';
    }
  };

  return (
    <Card className="bg-[#2C2F33] text-white overflow-hidden">
      <CardHeader className="px-5 py-4 bg-[#23272A] flex flex-row justify-between items-center">
        <CardTitle className="text-lg font-medium">Recent Bot Activity</CardTitle>
        <Button variant="ghost" size="icon" className="text-[#99AAB5] hover:text-white">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </CardHeader>
      
      <div className="px-5 py-3 border-b border-gray-700">
        <p className="text-sm text-[#99AAB5]">
          Recent bot logs and activity history
        </p>
      </div>
      
      <ScrollArea className="h-56">
        <CardContent className="px-5 py-3">
          {isLoading ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#5865F2]"></div>
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-6 text-[#99AAB5]">
              <p>No logs available.</p>
            </div>
          ) : (
            logs.map((log) => {
              const time = new Date(log.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              return (
                <div key={log.id} className="py-2 border-b border-gray-700">
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full ${getLogTypeColor(log.type)}`}></div>
                    <span className="ml-2 text-xs text-[#99AAB5]">{time}</span>
                  </div>
                  <p className="text-sm text-white mt-1">{log.message}</p>
                </div>
              );
            })
          )}
        </CardContent>
      </ScrollArea>
      
      <CardFooter className="px-5 py-4 bg-[#23272A]">
        <Button 
          className="w-full justify-center bg-[#5865F2] hover:bg-opacity-90 text-white"
          onClick={handleExportLogs}
          disabled={logs.length === 0}
        >
          <Download className="h-4 w-4 mr-2" />
          Export Logs
        </Button>
      </CardFooter>
    </Card>
  );
}
