import { useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type NewRoleDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  guildId: string;
};

export default function NewRoleDialog({ open, onOpenChange, guildId }: NewRoleDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const addRoleMutation = useMutation({
    mutationFn: async (formData: any) => {
      const res = await apiRequest('POST', '/api/role-patterns', formData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/role-patterns', guildId] });
      onOpenChange(false);
      toast({
        title: "Role pattern added",
        description: "The new role pattern has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add role pattern",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const roleName = formData.get('roleName') as string;
    const roleId = formData.get('roleId') as string;
    const pattern = formData.get('pattern') as string;
    const patternType = formData.get('patternType') as string;
    const caseSensitive = formData.get('caseSensitive') === 'on';
    const roleColor = formData.get('roleColor') as string;
    
    if (!roleName || !roleId || !pattern || !patternType) {
      toast({
        title: "Invalid form data",
        description: "Please fill out all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    addRoleMutation.mutate({
      guildId,
      roleId,
      roleName,
      pattern,
      patternType,
      caseSensitive,
      roleColor,
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#2C2F33] text-white border-gray-700">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium text-white">Add New Role Pattern</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="roleName" className="text-sm font-medium text-[#99AAB5]">Role Name</Label>
              <Input 
                id="roleName" 
                name="roleName" 
                className="bg-[#23272A] border-gray-700 text-white"
                placeholder="Developer"
                required
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="roleId" className="text-sm font-medium text-[#99AAB5]">Role ID</Label>
              <Input 
                id="roleId" 
                name="roleId" 
                className="bg-[#23272A] border-gray-700 text-white"
                placeholder="123456789012345678"
                required
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="roleColor" className="text-sm font-medium text-[#99AAB5]">Role Color</Label>
              <div className="flex gap-2">
                <Input 
                  type="color" 
                  id="roleColor" 
                  name="roleColor" 
                  className="w-12 h-10 p-1 bg-[#23272A] border-gray-700"
                  defaultValue="#3498db"
                />
                <Input 
                  id="roleColorHex" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="#3498db"
                  defaultValue="#3498db"
                  readOnly
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="pattern" className="text-sm font-medium text-[#99AAB5]">Username Pattern</Label>
              <Input 
                id="pattern" 
                name="pattern" 
                className="bg-[#23272A] border-gray-700 text-white"
                placeholder="dev,coder"
                required
              />
              <p className="text-xs text-[#99AAB5]">Separate multiple patterns with commas</p>
            </div>
            
            <div className="grid gap-2">
              <Label className="text-sm font-medium text-[#99AAB5]">Pattern Type</Label>
              <RadioGroup defaultValue="contains" name="patternType">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="contains" id="contains" className="text-[#5865F2]" />
                  <Label htmlFor="contains" className="text-white">Contains</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="startsWith" id="startsWith" className="text-[#5865F2]" />
                  <Label htmlFor="startsWith" className="text-white">Starts With</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="regex" id="regex" className="text-[#5865F2]" />
                  <Label htmlFor="regex" className="text-white">Regex</Label>
                </div>
              </RadioGroup>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox id="caseSensitive" name="caseSensitive" className="text-[#5865F2]" />
              <Label htmlFor="caseSensitive" className="text-white">Enable case sensitivity</Label>
            </div>
          </div>
          
          <DialogFooter className="bg-[#23272A] px-6 py-4 -mx-6 -mb-6 flex justify-end space-x-3">
            <Button 
              type="button" 
              variant="secondary" 
              onClick={() => onOpenChange(false)}
              className="bg-[#2C2F33] hover:bg-opacity-80 text-white"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-[#5865F2] hover:bg-opacity-90 text-white"
              disabled={addRoleMutation.isPending}
            >
              {addRoleMutation.isPending ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
