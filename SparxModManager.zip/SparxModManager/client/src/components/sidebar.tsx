import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useState } from "react";

// Icons
import { 
  LayoutDashboard, 
  Users, 
  Lock, 
  ClipboardList, 
  MessageSquare, 
  Settings, 
  HelpCircle,
  BookOpen
} from "lucide-react";

type SidebarProps = {
  className?: string;
};

export default function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const [selectedServer, setSelectedServer] = useState("Gaming Community");

  const navigation = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Auto Roles", href: "/auto-roles", icon: Users },
    { name: "Channel Permissions", href: "/channel-permissions", icon: Lock },
    { name: "Logs", href: "/logs", icon: ClipboardList },
    { name: "Commands", href: "/commands", icon: MessageSquare },
    { name: "Sparx Maths", href: "/sparx", icon: BookOpen },
  ];

  const adminNavigation = [
    { name: "Settings", href: "/settings", icon: Settings },
    { name: "Help", href: "/help", icon: HelpCircle },
  ];

  const servers = ["Gaming Community", "SparxCore HQ", "Developers Guild"];

  return (
    <div className={cn("h-full flex flex-col bg-[#23272A]", className)}>
      {/* Bot Info */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold text-xl">
            SC
          </div>
          <div className="ml-3">
            <h2 className="text-lg font-semibold text-white">SparxCore</h2>
            <div className="flex items-center">
              <div className="w-2 h-2 rounded-full bg-[#3BA55C]"></div>
              <span className="ml-1 text-xs text-gray-300">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        <div className="px-2 space-y-1">
          {navigation.map((item) => (
            <Link 
              key={item.name} 
              href={item.href}
            >
              <div 
                className={cn(
                  "flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer",
                  location === item.href 
                    ? "text-white bg-[rgba(79,84,92,0.32)]" 
                    : "text-[#99AAB5] hover:text-white hover:bg-[rgba(79,84,92,0.16)]"
                )}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.name}
              </div>
            </Link>
          ))}

          <div className="pt-2 mt-2 border-t border-gray-700">
            <h3 className="px-3 text-xs font-semibold text-[#99AAB5] uppercase tracking-wider">
              Admin Settings
            </h3>
          </div>

          {adminNavigation.map((item) => (
            <Link 
              key={item.name} 
              href={item.href}
            >
              <div 
                className={cn(
                  "flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer",
                  location === item.href 
                    ? "text-white bg-[rgba(79,84,92,0.32)]" 
                    : "text-[#99AAB5] hover:text-white hover:bg-[rgba(79,84,92,0.16)]"
                )}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.name}
              </div>
            </Link>
          ))}
        </div>
      </nav>

      {/* Server Selection */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-[#2C2F33] flex items-center justify-center text-white">
            {selectedServer[0]}
          </div>
          <div className="ml-3 flex-1">
            <select 
              className="w-full bg-[#2C2F33] text-sm text-white border border-gray-700 rounded py-1 px-2"
              value={selectedServer}
              onChange={(e) => setSelectedServer(e.target.value)}
            >
              {servers.map((server) => (
                <option key={server} value={server}>{server}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
