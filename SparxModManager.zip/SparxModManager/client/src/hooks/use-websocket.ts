import { useState, useEffect, useRef, useCallback } from 'react';

export type WebSocketStatus = 'connecting' | 'open' | 'closed' | 'error' | 'fallback';

export type WebSocketMessage = {
  type: string;
  [key: string]: any;
};

// Polling interval in milliseconds
const POLLING_INTERVAL = 5000;

export const useWebSocket = () => {
  const [status, setStatus] = useState<WebSocketStatus>('connecting');
  const [messages, setMessages] = useState<WebSocketMessage[]>([]);
  const socketRef = useRef<WebSocket | null>(null);
  
  // Initialize WebSocket connection
  useEffect(() => {
    // Try to establish WebSocket connection
    const setupWebSocket = () => {
      try {
        // Get the URL from the current host
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        
        // Log the host for debugging
        console.log('WebSocket host environment:', {
          host,
          protocol: window.location.protocol,
          origin: window.location.origin
        });
        
        // Validation to prevent malformed URLs
        if (!host || host.includes('undefined')) {
          console.error('Invalid WebSocket host:', host);
          throw new Error('Invalid host for WebSocket connection');
        }
        
        // For Replit environment, use the current host directly
        // Make sure we have a valid WebSocket URL with path
        const wsUrl = `${protocol}//${host}/ws`;
        console.log('Attempting to connect to WebSocket at:', wsUrl);
        
        // Create the WebSocket
        const socket = new WebSocket(wsUrl);
        socketRef.current = socket;
        
        socket.onopen = () => {
          console.log('WebSocket connection established');
          setStatus('open');
          
          // Send a subscribe message
          if (socket) {
            socket.send(JSON.stringify({ 
              type: 'subscribe', 
              channel: 'sparx-automation' 
            }));
          }
        };
        
        socket.onclose = () => {
          console.log('WebSocket connection closed');
          setStatus('closed');
        };
        
        socket.onerror = (error) => {
          console.error('WebSocket connection error:', error);
          setStatus('error');
          
          // Fallback to polling after error
          setTimeout(() => {
            if (status !== 'open' && !intervalId) {
              intervalId = setupFallbackPolling();
            }
          }, 2000);
        };
        
        socket.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data);
            console.log('WebSocket message received:', message);
            setMessages((prev) => [...prev, message]);
          } catch (error) {
            console.error('Error parsing WebSocket message:', error);
          }
        };
        
        return socket;
      } catch (error) {
        console.error('Error establishing WebSocket connection:', error);
        return null;
      }
    };
    
    // Fallback polling mechanism
    const setupFallbackPolling = (): ReturnType<typeof setInterval> => {
      console.log('Falling back to polling for updates...');
      setStatus('fallback');
      
      const intervalId = setInterval(async () => {
        try {
          // Fetch the latest session data
          const response = await fetch('/api/sparx/sessions?limit=1');
          // Handle the response
          const data = await response.json();
          
          if (data && Array.isArray(data) && data.length > 0) {
            const session = data[0];
            
            // Add a message to the state if there's progress info
            if (session.status === 'in_progress' || session.status === 'completed') {
              setMessages(prev => {
                // Only add if message is new (based on status & questions)
                const message = {
                  type: 'automation-progress',
                  message: `Status: ${session.status}, Questions answered: ${session.questionsAnswered || 0}`,
                  timestamp: new Date().toISOString()
                };
                
                // Check if we already have this message to avoid duplicates
                const messageExists = prev.some(m => 
                  m.type === message.type && 
                  m.message === message.message
                );
                
                return messageExists ? prev : [...prev, message];
              });
            }
          }
        } catch (pollError) {
          console.error('Error polling for updates:', pollError);
        }
      }, POLLING_INTERVAL);
      
      return intervalId;
    };
    
    // Main initialization logic
    let socket = setupWebSocket();
    let intervalId: ReturnType<typeof setInterval> | null = null;
    
    // If WebSocket setup failed, start polling
    if (!socket) {
      intervalId = setupFallbackPolling();
    }
    
    // Clean up function
    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
      
      if (intervalId !== null) {
        clearInterval(intervalId);
      }
    };
  }, []);
  
  // Function to send a message through the WebSocket
  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
      return true;
    }
    return false;
  }, []);
  
  // Clear the messages state
  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);
  
  return {
    status,
    messages,
    sendMessage,
    clearMessages,
  };
};