import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ChannelPermission, InsertChannelPermission } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import AutoChannelPermissionsCard from "@/components/auto-channel-permissions-card";

export default function ChannelPermissions() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [permissionToDelete, setPermissionToDelete] = useState<number | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: permissions = [], isLoading } = useQuery<ChannelPermission[]>({
    queryKey: ['/api/channel-permissions', guildId],
  });
  
  // Group permissions by channel
  const channelGroups = permissions.reduce((acc, perm) => {
    if (!acc[perm.channelId]) {
      acc[perm.channelId] = {
        id: perm.channelId,
        name: perm.channelName,
        permissions: []
      };
    }
    acc[perm.channelId].permissions.push(perm);
    return acc;
  }, {} as Record<string, { id: string; name: string; permissions: ChannelPermission[] }>);
  
  const channels = Object.values(channelGroups);
  
  const addPermissionMutation = useMutation({
    mutationFn: async (data: InsertChannelPermission) => {
      const res = await apiRequest('POST', '/api/channel-permissions', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/channel-permissions', guildId] });
      setIsDialogOpen(false);
      toast({
        title: "Channel permission added",
        description: "The channel permission has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add channel permission",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const deletePermissionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/channel-permissions/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/channel-permissions', guildId] });
      toast({
        title: "Channel permission deleted",
        description: "The channel permission has been deleted successfully.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete channel permission",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDeletePermission = (id: number) => {
    setPermissionToDelete(id);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (permissionToDelete !== null) {
      deletePermissionMutation.mutate(permissionToDelete);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const channelId = formData.get('channelId') as string;
    const channelName = formData.get('channelName') as string;
    const roleId = formData.get('roleId') as string;
    const roleName = formData.get('roleName') as string;
    const permission = formData.get('permission') as string;
    const access = formData.get('access') as 'allow' | 'deny';
    
    if (!channelId || !channelName || !roleId || !roleName || !permission || !access) {
      toast({
        title: "Invalid form data",
        description: "Please fill out all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    const permissionData: InsertChannelPermission = {
      guildId,
      channelId,
      channelName,
      roleId,
      roleName,
      permission,
      access
    };
    
    addPermissionMutation.mutate(permissionData);
  };
  
  const getAccessBadgeColor = (access: string) => {
    return access === 'allow' ? 'bg-[#3BA55C]' : 'bg-[#ED4245]';
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Channel Permissions" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="flex flex-col space-y-6">
            {/* Automatic Channel Permissions Card */}
            <AutoChannelPermissionsCard />
          
            {/* Manual Permissions Section */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Manual Channel Permissions</h2>
                <Button 
                  className="bg-[#5865F2] hover:bg-opacity-90 text-white"
                  onClick={() => setIsDialogOpen(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Permission
                </Button>
              </div>
              
              {isLoading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
                </div>
              ) : channels.length === 0 ? (
                <div className="text-center py-12 text-[#99AAB5] bg-[#2C2F33] rounded-lg">
                  <p>No channel permissions configured yet.</p>
                  <Button 
                    className="mt-4 bg-[#5865F2] hover:bg-opacity-90 text-white"
                    onClick={() => setIsDialogOpen(true)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Permission
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  {channels.map((channel) => (
                    <div key={channel.id} className="bg-[#2C2F33] rounded-lg shadow overflow-hidden">
                      <div className="bg-[#23272A] px-4 py-3 flex items-center">
                        <div className="w-2 h-2 bg-[#5865F2] rounded-full mr-2"></div>
                        <h3 className="font-medium">{channel.name}</h3>
                        <span className="text-xs text-[#99AAB5] ml-2">ID: {channel.id}</span>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="text-[#99AAB5]">Role</TableHead>
                              <TableHead className="text-[#99AAB5]">Permission</TableHead>
                              <TableHead className="text-[#99AAB5]">Access</TableHead>
                              <TableHead className="text-[#99AAB5] text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {channel.permissions.map((perm) => (
                              <TableRow key={perm.id} className="border-gray-700 hover:bg-[#2f3136]">
                                <TableCell className="font-medium">{perm.roleName}</TableCell>
                                <TableCell>{perm.permission}</TableCell>
                                <TableCell>
                                  <span className={`px-2 py-1 text-xs rounded-full ${getAccessBadgeColor(perm.access)} text-white`}>
                                    {perm.access.toUpperCase()}
                                  </span>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    onClick={() => handleDeletePermission(perm.id)}
                                  >
                                    <Trash2 className="h-4 w-4 text-[#ED4245]" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
      
      {/* Add Permission Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium text-white">Add Channel Permission</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="channelId" className="text-sm font-medium text-[#99AAB5]">Channel ID</Label>
                  <Input 
                    id="channelId" 
                    name="channelId" 
                    className="bg-[#23272A] border-gray-700 text-white"
                    placeholder="123456789012345678"
                    required
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="channelName" className="text-sm font-medium text-[#99AAB5]">Channel Name</Label>
                  <Input 
                    id="channelName" 
                    name="channelName" 
                    className="bg-[#23272A] border-gray-700 text-white"
                    placeholder="general"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="roleId" className="text-sm font-medium text-[#99AAB5]">Role ID</Label>
                  <Input 
                    id="roleId" 
                    name="roleId" 
                    className="bg-[#23272A] border-gray-700 text-white"
                    placeholder="123456789012345678"
                    required
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="roleName" className="text-sm font-medium text-[#99AAB5]">Role Name</Label>
                  <Input 
                    id="roleName" 
                    name="roleName" 
                    className="bg-[#23272A] border-gray-700 text-white"
                    placeholder="Member"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="permission" className="text-sm font-medium text-[#99AAB5]">Permission</Label>
                  <Select name="permission" defaultValue="VIEW_CHANNEL">
                    <SelectTrigger className="bg-[#23272A] border-gray-700 text-white">
                      <SelectValue placeholder="Select permission" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#2C2F33] border-gray-700 text-white">
                      <SelectItem value="VIEW_CHANNEL">VIEW_CHANNEL</SelectItem>
                      <SelectItem value="SEND_MESSAGES">SEND_MESSAGES</SelectItem>
                      <SelectItem value="EMBED_LINKS">EMBED_LINKS</SelectItem>
                      <SelectItem value="ATTACH_FILES">ATTACH_FILES</SelectItem>
                      <SelectItem value="ADD_REACTIONS">ADD_REACTIONS</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="access" className="text-sm font-medium text-[#99AAB5]">Access</Label>
                  <Select name="access" defaultValue="allow">
                    <SelectTrigger className="bg-[#23272A] border-gray-700 text-white">
                      <SelectValue placeholder="Select access" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#2C2F33] border-gray-700 text-white">
                      <SelectItem value="allow">Allow</SelectItem>
                      <SelectItem value="deny">Deny</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <DialogFooter className="bg-[#23272A] px-6 py-4 -mx-6 -mb-6 flex justify-end space-x-3">
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => setIsDialogOpen(false)}
                className="bg-[#2C2F33] hover:bg-opacity-80 text-white"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-[#5865F2] hover:bg-opacity-90 text-white"
                disabled={addPermissionMutation.isPending}
              >
                {addPermissionMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Permission</AlertDialogTitle>
            <AlertDialogDescription className="text-[#99AAB5]">
              Are you sure you want to delete this channel permission? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-[#36393F] text-white border-gray-700">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-[#ED4245] hover:bg-opacity-80"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
