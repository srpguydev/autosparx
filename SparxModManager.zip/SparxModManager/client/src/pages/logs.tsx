import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { BotLog } from "@shared/schema";
import { Download, FileText, Filter } from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Logs() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [logLimit, setLogLimit] = useState(50);
  const [logTypeFilter, setLogTypeFilter] = useState<string | null>(null);
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: logs = [], isLoading } = useQuery<BotLog[]>({
    queryKey: ['/api/logs', guildId, { limit: logLimit }],
  });
  
  const filteredLogs = logTypeFilter 
    ? logs.filter(log => log.type === logTypeFilter)
    : logs;
  
  const handleExportLogs = () => {
    if (!logs.length) return;
    
    // Format logs for export
    const formattedLogs = logs.map(log => {
      const time = new Date(log.createdAt).toLocaleString();
      const user = log.username ? ` by ${log.username}` : '';
      return `[${time}] [${log.type.toUpperCase()}]${user}: ${log.message}`;
    }).join('\n');
    
    // Create and download file
    const blob = new Blob([formattedLogs], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sparxcore-logs-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const getLogTypeColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-[#3BA55C]';
      case 'error':
        return 'bg-[#ED4245]';
      case 'warning':
        return 'bg-[#FEE75C]';
      case 'info':
      default:
        return 'bg-[#5865F2]';
    }
  };
  
  const getLogIcon = (type: string) => {
    switch (type) {
      case 'success':
        return '🟢';
      case 'error':
        return '🔴';
      case 'warning':
        return '🟡';
      case 'info':
      default:
        return '🔵';
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Bot Logs" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Bot Activity Logs</h2>
            <Button 
              className="bg-[#5865F2] hover:bg-opacity-90 text-white"
              onClick={handleExportLogs}
              disabled={logs.length === 0}
            >
              <Download className="h-4 w-4 mr-2" />
              Export Logs
            </Button>
          </div>
          
          {/* Filters */}
          <Card className="bg-[#2C2F33] text-white mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-md flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Log Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <div className="flex-1 min-w-[200px]">
                  <Label htmlFor="logType" className="text-sm text-[#99AAB5] mb-1 block">Log Type</Label>
                  <Select
                    value={logTypeFilter || "all"}
                    onValueChange={(value) => setLogTypeFilter(value === "all" ? null : value)}
                  >
                    <SelectTrigger className="bg-[#23272A] border-gray-700 text-white">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#2C2F33] border-gray-700 text-white">
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="success">Success</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="error">Error</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1 min-w-[200px]">
                  <Label htmlFor="logLimit" className="text-sm text-[#99AAB5] mb-1 block">Log Limit</Label>
                  <Select
                    value={logLimit.toString()}
                    onValueChange={(value) => setLogLimit(parseInt(value))}
                  >
                    <SelectTrigger className="bg-[#23272A] border-gray-700 text-white">
                      <SelectValue placeholder="Number of logs" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#2C2F33] border-gray-700 text-white">
                      <SelectItem value="10">10 Logs</SelectItem>
                      <SelectItem value="50">50 Logs</SelectItem>
                      <SelectItem value="100">100 Logs</SelectItem>
                      <SelectItem value="200">200 Logs</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Logs List */}
          <Card className="bg-[#2C2F33] text-white overflow-hidden">
            <CardHeader className="bg-[#23272A] pb-3">
              <CardTitle className="text-lg font-medium">Activity Logs</CardTitle>
            </CardHeader>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
              </div>
            ) : filteredLogs.length === 0 ? (
              <div className="text-center py-12 text-[#99AAB5]">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No logs found matching your criteria.</p>
              </div>
            ) : (
              <ScrollArea className="h-[500px]">
                <CardContent className="p-0">
                  <div className="divide-y divide-gray-700">
                    {filteredLogs.map((log) => {
                      const time = new Date(log.createdAt).toLocaleString();
                      return (
                        <div key={log.id} className="p-4">
                          <div className="flex items-center text-[#99AAB5]">
                            <div className={`w-2 h-2 rounded-full ${getLogTypeColor(log.type)}`}></div>
                            <span className="ml-2 text-xs">{time}</span>
                            {log.username && (
                              <span className="ml-2 text-xs font-medium">
                                by {log.username}
                              </span>
                            )}
                            <span className="ml-2 text-xs px-1.5 py-0.5 rounded bg-[#36393F]">
                              {log.type.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-sm text-white mt-1 pl-4">{log.message}</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </ScrollArea>
            )}
          </Card>
        </main>
      </div>
    </div>
  );
}
