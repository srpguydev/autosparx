import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/use-websocket";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, School, BookOpenCheck, Calendar, RotateCw, CheckCircle, XCircle } from "lucide-react";
import type { SparxAccount, SparxSession } from "@shared/schema";

export default function SparxPage() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [sessionUpdates, setSessionUpdates] = useState<{message: string, screenshot?: string}[]>([]);
  const { toast } = useToast();
  // Use WebSocket hook with a try-catch to avoid errors
  const websocket = useWebSocket();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  // For debugging
  useEffect(() => {
    console.log("WebSocket connection status:", websocket?.status || "not available");
  }, [websocket?.status]);
  
  // Listen for WebSocket messages
  useEffect(() => {
    // Ensure websocket and messages are available
    if (!websocket || !websocket.messages || websocket.messages.length === 0) {
      return;
    }
    
    const wsMessages = websocket.messages;
    const latestMessage = wsMessages[wsMessages.length - 1];
    
    // Handle automation progress updates
    if (latestMessage.type === 'automation-progress') {
      setSessionUpdates(prev => [...prev, {
        message: latestMessage.message,
        screenshot: latestMessage.screenshot
      }]);
      
      // Also refresh the sessions data
      queryClient.invalidateQueries({ queryKey: ['/api/sparx/sessions', guildId] });
      
      // Show toast for important updates
      if (latestMessage.important) {
        toast({
          title: "Automation Update",
          description: latestMessage.message,
        });
      }
    }
  }, [websocket?.messages, toast]);
  
  const { data: accounts, isLoading: isLoadingAccounts } = useQuery<SparxAccount[]>({
    queryKey: ['/api/sparx/accounts', guildId],
  });
  
  const { data: sessions, isLoading: isLoadingSessions } = useQuery<SparxSession[]>({
    queryKey: ['/api/sparx/sessions', guildId],
  });
  
  const addAccountMutation = useMutation({
    mutationFn: async (data: { 
      username: string; 
      password: string; 
      guildId: string;
      userId: string;
      schoolName: string;
      homeworkType: string;
    }) => {
      return apiRequest('/api/sparx/accounts', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sparx/accounts', guildId] });
      setUsername("");
      setPassword("");
      toast({
        title: "Success",
        description: "Sparx account added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add account: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const startAutomationMutation = useMutation({
    mutationFn: async (accountId: number) => {
      try {
        // First get the account to determine its userId and homeworkType
        const account = accounts?.find(acc => acc.id === accountId);
        
        if (!account) {
          throw new Error("Account not found");
        }
        
        // Use the account's userId or generate a new one if missing
        const userId = account.userId || `discord-user-${Date.now()}`;
        const homeworkType = account.homeworkType || "compulsory";
        
        console.log("Starting automation with:", {
          accountId,
          guildId, 
          userId,
          homeworkType
        });
        
        return apiRequest(`/api/sparx/automation/start`, {
          method: 'POST',
          body: JSON.stringify({ 
            accountId, 
            guildId, 
            userId,
            homeworkType
          }),
        });
      } catch (error) {
        console.error("Error preparing automation request:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sparx/sessions', guildId] });
      toast({
        title: "Success",
        description: "Sparx automation started",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to start automation: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const deleteAccountMutation = useMutation({
    mutationFn: async (accountId: number) => {
      return apiRequest(`/api/sparx/accounts/${accountId}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sparx/accounts', guildId] });
      toast({
        title: "Success",
        description: "Sparx account removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to remove account: ${error}`,
        variant: "destructive",
      });
    }
  });
  
  const [schoolName, setSchoolName] = useState("Sparx School");
  const [homeworkType, setHomeworkType] = useState<string>("compulsory");
  
  const handleAddAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password || !schoolName) {
      toast({
        title: "Error",
        description: "Please enter all required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Generate a userId (in a real app, this would be the actual Discord user ID)
    const userId = `discord-user-${Date.now()}`;
    
    addAccountMutation.mutate({ 
      username, 
      password, 
      guildId, 
      userId, 
      schoolName,
      homeworkType 
    });
  };
  
  const handleStartAutomation = (accountId: number) => {
    startAutomationMutation.mutate(accountId);
  };
  
  const handleDeleteAccount = (accountId: number) => {
    if (window.confirm("Are you sure you want to delete this account?")) {
      deleteAccountMutation.mutate(accountId);
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Sparx Maths" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="grid grid-cols-1 gap-6">
            {/* Add Account Card */}
            <Card className="bg-[#2F3136] border-[#202225] text-[#f6f6f7]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <School className="mr-2 h-5 w-5 text-[#5865F2]" />
                  Add Sparx Account
                </CardTitle>
                <CardDescription className="text-[#b9bbbe]">
                  Add a new Sparx account to automate homework
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddAccount} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="username" className="text-sm font-medium">
                        Username
                      </label>
                      <Input
                        id="username"
                        placeholder="Sparx username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="bg-[#40444B] border-[#202225] text-[#f6f6f7]"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="password" className="text-sm font-medium">
                        Password
                      </label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="Sparx password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="bg-[#40444B] border-[#202225] text-[#f6f6f7]"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="school" className="text-sm font-medium">
                        School Name
                      </label>
                      <Input
                        id="school"
                        placeholder="School name"
                        value={schoolName}
                        onChange={(e) => setSchoolName(e.target.value)}
                        className="bg-[#40444B] border-[#202225] text-[#f6f6f7]"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label htmlFor="homeworkType" className="text-sm font-medium">
                        Homework Type
                      </label>
                      <Select 
                        defaultValue={homeworkType}
                        onValueChange={(value) => setHomeworkType(value)}
                      >
                        <SelectTrigger className="bg-[#40444B] border-[#202225] text-[#f6f6f7]">
                          <SelectValue placeholder="Select homework type" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#2F3136] text-[#f6f6f7] border-[#202225]">
                          <SelectItem value="compulsory">Compulsory</SelectItem>
                          <SelectItem value="xpboost">XP Boost</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <Button
                    type="submit"
                    className="bg-[#5865F2] hover:bg-[#4752C4] text-white"
                    disabled={addAccountMutation.isPending}
                  >
                    {addAccountMutation.isPending ? (
                      <>
                        <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                        Adding...
                      </>
                    ) : (
                      "Add Account"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Accounts List */}
            <Card className="bg-[#2F3136] border-[#202225] text-[#f6f6f7]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="mr-2 h-5 w-5 text-[#5865F2]" />
                  Sparx Accounts
                </CardTitle>
                <CardDescription className="text-[#b9bbbe]">
                  Manage your registered Sparx accounts
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingAccounts ? (
                  <div className="flex justify-center p-4">
                    <RotateCw className="h-8 w-8 animate-spin text-[#5865F2]" />
                  </div>
                ) : accounts && accounts.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-[#40444B]">
                        <TableHead className="text-[#b9bbbe]">ID</TableHead>
                        <TableHead className="text-[#b9bbbe]">Username</TableHead>
                        <TableHead className="text-[#b9bbbe]">Status</TableHead>
                        <TableHead className="text-[#b9bbbe]">Last Login</TableHead>
                        <TableHead className="text-[#b9bbbe]">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {accounts.map((account) => (
                        <TableRow key={account.id} className="hover:bg-[#40444B]">
                          <TableCell className="font-medium">{account.id}</TableCell>
                          <TableCell>{account.username}</TableCell>
                          <TableCell>
                            {account.active ? (
                              <span className="flex items-center text-green-400">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Active
                              </span>
                            ) : (
                              <span className="flex items-center text-red-400">
                                <XCircle className="h-4 w-4 mr-1" />
                                Inactive
                              </span>
                            )}
                          </TableCell>
                          <TableCell>
                            {account.lastLogin
                              ? new Date(account.lastLogin).toLocaleString()
                              : "Never"}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                className="bg-[#3BA55C] hover:bg-[#2D7D46]"
                                onClick={() => handleStartAutomation(account.id)}
                              >
                                Start
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteAccount(account.id)}
                              >
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center p-4 text-[#b9bbbe]">
                    No Sparx accounts found. Add one above to get started.
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Live Progress Updates */}
            {sessionUpdates.length > 0 && (
              <Card className="bg-[#2F3136] border-[#202225] text-[#f6f6f7]">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <RotateCw className="mr-2 h-5 w-5 text-[#5865F2] animate-spin" />
                    Live Automation Updates
                    {websocket.status === 'fallback' && (
                      <span className="ml-2 text-sm text-yellow-400 font-normal">
                        (Polling Mode)
                      </span>
                    )}
                  </CardTitle>
                  <CardDescription className="text-[#b9bbbe]">
                    {websocket.status === 'open' 
                      ? "Real-time updates from the current session" 
                      : websocket.status === 'fallback'
                        ? "Updates using periodic polling (WebSocket unavailable)"
                        : websocket.status === 'error'
                          ? "WebSocket connection error - trying to reconnect"
                          : "Connecting to update service..."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {sessionUpdates.slice(-5).map((update, index) => (
                      <div key={index} className="p-3 bg-[#40444B] rounded-md">
                        <p className="text-[#f6f6f7] mb-2">{update.message}</p>
                        {update.screenshot && (
                          <div className="mt-2 border border-[#202225] rounded-md overflow-hidden">
                            <img src={update.screenshot} alt="Automation screenshot" className="w-full" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Recent Sessions */}
            <Card className="bg-[#2F3136] border-[#202225] text-[#f6f6f7]">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpenCheck className="mr-2 h-5 w-5 text-[#5865F2]" />
                  Recent Automation Sessions
                </CardTitle>
                <CardDescription className="text-[#b9bbbe]">
                  Recent Sparx automation activity
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingSessions ? (
                  <div className="flex justify-center p-4">
                    <RotateCw className="h-8 w-8 animate-spin text-[#5865F2]" />
                  </div>
                ) : sessions && sessions.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-[#40444B]">
                        <TableHead className="text-[#b9bbbe]">Account</TableHead>
                        <TableHead className="text-[#b9bbbe]">Start Time</TableHead>
                        <TableHead className="text-[#b9bbbe]">Questions</TableHead>
                        <TableHead className="text-[#b9bbbe]">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sessions.map((session) => (
                        <TableRow key={session.id} className="hover:bg-[#40444B]">
                          <TableCell>User #{session.userId.slice(-4)}</TableCell>
                          <TableCell>
                            {session.startTime ? new Date(session.startTime).toLocaleString() : 'N/A'}
                          </TableCell>
                          <TableCell>{session.questionsAnswered || 0}</TableCell>
                          <TableCell>
                            {session.status === 'completed' ? (
                              <span className="flex items-center text-green-400">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Completed
                              </span>
                            ) : session.status === 'error' ? (
                              <span className="flex items-center text-red-400">
                                <XCircle className="h-4 w-4 mr-1" />
                                Error
                              </span>
                            ) : (
                              <span className="flex items-center text-yellow-400">
                                <RotateCw className="h-4 w-4 mr-1 animate-spin" />
                                Running
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center p-4 text-[#b9bbbe]">
                    No automation sessions found yet.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}