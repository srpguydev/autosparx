import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Command, InsertCommand } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function Commands() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [commandToDelete, setCommandToDelete] = useState<number | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: commands = [], isLoading } = useQuery<Command[]>({
    queryKey: ['/api/commands', guildId],
  });
  
  const addCommandMutation = useMutation({
    mutationFn: async (data: InsertCommand) => {
      const res = await apiRequest('POST', '/api/commands', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commands', guildId] });
      setIsDialogOpen(false);
      toast({
        title: "Command added",
        description: "The command has been added successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to add command",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const deleteCommandMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/commands/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/commands', guildId] });
      toast({
        title: "Command deleted",
        description: "The command has been deleted successfully.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete command",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDeleteCommand = (id: number) => {
    setCommandToDelete(id);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (commandToDelete !== null) {
      deleteCommandMutation.mutate(commandToDelete);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;
    const usage = formData.get('usage') as string;
    const permission = formData.get('permission') as string;
    const enabled = formData.get('enabled') === 'on';
    
    if (!name || !description || !usage || !permission) {
      toast({
        title: "Invalid form data",
        description: "Please fill out all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    const commandData: InsertCommand = {
      guildId,
      name,
      description,
      usage,
      permission,
      enabled
    };
    
    addCommandMutation.mutate(commandData);
  };
  
  const getPermissionBadgeColor = (permission: string) => {
    switch (permission) {
      case 'admin':
        return 'bg-[#5865F2]';
      case 'mod':
        return 'bg-[#3BA55C]';
      case 'everyone':
      default:
        return 'bg-[#2C2F33]';
    }
  };
  
  const formatPermission = (permission: string) => {
    switch (permission) {
      case 'admin':
        return 'Admin';
      case 'mod':
        return 'Mod';
      case 'everyone':
      default:
        return 'Everyone';
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Commands" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Available Commands</h2>
            <Button 
              className="bg-[#5865F2] hover:bg-opacity-90 text-white"
              onClick={() => setIsDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Command
            </Button>
          </div>
          
          <div className="bg-[#2C2F33] rounded-lg shadow overflow-hidden">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
              </div>
            ) : commands.length === 0 ? (
              <div className="text-center py-12 text-[#99AAB5]">
                <p>No commands configured yet.</p>
                <Button 
                  className="mt-4 bg-[#5865F2] hover:bg-opacity-90 text-white"
                  onClick={() => setIsDialogOpen(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Command
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-[#23272A]">
                    <TableRow>
                      <TableHead className="text-[#99AAB5]">Command</TableHead>
                      <TableHead className="text-[#99AAB5]">Description</TableHead>
                      <TableHead className="text-[#99AAB5]">Usage</TableHead>
                      <TableHead className="text-[#99AAB5]">Permissions</TableHead>
                      <TableHead className="text-[#99AAB5] text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {commands.map((command) => (
                      <TableRow key={command.id} className="border-gray-700 hover:bg-[#2f3136]">
                        <TableCell className="font-medium">{command.name}</TableCell>
                        <TableCell>{command.description}</TableCell>
                        <TableCell className="text-xs text-[#99AAB5]">{command.usage}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 text-xs rounded-full ${getPermissionBadgeColor(command.permission)} text-white`}>
                            {formatPermission(command.permission)}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon">
                            <Edit2 className="h-4 w-4 text-[#99AAB5]" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </main>
      </div>
      
      {/* Add Command Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium text-white">Add Command</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name" className="text-sm font-medium text-[#99AAB5]">Command Name</Label>
                <Input 
                  id="name" 
                  name="name" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="!command"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="description" className="text-sm font-medium text-[#99AAB5]">Description</Label>
                <Input 
                  id="description" 
                  name="description" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="What the command does"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="usage" className="text-sm font-medium text-[#99AAB5]">Usage</Label>
                <Input 
                  id="usage" 
                  name="usage" 
                  className="bg-[#23272A] border-gray-700 text-white"
                  placeholder="!command [argument]"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="permission" className="text-sm font-medium text-[#99AAB5]">Required Permission</Label>
                <Select name="permission" defaultValue="everyone">
                  <SelectTrigger className="bg-[#23272A] border-gray-700 text-white">
                    <SelectValue placeholder="Select permission level" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#2C2F33] border-gray-700 text-white">
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="mod">Moderator</SelectItem>
                    <SelectItem value="everyone">Everyone</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="enabled" name="enabled" defaultChecked />
                <Label htmlFor="enabled" className="text-white">Enable command</Label>
              </div>
            </div>
            
            <DialogFooter className="bg-[#23272A] px-6 py-4 -mx-6 -mb-6 flex justify-end space-x-3">
              <Button 
                type="button" 
                variant="secondary" 
                onClick={() => setIsDialogOpen(false)}
                className="bg-[#2C2F33] hover:bg-opacity-80 text-white"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-[#5865F2] hover:bg-opacity-90 text-white"
                disabled={addCommandMutation.isPending}
              >
                {addCommandMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Command</AlertDialogTitle>
            <AlertDialogDescription className="text-[#99AAB5]">
              Are you sure you want to delete this command? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-[#36393F] text-white border-gray-700">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-[#ED4245] hover:bg-opacity-80"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
