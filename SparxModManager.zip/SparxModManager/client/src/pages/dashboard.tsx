import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import StatsCard from "@/components/stats-card";
import AutoRoleCard from "@/components/auto-role-card";
import ChannelPermissionsCard from "@/components/channel-permissions-card";
import LogsCard from "@/components/logs-card";
import { useQuery } from "@tanstack/react-query";
import { GuildStat } from "@shared/schema";
import { Users, Tag, MessageSquare, Shield } from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: stats, isLoading } = useQuery<GuildStat>({
    queryKey: ['/api/stats', guildId],
  });
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Dashboard" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          {/* Dashboard Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              title="Total Members"
              value={isLoading ? "..." : stats?.memberCount || 0}
              icon={<Users className="h-6 w-6 text-[#5865F2]" />}
              iconClassName="bg-[#5865F2]"
            />
            <StatsCard
              title="Active Roles"
              value={isLoading ? "..." : stats?.roleCount || 0}
              icon={<Tag className="h-6 w-6 text-[#3BA55C]" />}
              iconClassName="bg-[#3BA55C]"
            />
            <StatsCard
              title="Commands Today"
              value={isLoading ? "..." : stats?.commandsUsedToday || 0}
              icon={<MessageSquare className="h-6 w-6 text-[#FEE75C]" />}
              iconClassName="bg-[#FEE75C]"
            />
            <StatsCard
              title="Auto Assignments"
              value={isLoading ? "..." : stats?.autoAssignments || 0}
              icon={<Shield className="h-6 w-6 text-[#5865F2]" />}
              iconClassName="bg-[#5865F2]"
            />
          </div>

          {/* Main Features */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <AutoRoleCard />
            <ChannelPermissionsCard />
            <LogsCard />
          </div>
        </main>
      </div>
    </div>
  );
}
