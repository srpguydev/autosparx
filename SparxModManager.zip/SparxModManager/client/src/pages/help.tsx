import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { 
  MessageSquare, 
  Users, 
  Lock, 
  ClipboardList, 
  Settings, 
  Bot, 
  ExternalLink 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function Help() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Help & Documentation" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#2C2F33] text-white col-span-full md:col-span-2">
              <CardHeader>
                <CardTitle className="text-xl">SparxCore Bot Documentation</CardTitle>
                <CardDescription className="text-[#99AAB5]">
                  Learn how to use the SparxCore moderation bot in your Discord server
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-4">
                  <p>
                    SparxCore is a powerful moderation bot for Discord that automates role assignment, 
                    creates roles, and sets channel permissions based on usernames. This documentation
                    will help you understand how to use and configure the bot for your server.
                  </p>
                  
                  <div className="flex items-center gap-2 text-[#5865F2]">
                    <Bot className="h-5 w-5" />
                    <span className="font-semibold">Current Version: v1.2.0</span>
                  </div>
                  
                  <Separator className="bg-gray-700 my-2" />
                  
                  <h3 className="text-lg font-medium">Quick Navigation</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Button variant="outline" className="justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Commands Reference
                    </Button>
                    <Button variant="outline" className="justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <Users className="h-4 w-4 mr-2" />
                      Auto Role Guide
                    </Button>
                    <Button variant="outline" className="justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <Lock className="h-4 w-4 mr-2" />
                      Permissions Guide
                    </Button>
                    <Button variant="outline" className="justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <Settings className="h-4 w-4 mr-2" />
                      Configuration
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-[#2C2F33] text-white">
              <CardHeader>
                <CardTitle className="text-lg">Support</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-[#99AAB5]">
                    Need help? Join our support server or check out these resources:
                  </p>
                  
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 127.14 96.36" className="h-4 w-4 mr-2 fill-[#5865F2]">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z" />
                      </svg>
                      Join Support Server
                    </Button>
                    
                    <Button variant="outline" className="w-full justify-start border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Online Documentation
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="bg-[#2C2F33] text-white">
            <CardHeader>
              <CardTitle className="text-lg">Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1" className="border-b-gray-700">
                  <AccordionTrigger className="text-white hover:text-white">
                    How do auto roles work?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#99AAB5]">
                    <p>
                      Auto roles automatically assign roles to users based on their usernames. 
                      You can configure patterns that the bot will look for in usernames, and 
                      when a match is found, the corresponding role will be assigned to the user.
                    </p>
                    <p className="mt-2">
                      For example, if you set up a pattern for "dev" or "coder" for the "Developer" role,
                      any user with these terms in their username will automatically receive the Developer role.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-2" className="border-b-gray-700">
                  <AccordionTrigger className="text-white hover:text-white">
                    How do I set up channel permissions?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#99AAB5]">
                    <p>
                      Channel permissions allow you to control which roles can access specific channels.
                      You can set allow/deny permissions for each role in each channel from the Channel Permissions page.
                    </p>
                    <p className="mt-2">
                      You can also use the <code className="bg-[#23272A] p-1 rounded">!perms</code> command in Discord:
                      <br />
                      <code className="bg-[#23272A] p-1 rounded">!perms #channel @role allow/deny permission</code>
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-3" className="border-b-gray-700">
                  <AccordionTrigger className="text-white hover:text-white">
                    What permissions does the bot need?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#99AAB5]">
                    <p>
                      For full functionality, SparxCore needs the following permissions:
                    </p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>Manage Roles</li>
                      <li>Manage Channels</li>
                      <li>View Channels</li>
                      <li>Send Messages</li>
                      <li>Read Message History</li>
                      <li>Embed Links</li>
                    </ul>
                    <p className="mt-2">
                      The bot should be placed higher in the role hierarchy than any roles it needs to manage.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-4" className="border-b-gray-700">
                  <AccordionTrigger className="text-white hover:text-white">
                    How do I view bot logs?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#99AAB5]">
                    <p>
                      Bot logs can be viewed in two ways:
                    </p>
                    <ol className="list-decimal pl-5 mt-2 space-y-1">
                      <li>Through the Logs page in this dashboard</li>
                      <li>Using the <code className="bg-[#23272A] p-1 rounded">!logs [limit]</code> command in Discord</li>
                    </ol>
                    <p className="mt-2">
                      You can also set up a logging channel in Settings to have the bot automatically
                      post important events to a specific channel in your server.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-white hover:text-white">
                    Can I customize the bot prefix?
                  </AccordionTrigger>
                  <AccordionContent className="text-[#99AAB5]">
                    <p>
                      Yes, you can change the bot's command prefix in the Settings page.
                      The default prefix is "!", but you can change it to any character or short string.
                    </p>
                    <p className="mt-2">
                      After changing the prefix, all commands will need to use the new prefix instead of "!".
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
