import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import AutoRoleCard from "@/components/auto-role-card";
import NewRoleDialog from "@/components/new-role-dialog";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RolePattern } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AutoRoles() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [roleToDelete, setRoleToDelete] = useState<number | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: rolePatterns = [], isLoading } = useQuery<RolePattern[]>({
    queryKey: ['/api/role-patterns', guildId],
  });
  
  const deleteRoleMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/role-patterns/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/role-patterns', guildId] });
      toast({
        title: "Role pattern deleted",
        description: "The role pattern has been deleted successfully.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete role pattern",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleDeleteRole = (id: number) => {
    setRoleToDelete(id);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (roleToDelete !== null) {
      deleteRoleMutation.mutate(roleToDelete);
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Auto Roles" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Role Patterns</h2>
            <Button 
              className="bg-[#5865F2] hover:bg-opacity-90 text-white"
              onClick={() => setIsDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New Pattern
            </Button>
          </div>
          
          <div className="bg-[#2C2F33] rounded-lg shadow overflow-hidden">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
              </div>
            ) : rolePatterns.length === 0 ? (
              <div className="text-center py-12 text-[#99AAB5]">
                <p>No role patterns configured yet.</p>
                <Button 
                  className="mt-4 bg-[#5865F2] hover:bg-opacity-90 text-white"
                  onClick={() => setIsDialogOpen(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Pattern
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-[#23272A]">
                    <TableRow>
                      <TableHead className="text-[#99AAB5]">Role</TableHead>
                      <TableHead className="text-[#99AAB5]">Pattern</TableHead>
                      <TableHead className="text-[#99AAB5]">Pattern Type</TableHead>
                      <TableHead className="text-[#99AAB5]">Case Sensitive</TableHead>
                      <TableHead className="text-[#99AAB5] text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rolePatterns.map((pattern) => (
                      <TableRow key={pattern.id} className="border-gray-700 hover:bg-[#2f3136]">
                        <TableCell className="font-medium">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: pattern.roleColor || '#3498db' }}
                            ></div>
                            {pattern.roleName}
                          </div>
                        </TableCell>
                        <TableCell>{pattern.pattern}</TableCell>
                        <TableCell className="capitalize">{pattern.patternType}</TableCell>
                        <TableCell>{pattern.caseSensitive ? "Yes" : "No"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <Button variant="ghost" size="icon">
                              <Edit2 className="h-4 w-4 text-[#99AAB5]" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => handleDeleteRole(pattern.id)}
                            >
                              <Trash2 className="h-4 w-4 text-[#ED4245]" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </main>
      </div>
      
      <NewRoleDialog 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        guildId={guildId} 
      />
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="bg-[#2C2F33] text-white border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Delete Role Pattern</AlertDialogTitle>
            <AlertDialogDescription className="text-[#99AAB5]">
              Are you sure you want to delete this role pattern? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-[#36393F] text-white border-gray-700">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-[#ED4245] hover:bg-opacity-80"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
