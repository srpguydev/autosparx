import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { BotConfig, InsertBotConfig } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { Save, RefreshCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

export default function Settings() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Default guild ID (would be set from context or props in a real app)
  const guildId = "123456789012345678";
  
  const { data: config, isLoading } = useQuery<BotConfig>({
    queryKey: ['/api/bot-config', guildId],
  });
  
  const updateConfigMutation = useMutation({
    mutationFn: async (data: Partial<InsertBotConfig>) => {
      const res = await apiRequest('PUT', `/api/bot-config/${guildId}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bot-config', guildId] });
      toast({
        title: "Settings updated",
        description: "The bot configuration has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const prefix = formData.get('prefix') as string;
    const loggingChannelId = formData.get('loggingChannelId') as string;
    const adminRoleId = formData.get('adminRoleId') as string;
    const modRoleId = formData.get('modRoleId') as string;
    const active = formData.get('active') === 'on';
    
    if (!prefix) {
      toast({
        title: "Invalid form data",
        description: "Command prefix is required.",
        variant: "destructive",
      });
      return;
    }
    
    const configData: Partial<InsertBotConfig> = {
      prefix,
      loggingChannelId: loggingChannelId || undefined,
      adminRoleId: adminRoleId || undefined,
      modRoleId: modRoleId || undefined,
      active
    };
    
    updateConfigMutation.mutate(configData);
  };
  
  const handleReset = () => {
    if (config) {
      const form = document.getElementById('settings-form') as HTMLFormElement;
      
      if (form) {
        // Reset form values to original config
        const prefixInput = form.elements.namedItem('prefix') as HTMLInputElement;
        const loggingChannelIdInput = form.elements.namedItem('loggingChannelId') as HTMLInputElement;
        const adminRoleIdInput = form.elements.namedItem('adminRoleId') as HTMLInputElement;
        const modRoleIdInput = form.elements.namedItem('modRoleId') as HTMLInputElement;
        const activeSwitch = form.elements.namedItem('active') as HTMLInputElement;
        
        if (prefixInput) prefixInput.value = config.prefix;
        if (loggingChannelIdInput) loggingChannelIdInput.value = config.loggingChannelId || '';
        if (adminRoleIdInput) adminRoleIdInput.value = config.adminRoleId || '';
        if (modRoleIdInput) modRoleIdInput.value = config.modRoleId || '';
        if (activeSwitch) activeSwitch.checked = config.active;
        
        toast({
          title: "Settings reset",
          description: "Form values reset to original configuration.",
        });
      }
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#36393F] text-[#f6f6f7]">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden absolute top-4 left-4 z-50">
        <button 
          className="p-2 rounded-md text-[#f6f6f7] bg-[#2C2F33] focus:outline-none"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`${
          isMobileMenuOpen ? 'absolute inset-y-0 left-0 z-40' : 'hidden'
        } lg:block lg:static lg:z-auto w-64 flex-shrink-0`}
      >
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Settings" />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#36393F] px-4 py-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Bot Configuration</h2>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                className="border-gray-700 text-[#99AAB5] hover:text-white hover:bg-[#2C2F33]"
                onClick={handleReset}
              >
                <RefreshCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#5865F2]"></div>
            </div>
          ) : !config ? (
            <div className="text-center py-12 text-[#99AAB5] bg-[#2C2F33] rounded-lg">
              <p>No configuration found for this server.</p>
              <p className="mt-2">Create a new configuration to get started.</p>
            </div>
          ) : (
            <form id="settings-form" onSubmit={handleSubmit}>
              <Card className="bg-[#2C2F33] text-white mb-6">
                <CardHeader>
                  <CardTitle className="text-lg">General Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="prefix" className="text-sm font-medium text-[#99AAB5]">Command Prefix</Label>
                    <Input 
                      id="prefix" 
                      name="prefix" 
                      className="bg-[#23272A] border-gray-700 text-white"
                      placeholder="!"
                      defaultValue={config.prefix}
                      required
                    />
                    <p className="text-xs text-[#99AAB5]">The prefix used for bot commands (e.g., !help)</p>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="active" 
                      name="active" 
                      defaultChecked={config.active} 
                    />
                    <Label htmlFor="active" className="text-white">Bot Active</Label>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#2C2F33] text-white mb-6">
                <CardHeader>
                  <CardTitle className="text-lg">Logging Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="loggingChannelId" className="text-sm font-medium text-[#99AAB5]">Logging Channel ID</Label>
                    <Input 
                      id="loggingChannelId" 
                      name="loggingChannelId" 
                      className="bg-[#23272A] border-gray-700 text-white"
                      placeholder="123456789012345678"
                      defaultValue={config.loggingChannelId || ''}
                    />
                    <p className="text-xs text-[#99AAB5]">ID of the channel where bot logs will be sent</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#2C2F33] text-white mb-6">
                <CardHeader>
                  <CardTitle className="text-lg">Role Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-2">
                    <Label htmlFor="adminRoleId" className="text-sm font-medium text-[#99AAB5]">Admin Role ID</Label>
                    <Input 
                      id="adminRoleId" 
                      name="adminRoleId" 
                      className="bg-[#23272A] border-gray-700 text-white"
                      placeholder="123456789012345678"
                      defaultValue={config.adminRoleId || ''}
                    />
                    <p className="text-xs text-[#99AAB5]">Role ID for bot administrators</p>
                  </div>
                  
                  <Separator className="bg-gray-700 my-4" />
                  
                  <div className="grid gap-2">
                    <Label htmlFor="modRoleId" className="text-sm font-medium text-[#99AAB5]">Moderator Role ID</Label>
                    <Input 
                      id="modRoleId" 
                      name="modRoleId" 
                      className="bg-[#23272A] border-gray-700 text-white"
                      placeholder="123456789012345678"
                      defaultValue={config.modRoleId || ''}
                    />
                    <p className="text-xs text-[#99AAB5]">Role ID for bot moderators</p>
                  </div>
                </CardContent>
                <CardFooter className="bg-[#23272A] justify-end">
                  <Button 
                    type="submit" 
                    className="bg-[#5865F2] hover:bg-opacity-90 text-white"
                    disabled={updateConfigMutation.isPending}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {updateConfigMutation.isPending ? "Saving..." : "Save Settings"}
                  </Button>
                </CardFooter>
              </Card>
            </form>
          )}
        </main>
      </div>
    </div>
  );
}
