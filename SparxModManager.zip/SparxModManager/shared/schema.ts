import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (Discord users)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Bot configuration schema
export const botConfig = pgTable("bot_config", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  guildName: text("guild_name").notNull(),
  prefix: text("prefix").notNull().default("!"),
  loggingChannelId: text("logging_channel_id"),
  adminRoleId: text("admin_role_id"),
  modRoleId: text("mod_role_id"),
  active: boolean("active").notNull().default(true),
});

export const insertBotConfigSchema = createInsertSchema(botConfig).omit({
  id: true,
});

// Role patterns for auto-assignment
export const rolePatterns = pgTable("role_patterns", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  roleId: text("role_id").notNull(),
  roleName: text("role_name").notNull(),
  roleColor: text("role_color"),
  pattern: text("pattern").notNull(),
  patternType: text("pattern_type").notNull().default("contains"), // contains, startsWith, regex
  caseSensitive: boolean("case_sensitive").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRolePatternSchema = createInsertSchema(rolePatterns).omit({
  id: true,
  createdAt: true,
});

// Channel permissions
export const channelPermissions = pgTable("channel_permissions", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  channelId: text("channel_id").notNull(),
  channelName: text("channel_name").notNull(),
  roleId: text("role_id").notNull(),
  roleName: text("role_name").notNull(),
  allow: text("allow"), // Comma-separated permission flags
  deny: text("deny"), // Comma-separated permission flags
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertChannelPermissionSchema = createInsertSchema(channelPermissions).omit({
  id: true,
  createdAt: true,
});

// Bot activity logs
export const botLogs = pgTable("bot_logs", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  type: text("type").notNull(), // info, warning, error, success
  message: text("message").notNull(),
  userId: text("user_id"),
  username: text("username"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertBotLogSchema = createInsertSchema(botLogs).omit({
  id: true,
  createdAt: true,
});

// Commands
export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  usage: text("usage").notNull(),
  permission: text("permission").notNull().default("everyone"), // admin, mod, everyone
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCommandSchema = createInsertSchema(commands).omit({
  id: true,
  createdAt: true,
});

// Guild stats
export const guildStats = pgTable("guild_stats", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  memberCount: integer("member_count").notNull().default(0),
  roleCount: integer("role_count").notNull().default(0),
  commandsUsedToday: integer("commands_used_today").notNull().default(0),
  autoAssignments: integer("auto_assignments").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertGuildStatsSchema = createInsertSchema(guildStats).omit({
  id: true,
  updatedAt: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type BotConfig = typeof botConfig.$inferSelect;
export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;

export type RolePattern = typeof rolePatterns.$inferSelect;
export type InsertRolePattern = z.infer<typeof insertRolePatternSchema>;

export type ChannelPermission = typeof channelPermissions.$inferSelect;
export type InsertChannelPermission = z.infer<typeof insertChannelPermissionSchema>;

export type BotLog = typeof botLogs.$inferSelect;
export type InsertBotLog = z.infer<typeof insertBotLogSchema>;

export type Command = typeof commands.$inferSelect;
export type InsertCommand = z.infer<typeof insertCommandSchema>;

export type GuildStat = typeof guildStats.$inferSelect;
export type InsertGuildStat = z.infer<typeof insertGuildStatsSchema>;

// Sparx Maths related schemas
export const sparxAccounts = pgTable("sparx_accounts", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  schoolName: text("school_name").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  active: boolean("active").notNull().default(true),
  lastLogin: timestamp("last_login", { mode: 'date' }).defaultNow(),
  createdAt: timestamp("created_at", { mode: 'date' }).defaultNow(),
  homeworkType: text("homework_type").default("compulsory"), // compulsory or xpboost
});

export const insertSparxAccountSchema = createInsertSchema(sparxAccounts).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
});

export const sparxQuestions = pgTable("sparx_questions", {
  id: serial("id").primaryKey(),
  questionText: text("question_text").notNull(),
  questionHash: text("question_hash").notNull().unique(),
  questionImage: text("question_image"),
  answer: text("answer").notNull(),
  workingOut: text("working_out"),
  createdAt: timestamp("created_at", { mode: 'date' }).defaultNow(),
});

export const insertSparxQuestionSchema = createInsertSchema(sparxQuestions).omit({
  id: true,
  createdAt: true,
});

export const sparxSessions = pgTable("sparx_sessions", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => sparxAccounts.id).notNull(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  startTime: timestamp("start_time", { mode: 'date' }).defaultNow(),
  endTime: timestamp("end_time", { mode: 'date' }),
  questionsAnswered: integer("questions_answered").notNull().default(0),
  status: text("status").notNull().default("active"),
});

export const insertSparxSessionSchema = createInsertSchema(sparxSessions).omit({
  id: true,
  startTime: true,
  endTime: true,
  questionsAnswered: true,
  status: true,
});

// Define relationships between tables
// Note: Relations are defined but will be used once we implement full Drizzle ORM queries
// For now, we'll use simple queries with joins when needed
/*
export const sparxAccountsRelations = relations(sparxAccounts, ({ many }) => ({
  sessions: many(sparxSessions),
}));

export const sparxSessionsRelations = relations(sparxSessions, ({ one }) => ({
  account: one(sparxAccounts, {
    fields: [sparxSessions.accountId],
    references: [sparxAccounts.id],
  }),
}));
*/

export type SparxAccount = typeof sparxAccounts.$inferSelect;
export type InsertSparxAccount = z.infer<typeof insertSparxAccountSchema>;

export type SparxQuestion = typeof sparxQuestions.$inferSelect;
export type InsertSparxQuestion = z.infer<typeof insertSparxQuestionSchema>;

export type SparxSession = typeof sparxSessions.$inferSelect;
export type InsertSparxSession = z.infer<typeof insertSparxSessionSchema>;
