import { 
  users, type User, type InsertUser,
  botConfig, type BotConfig, type InsertBotConfig,
  rolePatterns, type RolePattern, type InsertRolePattern,
  channelPermissions, type ChannelPermission, type InsertChannelPermission,
  botLogs, type BotLog, type InsertBotLog,
  commands, type Command, type InsertCommand,
  guildStats, type GuildStat, type InsertGuildStat
} from "@shared/schema";
import { db } from './db';
import { eq, and, desc, sql } from 'drizzle-orm';

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Bot config methods
  getBotConfig(guildId: string): Promise<BotConfig | undefined>;
  createBotConfig(config: InsertBotConfig): Promise<BotConfig>;
  updateBotConfig(guildId: string, config: Partial<InsertBotConfig>): Promise<BotConfig | undefined>;
  
  // Role pattern methods
  getRolePatterns(guildId: string): Promise<RolePattern[]>;
  getRolePattern(id: number): Promise<RolePattern | undefined>;
  createRolePattern(pattern: InsertRolePattern): Promise<RolePattern>;
  updateRolePattern(id: number, pattern: Partial<InsertRolePattern>): Promise<RolePattern | undefined>;
  deleteRolePattern(id: number): Promise<boolean>;
  
  // Channel permission methods
  getChannelPermissions(guildId: string): Promise<ChannelPermission[]>;
  getChannelPermissionsByChannel(guildId: string, channelId: string): Promise<ChannelPermission[]>;
  createChannelPermission(permission: InsertChannelPermission): Promise<ChannelPermission>;
  updateChannelPermission(id: number, permission: Partial<InsertChannelPermission>): Promise<ChannelPermission | undefined>;
  deleteChannelPermission(id: number): Promise<boolean>;
  
  // Bot logs methods
  getBotLogs(guildId: string, limit?: number): Promise<BotLog[]>;
  createBotLog(log: InsertBotLog): Promise<BotLog>;
  
  // Command methods
  getCommands(guildId: string): Promise<Command[]>;
  getCommand(guildId: string, name: string): Promise<Command | undefined>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined>;
  deleteCommand(id: number): Promise<boolean>;
  
  // Guild stats methods
  getGuildStats(guildId: string): Promise<GuildStat | undefined>;
  updateGuildStats(guildId: string, stats: Partial<InsertGuildStat>): Promise<GuildStat | undefined>;
  incrementCommandUsage(guildId: string): Promise<GuildStat | undefined>;
  incrementAutoAssignments(guildId: string): Promise<GuildStat | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private botConfigs: Map<string, BotConfig>;
  private rolePatterns: Map<number, RolePattern>;
  private channelPermissions: Map<number, ChannelPermission>;
  private botLogs: Map<number, BotLog>;
  private commands: Map<number, Command>;
  private guildStats: Map<string, GuildStat>;
  
  private currentUserId: number;
  private currentRolePatternId: number;
  private currentChannelPermissionId: number;
  private currentBotLogId: number;
  private currentCommandId: number;
  private currentGuildStatId: number;

  constructor() {
    this.users = new Map();
    this.botConfigs = new Map();
    this.rolePatterns = new Map();
    this.channelPermissions = new Map();
    this.botLogs = new Map();
    this.commands = new Map();
    this.guildStats = new Map();
    
    this.currentUserId = 1;
    this.currentRolePatternId = 1;
    this.currentChannelPermissionId = 1;
    this.currentBotLogId = 1;
    this.currentCommandId = 1;
    this.currentGuildStatId = 1;
    
    // Initialize with some default commands
    this.initializeDefaultCommands();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Bot config methods
  async getBotConfig(guildId: string): Promise<BotConfig | undefined> {
    return this.botConfigs.get(guildId);
  }

  async createBotConfig(config: InsertBotConfig): Promise<BotConfig> {
    const botConfig: BotConfig = { ...config, id: 1 };
    this.botConfigs.set(config.guildId, botConfig);
    return botConfig;
  }

  async updateBotConfig(guildId: string, config: Partial<InsertBotConfig>): Promise<BotConfig | undefined> {
    const existingConfig = this.botConfigs.get(guildId);
    if (!existingConfig) return undefined;
    
    const updatedConfig = { ...existingConfig, ...config };
    this.botConfigs.set(guildId, updatedConfig);
    return updatedConfig;
  }

  // Role pattern methods
  async getRolePatterns(guildId: string): Promise<RolePattern[]> {
    return Array.from(this.rolePatterns.values()).filter(
      (pattern) => pattern.guildId === guildId
    );
  }

  async getRolePattern(id: number): Promise<RolePattern | undefined> {
    return this.rolePatterns.get(id);
  }

  async createRolePattern(pattern: InsertRolePattern): Promise<RolePattern> {
    const id = this.currentRolePatternId++;
    const rolePattern: RolePattern = { 
      ...pattern, 
      id, 
      createdAt: new Date() 
    };
    this.rolePatterns.set(id, rolePattern);
    return rolePattern;
  }

  async updateRolePattern(id: number, pattern: Partial<InsertRolePattern>): Promise<RolePattern | undefined> {
    const existingPattern = this.rolePatterns.get(id);
    if (!existingPattern) return undefined;
    
    const updatedPattern = { ...existingPattern, ...pattern };
    this.rolePatterns.set(id, updatedPattern);
    return updatedPattern;
  }

  async deleteRolePattern(id: number): Promise<boolean> {
    return this.rolePatterns.delete(id);
  }

  // Channel permission methods
  async getChannelPermissions(guildId: string): Promise<ChannelPermission[]> {
    return Array.from(this.channelPermissions.values()).filter(
      (permission) => permission.guildId === guildId
    );
  }

  async getChannelPermissionsByChannel(guildId: string, channelId: string): Promise<ChannelPermission[]> {
    return Array.from(this.channelPermissions.values()).filter(
      (permission) => permission.guildId === guildId && permission.channelId === channelId
    );
  }

  async createChannelPermission(permission: InsertChannelPermission): Promise<ChannelPermission> {
    const id = this.currentChannelPermissionId++;
    const channelPermission: ChannelPermission = { 
      ...permission, 
      id, 
      createdAt: new Date() 
    };
    this.channelPermissions.set(id, channelPermission);
    return channelPermission;
  }

  async updateChannelPermission(id: number, permission: Partial<InsertChannelPermission>): Promise<ChannelPermission | undefined> {
    const existingPermission = this.channelPermissions.get(id);
    if (!existingPermission) return undefined;
    
    const updatedPermission = { ...existingPermission, ...permission };
    this.channelPermissions.set(id, updatedPermission);
    return updatedPermission;
  }

  async deleteChannelPermission(id: number): Promise<boolean> {
    return this.channelPermissions.delete(id);
  }

  // Bot logs methods
  async getBotLogs(guildId: string, limit: number = 100): Promise<BotLog[]> {
    return Array.from(this.botLogs.values())
      .filter((log) => log.guildId === guildId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createBotLog(log: InsertBotLog): Promise<BotLog> {
    const id = this.currentBotLogId++;
    const botLog: BotLog = { 
      ...log, 
      id, 
      createdAt: new Date() 
    };
    this.botLogs.set(id, botLog);
    return botLog;
  }

  // Command methods
  async getCommands(guildId: string): Promise<Command[]> {
    return Array.from(this.commands.values()).filter(
      (command) => command.guildId === guildId
    );
  }

  async getCommand(guildId: string, name: string): Promise<Command | undefined> {
    return Array.from(this.commands.values()).find(
      (command) => command.guildId === guildId && command.name === name
    );
  }

  async createCommand(command: InsertCommand): Promise<Command> {
    const id = this.currentCommandId++;
    const newCommand: Command = { 
      ...command, 
      id, 
      createdAt: new Date() 
    };
    this.commands.set(id, newCommand);
    return newCommand;
  }

  async updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined> {
    const existingCommand = this.commands.get(id);
    if (!existingCommand) return undefined;
    
    const updatedCommand = { ...existingCommand, ...command };
    this.commands.set(id, updatedCommand);
    return updatedCommand;
  }

  async deleteCommand(id: number): Promise<boolean> {
    return this.commands.delete(id);
  }

  // Guild stats methods
  async getGuildStats(guildId: string): Promise<GuildStat | undefined> {
    return this.guildStats.get(guildId);
  }

  async updateGuildStats(guildId: string, stats: Partial<InsertGuildStat>): Promise<GuildStat | undefined> {
    const existingStats = this.guildStats.get(guildId);
    
    if (existingStats) {
      const updatedStats = { 
        ...existingStats, 
        ...stats, 
        updatedAt: new Date() 
      };
      this.guildStats.set(guildId, updatedStats);
      return updatedStats;
    } else {
      const id = this.currentGuildStatId++;
      const newStats: GuildStat = { 
        id,
        guildId,
        memberCount: stats.memberCount || 0,
        roleCount: stats.roleCount || 0,
        commandsUsedToday: stats.commandsUsedToday || 0,
        autoAssignments: stats.autoAssignments || 0,
        updatedAt: new Date()
      };
      this.guildStats.set(guildId, newStats);
      return newStats;
    }
  }

  async incrementCommandUsage(guildId: string): Promise<GuildStat | undefined> {
    const existingStats = this.guildStats.get(guildId);
    
    if (existingStats) {
      const updatedStats = { 
        ...existingStats,
        commandsUsedToday: existingStats.commandsUsedToday + 1,
        updatedAt: new Date() 
      };
      this.guildStats.set(guildId, updatedStats);
      return updatedStats;
    }
    
    return undefined;
  }

  async incrementAutoAssignments(guildId: string): Promise<GuildStat | undefined> {
    const existingStats = this.guildStats.get(guildId);
    
    if (existingStats) {
      const updatedStats = { 
        ...existingStats,
        autoAssignments: existingStats.autoAssignments + 1,
        updatedAt: new Date() 
      };
      this.guildStats.set(guildId, updatedStats);
      return updatedStats;
    }
    
    return undefined;
  }

  // Initialize some default commands for demonstration
  private initializeDefaultCommands() {
    const defaultGuildId = "123456789012345678";
    const defaultCommands: InsertCommand[] = [
      {
        guildId: defaultGuildId,
        name: "!role",
        description: "Manage server roles",
        usage: "!role [add/remove] [user] [role]",
        permission: "admin",
        enabled: true
      },
      {
        guildId: defaultGuildId,
        name: "!perms",
        description: "Set channel permissions",
        usage: "!perms [channel] [role] [allow/deny] [perm]",
        permission: "admin",
        enabled: true
      },
      {
        guildId: defaultGuildId,
        name: "!logs",
        description: "View bot activity logs",
        usage: "!logs [limit]",
        permission: "mod",
        enabled: true
      },
      {
        guildId: defaultGuildId,
        name: "!help",
        description: "Show help information",
        usage: "!help [command]",
        permission: "everyone",
        enabled: true
      }
    ];

    defaultCommands.forEach(command => {
      this.createCommand(command);
    });
    
    // Add some default stats
    this.updateGuildStats(defaultGuildId, {
      memberCount: 842,
      roleCount: 16,
      commandsUsedToday: 24,
      autoAssignments: 132
    });
    
    // Add some default role patterns
    const defaultRolePatterns: InsertRolePattern[] = [
      {
        guildId: defaultGuildId,
        roleId: "111111111111111111",
        roleName: "Developer",
        roleColor: "#3498db",
        pattern: "dev,coder",
        patternType: "contains",
        caseSensitive: false
      },
      {
        guildId: defaultGuildId,
        roleId: "222222222222222222",
        roleName: "Moderator",
        roleColor: "#2ecc71",
        pattern: "mod,admin",
        patternType: "contains",
        caseSensitive: false
      },
      {
        guildId: defaultGuildId,
        roleId: "333333333333333333",
        roleName: "Artist",
        roleColor: "#9b59b6",
        pattern: "art,design",
        patternType: "contains",
        caseSensitive: false
      }
    ];
    
    defaultRolePatterns.forEach(pattern => {
      this.createRolePattern(pattern);
    });
    
    // Add some sample logs
    const sampleLogs: InsertBotLog[] = [
      {
        guildId: defaultGuildId,
        type: "success",
        message: "Role 'Developer' assigned to user 'coder_123'",
        userId: "444444444444444444",
        username: "coder_123"
      },
      {
        guildId: defaultGuildId,
        type: "info",
        message: "Command '!help' executed by user 'GamingMaster'",
        userId: "555555555555555555",
        username: "GamingMaster"
      },
      {
        guildId: defaultGuildId,
        type: "info",
        message: "Updated permissions for channel 'announcements'",
        userId: "666666666666666666",
        username: "AdminUser"
      },
      {
        guildId: defaultGuildId,
        type: "error",
        message: "Error occurred while creating role 'Guest'",
        userId: "666666666666666666",
        username: "AdminUser"
      },
      {
        guildId: defaultGuildId,
        type: "success",
        message: "Bot restarted successfully"
      }
    ];
    
    sampleLogs.forEach(log => {
      this.createBotLog(log);
    });
  }
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Bot config methods
  async getBotConfig(guildId: string): Promise<BotConfig | undefined> {
    const [config] = await db.select().from(botConfig).where(eq(botConfig.guildId, guildId));
    return config;
  }
  
  async createBotConfig(config: InsertBotConfig): Promise<BotConfig> {
    const [createdConfig] = await db.insert(botConfig).values(config).returning();
    return createdConfig;
  }
  
  async updateBotConfig(guildId: string, config: Partial<InsertBotConfig>): Promise<BotConfig | undefined> {
    const [updatedConfig] = await db
      .update(botConfig)
      .set(config)
      .where(eq(botConfig.guildId, guildId))
      .returning();
    
    return updatedConfig;
  }
  
  // Role pattern methods
  async getRolePatterns(guildId: string): Promise<RolePattern[]> {
    return db.select().from(rolePatterns).where(eq(rolePatterns.guildId, guildId));
  }
  
  async getRolePattern(id: number): Promise<RolePattern | undefined> {
    const [pattern] = await db.select().from(rolePatterns).where(eq(rolePatterns.id, id));
    return pattern;
  }
  
  async createRolePattern(pattern: InsertRolePattern): Promise<RolePattern> {
    const [createdPattern] = await db
      .insert(rolePatterns)
      .values({ ...pattern })
      .returning();
    
    return createdPattern;
  }
  
  async updateRolePattern(id: number, pattern: Partial<InsertRolePattern>): Promise<RolePattern | undefined> {
    const [updatedPattern] = await db
      .update(rolePatterns)
      .set(pattern)
      .where(eq(rolePatterns.id, id))
      .returning();
    
    return updatedPattern;
  }
  
  async deleteRolePattern(id: number): Promise<boolean> {
    const result = await db
      .delete(rolePatterns)
      .where(eq(rolePatterns.id, id))
      .returning({ id: rolePatterns.id });
    
    return result.length > 0;
  }
  
  // Channel permission methods
  async getChannelPermissions(guildId: string): Promise<ChannelPermission[]> {
    return db
      .select()
      .from(channelPermissions)
      .where(eq(channelPermissions.guildId, guildId));
  }
  
  async getChannelPermissionsByChannel(guildId: string, channelId: string): Promise<ChannelPermission[]> {
    return db
      .select()
      .from(channelPermissions)
      .where(
        and(
          eq(channelPermissions.guildId, guildId),
          eq(channelPermissions.channelId, channelId)
        )
      );
  }
  
  async createChannelPermission(permission: InsertChannelPermission): Promise<ChannelPermission> {
    const [createdPermission] = await db
      .insert(channelPermissions)
      .values(permission)
      .returning();
    
    return createdPermission;
  }
  
  async updateChannelPermission(id: number, permission: Partial<InsertChannelPermission>): Promise<ChannelPermission | undefined> {
    const [updatedPermission] = await db
      .update(channelPermissions)
      .set(permission)
      .where(eq(channelPermissions.id, id))
      .returning();
    
    return updatedPermission;
  }
  
  async deleteChannelPermission(id: number): Promise<boolean> {
    const result = await db
      .delete(channelPermissions)
      .where(eq(channelPermissions.id, id))
      .returning({ id: channelPermissions.id });
    
    return result.length > 0;
  }
  
  // Bot logs methods
  async getBotLogs(guildId: string, limit: number = 100): Promise<BotLog[]> {
    return db
      .select()
      .from(botLogs)
      .where(eq(botLogs.guildId, guildId))
      .orderBy(desc(botLogs.createdAt))
      .limit(limit);
  }
  
  async createBotLog(log: InsertBotLog): Promise<BotLog> {
    const [createdLog] = await db
      .insert(botLogs)
      .values(log)
      .returning();
    
    return createdLog;
  }
  
  // Command methods
  async getCommands(guildId: string): Promise<Command[]> {
    return db
      .select()
      .from(commands)
      .where(eq(commands.guildId, guildId));
  }
  
  async getCommand(guildId: string, name: string): Promise<Command | undefined> {
    const [command] = await db
      .select()
      .from(commands)
      .where(
        and(
          eq(commands.guildId, guildId),
          eq(commands.name, name)
        )
      );
    
    return command;
  }
  
  async createCommand(command: InsertCommand): Promise<Command> {
    const [createdCommand] = await db
      .insert(commands)
      .values(command)
      .returning();
    
    return createdCommand;
  }
  
  async updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined> {
    const [updatedCommand] = await db
      .update(commands)
      .set(command)
      .where(eq(commands.id, id))
      .returning();
    
    return updatedCommand;
  }
  
  async deleteCommand(id: number): Promise<boolean> {
    const result = await db
      .delete(commands)
      .where(eq(commands.id, id))
      .returning({ id: commands.id });
    
    return result.length > 0;
  }
  
  // Guild stats methods
  async getGuildStats(guildId: string): Promise<GuildStat | undefined> {
    const [stats] = await db
      .select()
      .from(guildStats)
      .where(eq(guildStats.guildId, guildId));
    
    return stats;
  }
  
  async updateGuildStats(guildId: string, stats: Partial<InsertGuildStat>): Promise<GuildStat | undefined> {
    // Check if stats exist first
    const existingStats = await this.getGuildStats(guildId);
    
    if (existingStats) {
      // Update existing stats
      const [updatedStats] = await db
        .update(guildStats)
        .set({
          ...stats,
          updatedAt: new Date()
        })
        .where(eq(guildStats.guildId, guildId))
        .returning();
      
      return updatedStats;
    } else {
      // Create new stats
      const [newStats] = await db
        .insert(guildStats)
        .values({
          guildId,
          memberCount: stats.memberCount || 0,
          roleCount: stats.roleCount || 0,
          commandsUsedToday: stats.commandsUsedToday || 0,
          autoAssignments: stats.autoAssignments || 0,
          updatedAt: new Date()
        })
        .returning();
      
      return newStats;
    }
  }
  
  async incrementCommandUsage(guildId: string): Promise<GuildStat | undefined> {
    const [stats] = await db
      .update(guildStats)
      .set({
        commandsUsedToday: sql`${guildStats.commandsUsedToday} + 1`,
        updatedAt: new Date()
      })
      .where(eq(guildStats.guildId, guildId))
      .returning();
    
    return stats;
  }
  
  async incrementAutoAssignments(guildId: string): Promise<GuildStat | undefined> {
    const [stats] = await db
      .update(guildStats)
      .set({
        autoAssignments: sql`${guildStats.autoAssignments} + 1`,
        updatedAt: new Date()
      })
      .where(eq(guildStats.guildId, guildId))
      .returning();
    
    return stats;
  }
  
  async initializeDefaultCommands(guildId: string): Promise<void> {
    const defaultCommands = [
      {
        guildId,
        name: "!role",
        description: "Manage server roles",
        usage: "!role [add/remove] [user] [role]",
        permission: "admin",
        enabled: true
      },
      {
        guildId,
        name: "!perms",
        description: "Set channel permissions",
        usage: "!perms [channel] [role] [allow/deny] [perm]",
        permission: "admin",
        enabled: true
      },
      {
        guildId,
        name: "!logs",
        description: "View bot activity logs",
        usage: "!logs [limit]",
        permission: "mod",
        enabled: true
      },
      {
        guildId,
        name: "!help",
        description: "Show help information",
        usage: "!help [command]",
        permission: "everyone",
        enabled: true
      }
    ];
    
    for (const command of defaultCommands) {
      await this.createCommand(command);
    }
  }
}

// Create a storage instance
export const storage = new DatabaseStorage();

// Set the storage instance in the logger to avoid circular dependencies
import { setStorage } from './logger';
setStorage(storage);
