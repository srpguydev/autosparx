import { Browser as PuppeteerBrowser, Page } from 'puppeteer-core';
import puppeteer from 'puppeteer-core';

type Browser = PuppeteerBrowser;
import { Solver } from '2captcha';
import { logger } from '../logger';
import fs from 'fs-extra';
import path from 'path';
import crypto from 'crypto';
import { execSync } from 'child_process';

/**
 * Class for managing the browser for Sparx Maths automation
 */
export class SparxBrowser {
  private browser: Browser | null = null;
  private page: Page | null = null;
  private solver: Solver | null = null;
  private readonly userAgentString = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';
  private readonly screenshotsDir = path.join(process.cwd(), 'screenshots');
  private readonly cookiesDir = path.join(process.cwd(), 'cookies');
  private readonly baseUrl = 'https://sparxmaths.uk/';
  private readonly loginUrl = 'https://auth.sparxmaths.uk/';
  
  /**
   * Constructor for SparxBrowser
   * @param captchaApiKey The API key for 2captcha service
   */
  constructor(captchaApiKey?: string) {
    // Initialize directories
    fs.ensureDirSync(this.screenshotsDir);
    fs.ensureDirSync(this.cookiesDir);
    
    // Initialize captcha solver if API key is provided
    const apiKey = captchaApiKey || process.env.CAPTCHA_API_KEY;
    if (apiKey) {
      logger.info('Initializing 2CAPTCHA solver with provided API key');
      this.solver = new Solver(apiKey);
    } else {
      logger.warn('No 2CAPTCHA API key provided, captchas will not be automatically solved');
    }
  }
  
  /**
   * Find the path to the system Chromium browser
   */
  private findChromiumPath(): string {
    try {
      // Check if we're on Replit
      if (process.env.REPL_ID) {
        logger.info('Detected Replit environment');
        // Try common paths for Chrome on Replit
        const replitChromePaths = [
          '/nix/store/chrome-unstable/bin/google-chrome-unstable',
          '/nix/store/chrome/bin/google-chrome',
          '/usr/bin/chromium-browser',
          '/usr/bin/google-chrome'
        ];
        
        for (const path of replitChromePaths) {
          try {
            if (fs.existsSync(path)) {
              logger.info(`Found Chrome on Replit at: ${path}`);
              return path;
            }
          } catch (e) {
            // Continue checking other paths
          }
        }
      }
      
      // Try to find the system path to Chromium using which command
      const chromiumPath = execSync('which chromium-browser || which chromium || which google-chrome-stable || which google-chrome').toString().trim();
      if (chromiumPath) {
        logger.info(`Found system Chrome at: ${chromiumPath}`);
        return chromiumPath;
      }
    } catch (error) {
      // If all attempts fail, log the error
      logger.warn('Could not find system Chromium or Chrome executables');
      return '';
    }
    
    // Default return empty string if no browser found
    return '';
  }

  /**
   * Launch the browser
   */
  async launch(): Promise<Browser> {
    try {
      // Find the system browser
      const executablePath = this.findChromiumPath();
      
      const options: any = {
        headless: 'new', // Use the new headless mode
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-blink-features=AutomationControlled', // Hide automation
          '--disable-features=IsolateOrigins,site-per-process', // Needed for some captchas
          '--disable-web-security', // Occasionally needed for navigation
          '--allow-running-insecure-content',
          '--window-size=1920,1080', // More common screen size
          '--user-agent=' + this.userAgentString
        ],
        ignoreHTTPSErrors: true,
        defaultViewport: {
          width: 1920,
          height: 1080
        }
      };
      
      // Add the executable path if we found a system browser
      if (executablePath) {
        options.executablePath = executablePath;
      }
      
      const browser = await puppeteer.launch(options);
      this.browser = browser;
      
      logger.info('Browser launched successfully');
      return browser;
    } catch (error) {
      logger.error(`Failed to launch browser: ${error}`);
      throw error;
    }
  }
  
  /**
   * Close the browser
   */
  async close(): Promise<void> {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
      logger.info('Browser closed');
    }
  }
  
  /**
   * Create a new page
   */
  async newPage(): Promise<Page> {
    if (!this.browser) {
      await this.launch();
    }
    
    this.page = await this.browser!.newPage();
    
    // Set user agent and viewport
    await this.page.setUserAgent(this.userAgentString);
    await this.page.setViewport({ width: 1920, height: 1080 });
    
    // Set extra HTTP headers to appear more like a real browser
    await this.page.setExtraHTTPHeaders({
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br'
    });
    
    // Add event listeners for console, dialog, and error events
    this.page.on('console', message => {
      const text = message.text();
      
      // Use a safer approach to check message type
      try {
        if (message.type() === 'error') {
          logger.error(`Browser console error: ${text}`);
        } else {
          // Log all other messages as info to avoid type comparison issues
          logger.info(`Browser console: ${text}`);
        }
      } catch (e) {
        logger.info(`Browser console message: ${text}`);
      }
    });
    
    this.page.on('dialog', async dialog => {
      logger.warn(`Browser dialog: ${dialog.message()}`);
      await dialog.dismiss();
    });
    
    this.page.on('error', error => {
      logger.error(`Browser page error: ${error.message}`);
    });
    
    return this.page;
  }
  
  /**
   * Navigate to a URL
   * @param url The URL to navigate to
   */
  async goto(url: string): Promise<void> {
    if (!this.page) {
      await this.newPage();
    }
    
    try {
      const response = await this.page!.goto(url, {
        waitUntil: 'networkidle2',
        timeout: 60000
      });
      
      if (!response) {
        throw new Error('No response received from page navigation');
      }
      
      const status = response.status();
      if (status >= 400) {
        throw new Error(`Page returned status code ${status}`);
      }
      
      logger.info(`Navigated to ${url}`);
      
      // Check for Cloudflare challenge
      await this.handleCloudflareChallenge();
    } catch (error) {
      logger.error(`Failed to navigate to ${url}: ${error}`);
      await this.takeScreenshot('navigation-error');
      throw error;
    }
  }
  
  /**
   * Handle Cloudflare challenge if present
   */
  private async handleCloudflareChallenge(): Promise<void> {
    if (!this.page) return;
    
    // Check if we're on a Cloudflare challenge page
    const cloudflareDetected = await this.page.evaluate(() => {
      return document.querySelector('#cf-please-wait') !== null ||
             document.querySelector('.cf-browser-verification') !== null ||
             document.querySelector('#cf-spinner') !== null ||
             document.querySelector('.cf-error-code') !== null ||
             document.querySelector('iframe[src*="challenges.cloudflare.com"]') !== null;
    });
    
    if (cloudflareDetected) {
      logger.warn('Cloudflare challenge detected, waiting for resolution...');
      await this.takeScreenshot('cloudflare-challenge');
      
      // Inject the Turnstile interceptor script
      await this.page.evaluate(() => {
        const script = document.createElement('script');
        script.textContent = `
          const i = setInterval(() => {
            if (window.turnstile) {
              clearInterval(i);
              console.log("Intercepted Turnstile!");
              window.turnstile.render = (a, b) => {
                let p = {
                  type: "TurnstileTaskProxyless",
                  websiteKey: b.sitekey,
                  websiteURL: window.location.href,
                  data: b.cData,
                  pagedata: b.chlPageData,
                  action: b.action,
                  userAgent: navigator.userAgent
                };
                console.log("TURNSTILE_TASK:" + JSON.stringify(p));
                window.tsCallback = b.callback;
                return 'foo';
              };
            }
          }, 10);
        `;
        document.head.appendChild(script);
      });
      
      logger.info('Injected Turnstile interceptor script');
      
      // Wait for the Turnstile task to be logged
      try {
        await this.page.waitForFunction(() => {
          return document.body && document.body.textContent ? 
                 document.body.textContent.includes('TURNSTILE_TASK:') : false;
        }, { timeout: 10000 });
        
        // Extract the Turnstile task details
        const turnstileTask = await this.page.evaluate(() => {
          if (!document.body || !document.body.textContent) return null;
          const match = document.body.textContent.match(/TURNSTILE_TASK:({.*})/);
          return match ? match[1] : null;
        });
        
        if (turnstileTask) {
          logger.info(`Detected Turnstile task: ${turnstileTask}`);
          // Here we would typically send this to a solving service
          // For now, we'll just log it
        }
      } catch (error) {
        logger.warn('No Turnstile task detected within timeout');
      }
      
      // Wait for Cloudflare to resolve (may take time)
      await this.page.waitForNavigation({
        waitUntil: 'networkidle2',
        timeout: 60000
      }).catch(() => {
        logger.warn('Cloudflare challenge navigation timeout');
      });
      
      // Check for CAPTCHA and solve if 2captcha API key is available
      const captchaDetected = await this.page.evaluate(() => {
        return document.querySelector('#cf-hcaptcha-container') !== null ||
               document.querySelector('iframe[src*="hcaptcha"]') !== null ||
               document.querySelector('iframe[src*="recaptcha"]') !== null;
      });
      
      if (captchaDetected && this.solver) {
        await this.solveCaptcha();
      }
      
      // Monitor console logs for our TURNSTILE_TASK marker
      this.page.on('console', async (msg) => {
        const text = msg.text();
        if (text.includes('TURNSTILE_TASK:')) {
          try {
            const taskJson = text.split('TURNSTILE_TASK:')[1];
            const task = JSON.parse(taskJson);
            logger.info(`Detected Turnstile task via console: ${JSON.stringify(task)}`);
            
            // Here we would send the task to a solving service
            // For demonstration, simulate getting a token
            const token = "simulated_turnstile_token";
            
            // Submit the token
            if (this.page) {
              await this.page.evaluate((token) => {
                // Use the callback function that was stored when intercepting Turnstile
                if ((window as any).tsCallback) {
                  (window as any).tsCallback(token);
                  console.log("Applied Turnstile token");
                }
              }, token);
            }
          } catch (error) {
            logger.error(`Error processing Turnstile task: ${error}`);
          }
        }
      });
      
      // Wait for final navigation after challenge
      await this.page.waitForNavigation({
        waitUntil: 'networkidle2',
        timeout: 30000
      }).catch(() => {
        logger.warn('Post-Cloudflare navigation timeout');
      });
      
      logger.info('Cloudflare challenge handled');
    }
  }
  
  /**
   * Solve CAPTCHA if present
   */
  private async solveCaptcha(): Promise<void> {
    if (!this.page || !this.solver) return;
    
    try {
      logger.info('Attempting to solve CAPTCHA...');
      
      // Take screenshot for debugging
      await this.takeScreenshot('captcha-detected');
      
      // Check for hCaptcha
      const hcaptchaSiteKey = await this.page.evaluate(() => {
        const iframe = document.querySelector('iframe[src*="hcaptcha"]');
        if (iframe) {
          const src = iframe.getAttribute('src') || '';
          const siteKeyMatch = src.match(/sitekey=([^&]+)/);
          return siteKeyMatch ? siteKeyMatch[1] : null;
        }
        return null;
      });
      
      if (hcaptchaSiteKey) {
        const pageUrl = this.page.url();
        
        // Solve hCaptcha
        const captchaResult = await this.solver.hcaptcha(hcaptchaSiteKey, pageUrl);
        
        // Input the captcha result
        await this.page.evaluate((token) => {
          // Find the appropriate callback function or input for the token
          (window as any).hcaptchaCallback?.(token);
          
          // Try to find an input field to paste the token
          const inputs = Array.from(document.querySelectorAll('input[name="h-captcha-response"]'));
          if (inputs.length > 0) {
            (inputs[0] as HTMLInputElement).value = token;
          }
          
          // Try to submit the form
          const forms = Array.from(document.querySelectorAll('form'));
          forms.forEach(form => {
            if (form.querySelector('iframe[src*="hcaptcha"]')) {
              form.submit();
            }
          });
        }, captchaResult.data);
        
        logger.info('hCaptcha solved successfully');
      }
      
      // Check for reCAPTCHA (similar process as hCaptcha)
      const recaptchaSiteKey = await this.page.evaluate(() => {
        const iframe = document.querySelector('iframe[src*="recaptcha"]');
        if (iframe) {
          const src = iframe.getAttribute('src') || '';
          const siteKeyMatch = src.match(/k=([^&]+)/);
          return siteKeyMatch ? siteKeyMatch[1] : null;
        }
        return null;
      });
      
      if (recaptchaSiteKey) {
        const pageUrl = this.page.url();
        
        // Solve reCAPTCHA
        const captchaResult = await this.solver.recaptcha(recaptchaSiteKey, pageUrl);
        
        // Input the captcha result
        await this.page.evaluate((token) => {
          // Find the appropriate callback function or input for the token
          (window as any).___grecaptcha_cfg?.clients[0]?.callback?.(token);
          
          // Try to find an input field to paste the token
          const inputs = Array.from(document.querySelectorAll('textarea[name="g-recaptcha-response"]'));
          if (inputs.length > 0) {
            (inputs[0] as HTMLTextAreaElement).value = token;
          }
          
          // Try to submit the form
          const forms = Array.from(document.querySelectorAll('form'));
          forms.forEach(form => {
            if (form.querySelector('iframe[src*="recaptcha"]')) {
              form.submit();
            }
          });
        }, captchaResult.data);
        
        logger.info('reCAPTCHA solved successfully');
      }
      
      // Wait a moment for the form submission to process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
    } catch (error) {
      logger.error(`Failed to solve CAPTCHA: ${error}`);
      await this.takeScreenshot('captcha-error');
    }
  }
  
  /**
   * Take a screenshot for debugging purposes
   * @param name The name of the screenshot
   */
  async takeScreenshot(name: string): Promise<string | null> {
    if (!this.page) return null;
    
    try {
      const timestamp = new Date().toISOString().replace(/:/g, '-');
      const filename = `${name}-${timestamp}.png`;
      const filepath = path.join(this.screenshotsDir, filename);
      
      await this.page.screenshot({ path: filepath, fullPage: true });
      logger.info(`Screenshot saved to ${filepath}`);
      return filepath;
    } catch (error) {
      logger.error(`Failed to take screenshot: ${error}`);
      return null;
    }
  }
  
  /**
   * Save cookies for reuse
   * @param name The name to save the cookies under
   */
  async saveCookies(name: string): Promise<void> {
    if (!this.page) return;
    
    try {
      const cookies = await this.page.cookies();
      const filepath = path.join(this.cookiesDir, `${name}.json`);
      
      await fs.writeJSON(filepath, cookies, { spaces: 2 });
      logger.info(`Cookies saved to ${filepath}`);
    } catch (error) {
      logger.error(`Failed to save cookies: ${error}`);
    }
  }
  
  /**
   * Load cookies from file
   * @param name The name of the cookies file to load
   */
  async loadCookies(name: string): Promise<boolean> {
    if (!this.page) return false;
    
    const filepath = path.join(this.cookiesDir, `${name}.json`);
    
    if (!fs.existsSync(filepath)) {
      logger.warn(`Cookies file not found: ${filepath}`);
      return false;
    }
    
    try {
      const cookies = await fs.readJSON(filepath);
      await this.page.setCookie(...cookies);
      logger.info(`Cookies loaded from ${filepath}`);
      return true;
    } catch (error) {
      logger.error(`Failed to load cookies: ${error}`);
      return false;
    }
  }
  
  /**
   * Login to Sparx Maths with school selection
   * @param schoolName The school name to search for and select
   * @param username The username to login with
   * @param password The password to login with
   */
  async login(schoolName: string, username: string, password: string): Promise<boolean> {
    try {
      // First, try to load cookies
      const cookieFilename = this.getCookieFilename(username);
      const cookiesLoaded = await this.loadCookies(cookieFilename);
      
      // Go to the login page
      await this.goto(this.loginUrl);
      
      // If cookies loaded successfully, check if we're already logged in
      if (cookiesLoaded) {
        const isLoggedIn = await this.checkIfLoggedIn();
        if (isLoggedIn) {
          logger.info(`Already logged in as ${username}`);
          return true;
        }
      }
      
      // Otherwise, perform the login process starting with school selection
      logger.info(`Attempting to login as ${username} for school "${schoolName}"`);
      
      try {
        // Wait for the school search input to be available
        await this.page!.waitForSelector('input[type="text"], #school-search, input[placeholder*="school"]', { 
          timeout: 10000 
        });
        
        // Find the school search input
        const schoolInput = await this.page!.$('input[type="text"], #school-search, input[placeholder*="school"]');
        
        if (!schoolInput) {
          throw new Error('School search input not found');
        }
        
        // Clear any existing text and type the school name
        await schoolInput.click({ clickCount: 3 });
        await schoolInput.press('Backspace');
        await schoolInput.type(schoolName);
        
        // Take a screenshot for debugging
        await this.takeScreenshot('school-search');
        
        // Wait for search results to appear (1 second delay)
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Find and click the first search result
        const schoolResults = await this.page!.$$('.search-result, .school-option, li[role="option"]');
        
        if (schoolResults.length === 0) {
          throw new Error('No school search results found');
        }
        
        // Click the first result
        await schoolResults[0].click();
        
        // Wait for the continue button and click it
        await this.page!.waitForSelector('button[type="submit"], button:contains("Continue"), .continue-button', {
          timeout: 5000
        });
        
        const continueButton = await this.page!.$('button[type="submit"], button:contains("Continue"), .continue-button');
        
        if (!continueButton) {
          throw new Error('Continue button not found');
        }
        
        await continueButton.click();
        
        // Wait a short period for the page to update
        await new Promise(resolve => setTimeout(resolve, 1300));
        
        // Click continue again if needed for the second step
        const secondContinueButton = await this.page!.$('button[type="submit"], button:contains("Continue"), .continue-button');
        
        if (secondContinueButton) {
          await secondContinueButton.click();
          await new Promise(resolve => setTimeout(resolve, 1300));
        }
        
        // Check if we need to select between student and teacher login
        const studentOption = await this.page!.$('button:contains("Student"), [role="button"]:contains("Student"), a:contains("Student")');
        
        if (studentOption) {
          await studentOption.click();
          await new Promise(resolve => setTimeout(resolve, 1300));
        }
        
        // Now the username and password form should be visible
        await this.page!.waitForSelector('#username, input[name="username"], input[placeholder*="username"]', { 
          timeout: 10000 
        });
        
        // Find the username and password fields
        const usernameField = await this.page!.$('#username, input[name="username"], input[placeholder*="username"]');
        const passwordField = await this.page!.$('#password, input[name="password"], input[placeholder*="password"]');
        
        if (!usernameField || !passwordField) {
          throw new Error('Username or password field not found');
        }
        
        // Fill in the login form
        await usernameField.click({ clickCount: 3 });
        await usernameField.press('Backspace');
        await usernameField.type(username);
        
        await passwordField.click({ clickCount: 3 });
        await passwordField.press('Backspace');
        await passwordField.type(password);
        
        // Take a screenshot before submitting
        await this.takeScreenshot('pre-login');
        
        // Find and click the login submit button
        const loginButton = await this.page!.$('button[type="submit"], button:contains("Log in"), .login-button');
        
        if (!loginButton) {
          throw new Error('Login button not found');
        }
        
        await Promise.all([
          loginButton.click(),
          this.page!.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {
            logger.warn('No navigation detected after login click');
          })
        ]);
        
        // Check if login was successful
        const isLoggedIn = await this.checkIfLoggedIn();
        
        if (isLoggedIn) {
          logger.info(`Successfully logged in as ${username}`);
          await this.saveCookies(cookieFilename);
          return true;
        } else {
          const errorMessage = await this.getLoginErrorMessage();
          logger.error(`Login failed: ${errorMessage || 'Unknown error'}`);
          await this.takeScreenshot('login-failed');
          return false;
        }
      } catch (error) {
        logger.error(`Login flow error: ${error}`);
        await this.takeScreenshot('login-flow-error');
        return false;
      }
    } catch (error) {
      logger.error(`Login process failed: ${error}`);
      await this.takeScreenshot('login-error');
      return false;
    }
  }
  
  /**
   * Check if the user is currently logged in
   */
  private async checkIfLoggedIn(): Promise<boolean> {
    if (!this.page) return false;
    
    try {
      // Take a screenshot for debug purposes
      await this.takeScreenshot('check-logged-in');
      
      // Check for elements that indicate a successful login
      return await this.page.evaluate(() => {
        // Look for elements that would only be present when logged in
        const userProfileElement = document.querySelector('.user-profile, .avatar, .username');
        const logoutElement = document.querySelector('a[href*="logout"], button:contains("Sign out")');
        const welcomeMessage = document.querySelector('*:contains("Welcome back")');
        
        return !!userProfileElement || !!logoutElement || !!welcomeMessage;
      });
    } catch (error) {
      logger.error(`Error checking login status: ${error}`);
      return false;
    }
  }
  
  /**
   * Get any error message from the login page
   */
  private async getLoginErrorMessage(): Promise<string | null> {
    if (!this.page) return null;
    
    try {
      return await this.page.evaluate(() => {
        const errorElement = document.querySelector('.error-message, .alert-danger, .form-error');
        return errorElement ? errorElement.textContent!.trim() : null;
      });
    } catch {
      return null;
    }
  }
  
  /**
   * Generate a standardized cookie filename based on username
   */
  private getCookieFilename(username: string): string {
    // Create a hash of the username to use as the filename
    const hash = crypto.createHash('md5').update(username).digest('hex');
    return `sparx-cookies-${hash}`;
  }
  
  /**
   * Get the current page object
   */
  getPage(): Page | null {
    return this.page;
  }
  
  /**
   * Get the current browser object
   */
  getBrowser(): Browser | null {
    return this.browser;
  }

  /**
   * Navigate to homework page and select homework type
   * @param homeworkType The type of homework to select ('compulsory' or 'xpboost')
   */
  async selectHomeworkType(homeworkType: 'compulsory' | 'xpboost'): Promise<boolean> {
    if (!this.page) return false;
    
    try {
      logger.info(`Selecting homework type: ${homeworkType}`);
      
      // Navigate to the homework page if not already there
      if (!this.page.url().includes('/student/homework')) {
        await this.goto('https://sparxmaths.uk/student/homework');
      }
      
      // Take a screenshot for debugging
      await this.takeScreenshot('homework-page');
      
      // Wait for the homework page to load properly
      await this.page.waitForSelector('.package-cards, .homework-cards, .task-list', {
        timeout: 10000
      }).catch(() => {
        logger.warn('Homework type selection elements not found with expected selectors');
      });
      
      // First, check if we need to select a package type
      // Depending on the website structure, we might need different selectors
      if (homeworkType === 'compulsory') {
        // Try to find and click on the compulsory homework option
        const compulsoryOptions = await this.page.$$([
          '.homework-cards .compulsory-card', 
          '[data-test="compulsory-homework"]',
          'button:contains("Compulsory")',
          '.card:contains("Compulsory")',
          'div[role="button"]:contains("Compulsory")',
          'a:contains("Compulsory homework")'
        ].join(', '));
        
        if (compulsoryOptions.length > 0) {
          // Click the first compulsory homework option
          await compulsoryOptions[0].click();
          logger.info('Clicked on compulsory homework option');
          
          // Wait for navigation or UI update
          await this.page.waitForNavigation({ waitUntil: 'networkidle2' })
            .catch(() => logger.warn('No navigation occurred after clicking compulsory homework'));
          
          await this.takeScreenshot('after-compulsory-select');
          return true;
        } else {
          logger.warn('Compulsory homework option not found');
        }
      } else if (homeworkType === 'xpboost') {
        // Try to find and click on the XP boost homework option
        const xpBoostOptions = await this.page.$$([
          '.homework-cards .xp-boost-card', 
          '[data-test="xp-boost"]',
          'button:contains("XP Boost")',
          '.card:contains("XP Boost")',
          'div[role="button"]:contains("XP Boost")',
          'a:contains("XP Boost")'
        ].join(', '));
        
        if (xpBoostOptions.length > 0) {
          // Click the first XP boost option
          await xpBoostOptions[0].click();
          logger.info('Clicked on XP boost homework option');
          
          // Wait for navigation or UI update
          await this.page.waitForNavigation({ waitUntil: 'networkidle2' })
            .catch(() => logger.warn('No navigation occurred after clicking XP boost'));
          
          await this.takeScreenshot('after-xpboost-select');
          return true;
        } else {
          logger.warn('XP boost homework option not found');
        }
      }
      
      // If we reach here, we couldn't find the specific homework type
      // Let's attempt to identify the most recent homework assignment of any type
      const recentHomeworkCards = await this.page.$$('.homework-card, .task-card, .homework-item');
      
      if (recentHomeworkCards.length > 0) {
        // Click the first (most recent) homework card
        await recentHomeworkCards[0].click();
        logger.info('Clicked on the most recent homework assignment');
        
        // Wait for navigation or UI update
        await this.page.waitForNavigation({ waitUntil: 'networkidle2' })
          .catch(() => logger.warn('No navigation occurred after clicking recent homework'));
        
        await this.takeScreenshot('after-recent-homework-select');
        return true;
      }
      
      logger.error('Could not find any homework assignments');
      return false;
    } catch (error) {
      logger.error(`Error selecting homework type: ${error}`);
      await this.takeScreenshot('homework-type-selection-error');
      return false;
    }
  }
  
  /**
   * Try to identify and solve questions on the current page
   * @param maxAttempts Maximum number of attempts to solve a single question
   * @returns Number of questions solved
   */
  async solveCurrentPage(maxAttempts: number = 2): Promise<number> {
    if (!this.page) return 0;
    
    try {
      // Take a screenshot of the current page
      await this.takeScreenshot('current-page-to-solve');
      
      let questionsSolved = 0;
      
      // Look for question elements on the page
      const questionElems = await this.page.$$('.question-container, .task-container, .question-card');
      
      if (questionElems.length === 0) {
        logger.warn('No question elements found on the current page');
        return 0;
      }
      
      logger.info(`Found ${questionElems.length} potential question elements`);
      
      // Process each question
      for (const questionElem of questionElems) {
        let solved = false;
        
        // Extract the question text if possible
        const questionText = await questionElem.evaluate(el => {
          const textElement = el.querySelector('.question-text, .task-text, .question-content');
          return textElement ? textElement.textContent || '' : '';
        }).catch(() => '');
        
        logger.info(`Processing question: ${questionText.substring(0, 50)}...`);
        
        // Try to solve the question with multiple attempts
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          logger.info(`Attempt ${attempt} for question`);
          
          // Look for answer input
          const answerInput = await questionElem.$('input[type="text"], textarea, .answer-input');
          
          if (!answerInput) {
            logger.warn('No answer input found for this question');
            break;
          }
          
          // Try some common answer patterns for testing
          // In a real implementation, this would use the OCR service and database lookup
          const testAnswers = ['4', '10', 'x^2', '2x + 3', '3.14', 'y = 2x + 1'];
          const answerToTry = testAnswers[Math.floor(Math.random() * testAnswers.length)];
          
          // Clear the input and type the answer
          await answerInput.click({ clickCount: 3 });
          await answerInput.press('Backspace');
          await answerInput.type(answerToTry);
          
          // Look for and click the submit button
          const submitButton = await questionElem.$('button[type="submit"], .submit-button, button:contains("Check")');
          
          if (submitButton) {
            await submitButton.click();
            
            // Wait a moment for the result
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Check if the answer was correct
            const isCorrect = await questionElem.evaluate(el => {
              return el.querySelector('.correct, .success, .answer-correct') !== null;
            }).catch(() => false);
            
            if (isCorrect) {
              logger.info('Answer was correct!');
              solved = true;
              questionsSolved++;
              break;
            } else {
              logger.warn(`Attempt ${attempt} was incorrect`);
            }
          } else {
            logger.warn('No submit button found for this question');
            break;
          }
        }
        
        if (!solved) {
          logger.warn(`Could not solve question after ${maxAttempts} attempts, moving on`);
        }
        
        // Try to find and click the "Next" button to proceed to the next question
        const nextButton = await this.page.$('button:contains("Next"), .next-button, button[aria-label="Next"]');
        
        if (nextButton) {
          await nextButton.click();
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }
      
      logger.info(`Solved ${questionsSolved} questions on this page`);
      return questionsSolved;
    } catch (error) {
      logger.error(`Error solving current page: ${error}`);
      await this.takeScreenshot('solve-page-error');
      return 0;
    }
  }
}