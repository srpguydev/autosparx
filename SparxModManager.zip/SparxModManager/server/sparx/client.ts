import { SparxBrowser } from './browser';
import { OcrService } from './ocr';
import { logger } from '../logger';
import { db } from '../db';
import crypto from 'crypto';
import * as cheerio from 'cheerio';
import { sparxQuestions, sparxAccounts, sparxSessions, type SparxAccount, type SparxQuestion, type SparxSession } from '@shared/schema';
import { eq, and, desc } from 'drizzle-orm';

/**
 * Main client for Sparx Maths automation
 */
export class SparxClient {
  private browser: SparxBrowser;
  private ocr: OcrService;
  private currentSession: SparxSession | null = null;
  
  /**
   * Constructor for SparxClient
   * @param captchaApiKey API key for 2captcha service
   */
  constructor(captchaApiKey?: string) {
    this.browser = new SparxBrowser(captchaApiKey);
    this.ocr = new OcrService();
  }
  
  /**
   * Initialize the client
   */
  async initialize(): Promise<void> {
    try {
      logger.info('Initializing Sparx client');
      await this.browser.launch();
      await this.ocr.initialize();
      logger.info('Sparx client initialized successfully');
    } catch (error) {
      logger.error(`Failed to initialize Sparx client: ${error}`);
      throw error;
    }
  }
  
  /**
   * Shut down the client
   */
  async shutdown(): Promise<void> {
    try {
      logger.info('Shutting down Sparx client');
      await this.browser.close();
      await this.ocr.terminate();
      logger.info('Sparx client shut down successfully');
    } catch (error) {
      logger.error(`Error during shutdown: ${error}`);
    }
  }
  
  /**
   * Start a session for automated Sparx Maths
   * @param accountId The ID of the Sparx account to use
   * @param guildId The ID of the Discord guild
   * @param userId The ID of the Discord user
   */
  async startSession(accountId: number, guildId: string, userId: string): Promise<SparxSession | null> {
    try {
      // Get the account from the database
      const [account] = await db.select().from(sparxAccounts).where(eq(sparxAccounts.id, accountId));
      
      if (!account) {
        logger.error(`Account with ID ${accountId} not found`);
        return null;
      }
      
      // Create a new session
      const [session] = await db.insert(sparxSessions).values({
        accountId,
        guildId,
        userId,
        // The other fields will use default values
      }).returning();
      
      this.currentSession = session;
      
      logger.info(`Started session ${session.id} for account ${account.username}`);
      
      // Login to Sparx with the account credentials including school name
      const loginSuccess = await this.browser.login(account.schoolName, account.username, account.password);
      
      if (!loginSuccess) {
        logger.error(`Failed to login with account ${account.username}`);
        
        // Update the session status to failed
        await db.update(sparxSessions)
          .set({ status: 'failed', endTime: new Date() })
          .where(eq(sparxSessions.id, session.id));
          
        return null;
      }
      
      // Update the account's last login time
      await db.update(sparxAccounts)
        .set({ lastLogin: new Date() })
        .where(eq(sparxAccounts.id, accountId));
      
      return session;
    } catch (error) {
      logger.error(`Error starting session: ${error}`);
      return null;
    }
  }
  
  /**
   * End the current session
   */
  async endSession(): Promise<void> {
    if (!this.currentSession) {
      return;
    }
    
    try {
      await db.update(sparxSessions)
        .set({ 
          status: 'completed', 
          endTime: new Date() 
        })
        .where(eq(sparxSessions.id, this.currentSession.id));
        
      logger.info(`Session ${this.currentSession.id} ended`);
      this.currentSession = null;
    } catch (error) {
      logger.error(`Error ending session: ${error}`);
    }
  }
  
  /**
   * Navigate to the homework page
   */
  async navigateToHomework(): Promise<boolean> {
    try {
      const page = this.browser.getPage();
      if (!page) {
        throw new Error('Browser page not initialized');
      }
      
      // Navigate to the main homework page
      await this.browser.goto('https://sparxmaths.uk/student/homework');
      
      // Wait for the homework page to load
      await page.waitForSelector('.homework-cards, .homework-list, .task-list', {
        timeout: 10000
      }).catch(() => {
        logger.warn('Homework selector not found, may be on a different page structure');
      });
      
      // Take a screenshot for debugging
      await this.browser.takeScreenshot('homework-page');
      
      logger.info('Navigated to homework page');
      return true;
    } catch (error) {
      logger.error(`Failed to navigate to homework page: ${error}`);
      return false;
    }
  }
  
  /**
   * Extract questions from the current page
   */
  async extractQuestions(): Promise<string[]> {
    try {
      const page = this.browser.getPage();
      if (!page) {
        throw new Error('Browser page not initialized');
      }
      
      // Take a screenshot for debugging
      await this.browser.takeScreenshot('extract-questions');
      
      // Get the HTML content of the page
      const content = await page.content();
      
      // Use cheerio to parse the HTML
      const $ = cheerio.load(content);
      
      // Find question elements
      // Note: The selectors here are placeholders and need to be adjusted based on the actual HTML structure
      const questionElements = $('.question, .task-question, .question-text');
      
      const questions: string[] = [];
      
      // Extract text from each question element
      questionElements.each((_, element) => {
        const questionText = $(element).text().trim();
        if (questionText) {
          questions.push(questionText);
        }
      });
      
      // If no questions found in text, try OCR for image-based questions
      if (questions.length === 0) {
        const questionImages = $('.question-image, img[alt*="question"], .task-image');
        
        for (let i = 0; i < questionImages.length; i++) {
          const selector = questionImages.eq(i).toString();
          // Type assertion to handle the puppeteer-core vs puppeteer page type mismatch
          const extractedText = await this.ocr.processQuestionImage(page as any, selector);
          
          if (extractedText) {
            questions.push(extractedText);
          }
        }
      }
      
      logger.info(`Extracted ${questions.length} questions`);
      return questions;
    } catch (error) {
      logger.error(`Failed to extract questions: ${error}`);
      return [];
    }
  }
  
  /**
   * Find the answer for a question from the database
   * @param questionText The text of the question
   */
  async findAnswer(questionText: string): Promise<SparxQuestion | null> {
    try {
      // Create a hash of the question text for lookup
      const questionHash = this.createQuestionHash(questionText);
      
      // Look up the question in the database
      const [question] = await db.select()
        .from(sparxQuestions)
        .where(eq(sparxQuestions.questionHash, questionHash));
      
      if (question) {
        logger.info(`Found answer for question: ${questionText.substring(0, 50)}...`);
        return question;
      }
      
      logger.warn(`No answer found for question: ${questionText.substring(0, 50)}...`);
      return null;
    } catch (error) {
      logger.error(`Error finding answer: ${error}`);
      return null;
    }
  }
  
  /**
   * Submit an answer to the current question
   * @param answer The answer to submit
   */
  async submitAnswer(answer: string): Promise<boolean> {
    try {
      const page = this.browser.getPage();
      if (!page) {
        throw new Error('Browser page not initialized');
      }
      
      // Take a screenshot before submitting
      await this.browser.takeScreenshot('pre-submit-answer');
      
      // Find the answer input field
      // Note: The selectors here are placeholders and need to be adjusted based on the actual HTML structure
      const inputField = await page.$('input[type="text"], .answer-input, textarea.answer');
      
      if (!inputField) {
        logger.error('Answer input field not found');
        return false;
      }
      
      // Clear the input field
      await inputField.click({ clickCount: 3 }); // Triple click to select all
      await inputField.press('Backspace');
      
      // Type the answer
      await inputField.type(answer);
      
      // Take a screenshot after typing
      await this.browser.takeScreenshot('post-type-answer');
      
      // Find and click the submit button
      const submitButton = await page.$('button[type="submit"], .submit-button, button:contains("Check")');
      
      if (!submitButton) {
        logger.error('Submit button not found');
        return false;
      }
      
      // Click the submit button
      await submitButton.click();
      
      // Wait for the response
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {
        logger.warn('No navigation after submit, may be an AJAX form');
      });
      
      // Take a screenshot after submission
      await this.browser.takeScreenshot('post-submit-answer');
      
      // Check if the answer was correct
      const isCorrect = await this.checkIfAnswerCorrect();
      
      if (isCorrect) {
        logger.info('Answer submitted correctly');
        
        // Increment the questions answered counter in the session
        if (this.currentSession) {
          await db.update(sparxSessions)
            .set({ 
              questionsAnswered: this.currentSession.questionsAnswered + 1 
            })
            .where(eq(sparxSessions.id, this.currentSession.id));
        }
      } else {
        logger.warn('Answer was incorrect or submission failed');
      }
      
      return isCorrect;
    } catch (error) {
      logger.error(`Failed to submit answer: ${error}`);
      return false;
    }
  }
  
  /**
   * Check if the submitted answer was correct
   */
  private async checkIfAnswerCorrect(): Promise<boolean> {
    try {
      const page = this.browser.getPage();
      if (!page) {
        return false;
      }
      
      // Look for elements that indicate success
      const isCorrect = await page.evaluate(() => {
        // These selectors are placeholders and should be adjusted based on the actual website structure
        const successElements = document.querySelectorAll('.success-message, .correct-answer, .answer-correct');
        const errorElements = document.querySelectorAll('.error-message, .incorrect-answer, .answer-incorrect');
        
        return successElements.length > 0 && errorElements.length === 0;
      });
      
      return isCorrect;
    } catch (error) {
      logger.error(`Error checking if answer is correct: ${error}`);
      return false;
    }
  }
  
  /**
   * Store a new question and answer pair in the database
   * @param questionText The text of the question
   * @param answer The answer to the question
   * @param questionImage Optional path to an image of the question
   * @param workingOut Optional working out for the question
   */
  async storeQuestionAnswer(
    questionText: string,
    answer: string,
    questionImage?: string,
    workingOut?: string
  ): Promise<SparxQuestion | null> {
    try {
      const questionHash = this.createQuestionHash(questionText);
      
      // Check if the question already exists
      const [existingQuestion] = await db.select()
        .from(sparxQuestions)
        .where(eq(sparxQuestions.questionHash, questionHash));
      
      if (existingQuestion) {
        logger.info(`Question already exists in database: ${questionText.substring(0, 50)}...`);
        return existingQuestion;
      }
      
      // Insert the new question
      const [newQuestion] = await db.insert(sparxQuestions)
        .values({
          questionText,
          questionHash,
          questionImage,
          answer,
          workingOut
        })
        .returning();
      
      logger.info(`Stored new question: ${questionText.substring(0, 50)}...`);
      return newQuestion;
    } catch (error) {
      logger.error(`Failed to store question: ${error}`);
      return null;
    }
  }
  
  /**
   * Create a hash of the question text for lookup
   * @param questionText The text of the question
   */
  private createQuestionHash(questionText: string): string {
    // Normalize the question text (remove extra spaces, lowercase, etc.)
    const normalizedText = questionText
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .trim();
    
    // Create a hash of the normalized text
    return crypto.createHash('md5').update(normalizedText).digest('hex');
  }
  
  /**
   * Run the complete automation process for a session
   * @param accountId The ID of the Sparx account to use
   * @param guildId The ID of the Discord guild
   * @param userId The ID of the Discord user
   * @param homeworkType Type of homework to complete ('compulsory' or 'xpboost')
   * @param maxQuestions Maximum number of questions to answer (0 for all)
   * @param progressCallback Optional callback for progress updates
   */
  async runAutomation(
    accountId: number,
    guildId: string,
    userId: string,
    homeworkType: 'compulsory' | 'xpboost' = 'compulsory',
    maxQuestions: number = 0,
    progressCallback?: (progress: { message: string; screenshot?: string }) => Promise<void>
  ): Promise<{ success: boolean; message: string; questionsAnswered: number }> {
    try {
      // Start a new session
      const session = await this.startSession(accountId, guildId, userId);
      
      if (!session) {
        return { 
          success: false, 
          message: 'Failed to start session', 
          questionsAnswered: 0 
        };
      }
      
      // Get the account information
      const [account] = await db.select().from(sparxAccounts).where(eq(sparxAccounts.id, accountId));
      
      if (!account) {
        await this.endSession();
        return {
          success: false,
          message: 'Account not found',
          questionsAnswered: 0
        };
      }
      
      // Send progress update if callback is provided
      try {
        if (progressCallback) {
          await progressCallback({ 
            message: `Logged in successfully as ${account.username} for school "${account.schoolName}"`
          });
        }
      } catch (error) {
        logger.warn(`Failed to send progress update: ${error}`);
        // Continue automation even if progress updates fail
      }
      
      // Navigate to the homework page
      const navigated = await this.navigateToHomework();
      
      if (!navigated) {
        await this.endSession();
        return { 
          success: false, 
          message: 'Failed to navigate to homework page', 
          questionsAnswered: 0 
        };
      }
      
      // Select the homework type (compulsory or XP boost)
      try {
        if (progressCallback) {
          await progressCallback({ 
            message: `Selecting ${homeworkType} homework...`
          });
        }
      } catch (error) {
        logger.warn(`Failed to send progress update: ${error}`);
      }
      
      const homeworkSelected = await this.browser.selectHomeworkType(homeworkType);
      
      if (!homeworkSelected) {
        await this.endSession();
        return {
          success: false,
          message: `Failed to select ${homeworkType} homework`,
          questionsAnswered: 0
        };
      }
      
      // Take a screenshot after selecting homework
      const screenshotPath = await this.browser.takeScreenshot('homework-selected');
      
      try {
        if (progressCallback) {
          await progressCallback({ 
            message: `Selected ${homeworkType} homework successfully`,
            screenshot: screenshotPath || undefined
          });
        }
      } catch (error) {
        logger.warn(`Failed to send progress update: ${error}`);
      }
      
      let questionsAnswered = 0;
      let continueAnswering = true;
      
      // Main question-solving loop
      while (continueAnswering && (maxQuestions === 0 || questionsAnswered < maxQuestions)) {
        // Use the solveCurrentPage method to handle questions on the current page
        try {
          if (progressCallback) {
            await progressCallback({ 
              message: `Solving page ${questionsAnswered + 1}...`
            });
          }
        } catch (error) {
          logger.warn(`Failed to send progress update: ${error}`);
        }
        
        const solvedOnThisPage = await this.browser.solveCurrentPage(2); // Try each question up to 2 times
        
        if (solvedOnThisPage > 0) {
          questionsAnswered += solvedOnThisPage;
          
          try {
            if (progressCallback) {
              const screenshotPath = await this.browser.takeScreenshot(`solved-page-${questionsAnswered}`);
              await progressCallback({ 
                message: `Solved ${solvedOnThisPage} questions (total: ${questionsAnswered})`,
                screenshot: screenshotPath || undefined
              });
            }
          } catch (error) {
            logger.warn(`Failed to send progress update: ${error}`);
          }
          
          // Update the session with the new count
          if (this.currentSession) {
            await db.update(sparxSessions)
              .set({ questionsAnswered })
              .where(eq(sparxSessions.id, this.currentSession.id));
          }
        } else {
          // If we couldn't solve any questions on this page, we might be stuck
          try {
            if (progressCallback) {
              const screenshotPath = await this.browser.takeScreenshot('no-questions-solved');
              await progressCallback({ 
                message: `Couldn't solve any questions on the current page`,
                screenshot: screenshotPath || undefined
              });
            }
          } catch (error) {
            logger.warn(`Failed to send progress update: ${error}`);
          }
          
          // We could try to navigate to the next page anyway
          logger.warn('No questions solved on the current page, attempting to continue');
        }
        
        // Check if we've reached the maximum number of questions
        if (maxQuestions > 0 && questionsAnswered >= maxQuestions) {
          try {
            if (progressCallback) {
              await progressCallback({ 
                message: `Reached maximum questions limit (${maxQuestions})`
              });
            }
          } catch (error) {
            logger.warn(`Failed to send progress update: ${error}`);
          }
          break;
        }
        
        // Try to navigate to the next page
        const hasNextPage = await this.navigateToNextPage();
        
        if (!hasNextPage) {
          try {
            if (progressCallback) {
              await progressCallback({ 
                message: `No more pages available, homework complete`
              });
            }
          } catch (error) {
            logger.warn(`Failed to send progress update: ${error}`);
          }
          logger.info('No more questions to answer');
          break;
        }
      }
      
      // End the session
      await this.endSession();
      
      return {
        success: true,
        message: `Answered ${questionsAnswered} questions`,
        questionsAnswered
      };
    } catch (error) {
      logger.error(`Error during automation: ${error}`);
      
      // End the session if it was started
      if (this.currentSession) {
        await this.endSession();
      }
      
      return {
        success: false,
        message: `Error during automation: ${error}`,
        questionsAnswered: 0
      };
    }
  }
  
  /**
   * Navigate to the next page of questions
   */
  private async navigateToNextPage(): Promise<boolean> {
    try {
      const page = this.browser.getPage();
      if (!page) {
        return false;
      }
      
      // Look for a next button or link
      // Note: The selectors here are placeholders and need to be adjusted based on the actual website structure
      const nextButton = await page.$('.next-button, button:contains("Next"), a:contains("Next"), .pagination-next');
      
      if (!nextButton) {
        logger.info('No next button found');
        return false;
      }
      
      // Take a screenshot before clicking
      await this.browser.takeScreenshot('pre-next-page');
      
      // Click the next button
      await nextButton.click();
      
      // Wait for navigation to complete
      await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {
        logger.warn('No navigation after next button click, may be an AJAX navigation');
      });
      
      // Take a screenshot after navigation
      await this.browser.takeScreenshot('post-next-page');
      
      logger.info('Navigated to next page');
      return true;
    } catch (error) {
      logger.error(`Failed to navigate to next page: ${error}`);
      return false;
    }
  }
  
  /**
   * Get all stored Sparx accounts for a guild
   * @param guildId The ID of the Discord guild
   */
  static async getAccounts(guildId: string): Promise<SparxAccount[]> {
    try {
      return await db.select()
        .from(sparxAccounts)
        .where(eq(sparxAccounts.guildId, guildId));
    } catch (error) {
      logger.error(`Failed to retrieve Sparx accounts: ${error}`);
      return [];
    }
  }
  
  /**
   * Get a specific Sparx account by ID
   * @param id The ID of the Sparx account
   */
  static async getAccount(id: number): Promise<SparxAccount | null> {
    try {
      const [account] = await db.select()
        .from(sparxAccounts)
        .where(eq(sparxAccounts.id, id));
      
      return account || null;
    } catch (error) {
      logger.error(`Failed to retrieve Sparx account: ${error}`);
      return null;
    }
  }
  
  /**
   * Alias for getAccount - to match the method name used in routes
   * @param id The ID of the Sparx account
   */
  static async getAccountById(id: number): Promise<SparxAccount | null> {
    return SparxClient.getAccount(id);
  }
  
  /**
   * Create a new Sparx account
   * @param guildId The ID of the Discord guild
   * @param userId The ID of the Discord user
   * @param schoolName The school name for the Sparx account
   * @param username The username for the Sparx account
   * @param password The password for the Sparx account
   * @param homeworkType The default homework type ('compulsory' or 'xpboost')
   */
  static async createAccount(
    guildId: string,
    userId: string,
    schoolName: string,
    username: string,
    password: string,
    homeworkType: 'compulsory' | 'xpboost' = 'compulsory'
  ): Promise<SparxAccount | null> {
    try {
      // Check if an account with this username already exists for this guild
      const [existingAccount] = await db.select()
        .from(sparxAccounts)
        .where(
          and(
            eq(sparxAccounts.guildId, guildId),
            eq(sparxAccounts.username, username)
          )
        );
      
      if (existingAccount) {
        logger.warn(`Account with username ${username} already exists for guild ${guildId}`);
        return null;
      }
      
      // Create the new account
      const [newAccount] = await db.insert(sparxAccounts)
        .values({
          guildId,
          userId,
          schoolName,
          username,
          password,
          homeworkType,
          active: true
        })
        .returning();
      
      logger.info(`Created new Sparx account for guild ${guildId}, user ${userId}: ${username}`);
      
      // Send a DM to the owner for support purposes if requested
      // In a real implementation, this would be handled at the command level
      
      return newAccount;
    } catch (error) {
      logger.error(`Failed to create Sparx account: ${error}`);
      return null;
    }
  }
  
  /**
   * Get recent sessions for a guild
   * @param guildId The ID of the Discord guild
   * @param limit Maximum number of sessions to return
   */
  static async getRecentSessions(guildId: string, limit: number = 10): Promise<SparxSession[]> {
    try {
      return await db.select()
        .from(sparxSessions)
        .where(eq(sparxSessions.guildId, guildId))
        .orderBy(desc(sparxSessions.startTime))
        .limit(limit);
    } catch (error) {
      logger.error(`Failed to retrieve recent sessions: ${error}`);
      return [];
    }
  }
  
  /**
   * Get all stored questions
   * @param limit Maximum number of questions to return
   */
  static async getQuestions(limit: number = 100): Promise<SparxQuestion[]> {
    try {
      return await db.select()
        .from(sparxQuestions)
        .limit(limit);
    } catch (error) {
      logger.error(`Failed to retrieve questions: ${error}`);
      return [];
    }
  }
}

// Create a singleton instance
let sparxClientInstance: SparxClient | null = null;

export function getSparxClient(captchaApiKey?: string): SparxClient {
  if (!sparxClientInstance) {
    sparxClientInstance = new SparxClient(captchaApiKey);
  }
  return sparxClientInstance;
}

export function resetSparxClient(): void {
  if (sparxClientInstance) {
    sparxClientInstance.shutdown().catch(err => {
      logger.error(`Error shutting down Sparx client: ${err}`);
    });
    sparxClientInstance = null;
  }
}