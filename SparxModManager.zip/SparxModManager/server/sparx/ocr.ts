import { createWorker } from 'tesseract.js';
import fs from 'fs-extra';
import path from 'path';
import crypto from 'crypto';
import { logger } from '../logger';
import { Page } from 'puppeteer-core';

// Define a more flexible worker type to avoid TypeScript errors
type FlexibleWorker = any;

/**
 * Class for extracting text from images using OCR
 */
export class OcrService {
  private readonly imageDir = path.join(process.cwd(), 'question_images');
  private worker: FlexibleWorker | null = null;
  
  constructor() {
    // Ensure the image directory exists
    fs.ensureDirSync(this.imageDir);
  }
  
  /**
   * Initialize the OCR worker
   */
  async initialize(): Promise<void> {
    try {
      // Initialize the worker with simplified configuration
      this.worker = await createWorker();
      
      // Log success
      logger.info('OCR worker initialized successfully');
    } catch (error) {
      logger.error(`Failed to initialize OCR worker: ${error}`);
      throw error;
    }
  }
  
  /**
   * Terminate the OCR worker
   */
  async terminate(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate();
      this.worker = null;
      logger.info('OCR worker terminated');
    }
  }
  
  /**
   * Extract text from an image
   * @param imagePath Path to the image file
   */
  async extractTextFromImage(imagePath: string): Promise<string> {
    if (!this.worker) {
      await this.initialize();
    }
    
    try {
      logger.info(`Extracting text from image: ${imagePath}`);
      
      const result = await this.worker!.recognize(imagePath);
      const text = result.data.text.trim();
      
      logger.info(`Extracted text (${text.length} characters)`);
      return text;
    } catch (error) {
      logger.error(`Failed to extract text from image: ${error}`);
      throw error;
    }
  }
  
  /**
   * Capture a question image from the page
   * @param page Puppeteer page object
   * @param selector CSS selector for the question element
   */
  async captureQuestionImage(page: Page, selector: string): Promise<string | null> {
    try {
      // Wait for the element to be visible
      await page.waitForSelector(selector, { visible: true, timeout: 10000 });
      
      // Get the bounding box of the element
      const boundingBox = await page.evaluate((sel) => {
        const element = document.querySelector(sel);
        if (!element) return null;
        
        const { x, y, width, height } = element.getBoundingClientRect();
        return { x, y, width, height };
      }, selector);
      
      if (!boundingBox) {
        logger.error(`Element not found for selector: ${selector}`);
        return null;
      }
      
      // Create a unique filename for the screenshot
      const timestamp = Date.now();
      const hash = crypto.createHash('md5').update(`${selector}-${timestamp}`).digest('hex');
      const imagePath = path.join(this.imageDir, `question-${hash}.png`);
      
      // Take a screenshot of the specific element
      await page.screenshot({
        path: imagePath,
        clip: {
          x: boundingBox.x,
          y: boundingBox.y,
          width: boundingBox.width,
          height: boundingBox.height
        }
      });
      
      logger.info(`Question image captured: ${imagePath}`);
      return imagePath;
    } catch (error) {
      logger.error(`Failed to capture question image: ${error}`);
      return null;
    }
  }
  
  /**
   * Process a question image and extract text
   * @param page Puppeteer page object
   * @param selector CSS selector for the question element
   */
  async processQuestionImage(page: Page, selector: string): Promise<string | null> {
    const imagePath = await this.captureQuestionImage(page, selector);
    
    if (!imagePath) {
      return null;
    }
    
    try {
      const text = await this.extractTextFromImage(imagePath);
      return text;
    } catch (error) {
      logger.error(`Failed to process question image: ${error}`);
      return null;
    }
  }
}