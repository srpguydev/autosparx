import type { InsertBotLog } from '@shared/schema';
import type { IStorage } from './storage';

// This will be set later to avoid circular dependencies
let storageInstance: IStorage | null = null;

export function setStorage(storage: IStorage) {
  storageInstance = storage;
}

class Logger {
  private readonly defaultGuildId: string;
  
  constructor() {
    // Default guild ID for logs when no guild is specified
    this.defaultGuildId = process.env.DEFAULT_GUILD_ID || '123456789012345678';
  }
  
  /**
   * Log an info message
   */
  async info(message: string, options?: Partial<InsertBotLog>): Promise<void> {
    await this.log('info', message, options);
    console.log(`[INFO] ${message}`);
  }
  
  /**
   * Log a success message
   */
  async success(message: string, options?: Partial<InsertBotLog>): Promise<void> {
    await this.log('success', message, options);
    console.log(`[SUCCESS] ${message}`);
  }
  
  /**
   * Log a warning message
   */
  async warn(message: string, options?: Partial<InsertBotLog>): Promise<void> {
    await this.log('warning', message, options);
    console.warn(`[WARNING] ${message}`);
  }
  
  /**
   * Log an error message
   */
  async error(message: string, options?: Partial<InsertBotLog>): Promise<void> {
    await this.log('error', message, options);
    console.error(`[ERROR] ${message}`);
  }
  
  /**
   * Create a bot log entry in storage
   */
  private async log(type: string, message: string, options?: Partial<InsertBotLog>): Promise<void> {
    try {
      // Only attempt to store logs if storage is initialized
      if (storageInstance) {
        const logEntry: InsertBotLog = {
          guildId: options?.guildId || this.defaultGuildId,
          type,
          message,
          userId: options?.userId,
          username: options?.username
        };
        
        await storageInstance.createBotLog(logEntry);
      }
    } catch (error) {
      console.error(`Failed to create log entry: ${error}`);
    }
  }
}

export const logger = new Logger();
