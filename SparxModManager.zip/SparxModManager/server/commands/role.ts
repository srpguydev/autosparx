import { Message, GuildMember } from 'discord.js';
import { storage } from '../storage';
import { logger } from '../logger';
import type { BotClient } from '../botClient';

export const roleCommand = {
  name: 'role',
  description: 'Manage server roles',
  usage: '!role [add/remove] [user] [role]',
  permission: 'admin',
  
  async execute(message: Message, args: string[], botClient: BotClient) {
    if (args.length < 3) {
      await message.reply(`Incorrect usage. Syntax: ${this.usage}`);
      return;
    }
    
    const action = args[0].toLowerCase();
    
    if (action !== 'add' && action !== 'remove' && action !== 'create') {
      await message.reply('Invalid action. Use `add`, `remove`, or `create`.');
      return;
    }
    
    // Handle create role action
    if (action === 'create') {
      const roleName = args.slice(1).join(' ');
      try {
        const newRole = await message.guild!.roles.create({
          name: roleName,
          reason: `Created by ${message.author.username} using role command`
        });
        
        await message.reply(`Role "${newRole.name}" created successfully!`);
        
        logger.success(`Role "${newRole.name}" created by ${message.author.username}`, {
          guildId: message.guild!.id,
          userId: message.author.id,
          username: message.author.username
        });
        
        return;
      } catch (error) {
        logger.error(`Failed to create role "${roleName}": ${error}`, {
          guildId: message.guild!.id,
          userId: message.author.id,
          username: message.author.username
        });
        
        await message.reply(`Failed to create role: ${error}`);
        return;
      }
    }
    
    // Handle add/remove role actions
    const targetUser = message.mentions.members?.first();
    
    if (!targetUser) {
      await message.reply('You need to mention a user.');
      return;
    }
    
    const roleName = args.slice(2).join(' ');
    const role = message.guild!.roles.cache.find(r => 
      r.name.toLowerCase() === roleName.toLowerCase()
    );
    
    if (!role) {
      await message.reply(`Role "${roleName}" not found.`);
      return;
    }
    
    try {
      if (action === 'add') {
        await targetUser.roles.add(role);
        await message.reply(`Added role "${role.name}" to ${targetUser.user.username}.`);
        
        logger.success(`Role "${role.name}" added to ${targetUser.user.username} by ${message.author.username}`, {
          guildId: message.guild!.id,
          userId: targetUser.id,
          username: targetUser.user.username
        });
      } else if (action === 'remove') {
        await targetUser.roles.remove(role);
        await message.reply(`Removed role "${role.name}" from ${targetUser.user.username}.`);
        
        logger.success(`Role "${role.name}" removed from ${targetUser.user.username} by ${message.author.username}`, {
          guildId: message.guild!.id,
          userId: targetUser.id,
          username: targetUser.user.username
        });
      }
    } catch (error) {
      logger.error(`Failed to ${action} role "${role.name}" to/from ${targetUser.user.username}: ${error}`, {
        guildId: message.guild!.id,
        userId: targetUser.id,
        username: targetUser.user.username
      });
      
      await message.reply(`Failed to ${action} role: ${error}`);
    }
  }
};
