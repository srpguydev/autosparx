import { Message, EmbedBuilder } from 'discord.js';
import { storage } from '../storage';
import { logger } from '../logger';
import type { BotClient } from '../botClient';

export const logsCommand = {
  name: 'logs',
  description: 'View bot activity logs',
  usage: '!logs [limit]',
  permission: 'mod',
  
  async execute(message: Message, args: string[], botClient: BotClient) {
    let limit = 5;
    
    if (args.length > 0) {
      const parsedLimit = parseInt(args[0]);
      if (!isNaN(parsedLimit) && parsedLimit > 0) {
        limit = Math.min(parsedLimit, 20); // Cap at 20 logs to prevent spam
      }
    }
    
    try {
      const logs = await storage.getBotLogs(message.guild!.id, limit);
      
      if (logs.length === 0) {
        await message.reply('No logs found for this server.');
        return;
      }
      
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('Recent Bot Activity Logs')
        .setDescription(`Showing the last ${logs.length} log entries`)
        .setTimestamp();
      
      logs.forEach((log, index) => {
        const formattedTime = log.createdAt.toLocaleTimeString();
        const logIcon = this.getLogIcon(log.type);
        const userInfo = log.username ? ` by ${log.username}` : '';
        
        embed.addFields({
          name: `${logIcon} ${formattedTime}${userInfo}`,
          value: log.message
        });
      });
      
      await message.reply({ embeds: [embed] });
      
      logger.info(`Logs viewed by ${message.author.username}`, {
        guildId: message.guild!.id,
        userId: message.author.id,
        username: message.author.username
      });
    } catch (error) {
      logger.error(`Failed to retrieve logs: ${error}`, {
        guildId: message.guild!.id,
        userId: message.author.id,
        username: message.author.username
      });
      
      await message.reply(`Failed to retrieve logs: ${error}`);
    }
  },
  
  getLogIcon(type: string): string {
    switch (type) {
      case 'success':
        return '🟢';
      case 'error':
        return '🔴';
      case 'warning':
        return '🟡';
      case 'info':
      default:
        return '🔵';
    }
  }
};
