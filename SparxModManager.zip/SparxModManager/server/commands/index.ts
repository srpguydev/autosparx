import { Collection } from 'discord.js';
import { roleCommand } from './role';
import { permsCommand } from './perms';
import { logsCommand } from './logs';
import { helpCommand } from './help';
import { sparxCommand } from './sparx';

// Create a collection for commands
const commands = new Collection();

// Register all commands
commands.set('role', roleCommand);
commands.set('perms', permsCommand);
commands.set('logs', logsCommand);
commands.set('help', helpCommand);
commands.set('sparx', sparxCommand);

export { commands };
