import { Message, PermissionFlagsBits, ChannelType } from 'discord.js';
import { storage } from '../storage';
import { logger } from '../logger';
import type { BotClient } from '../botClient';

export const permsCommand = {
  name: 'perms',
  description: 'Set channel permissions',
  usage: '!perms [channel] [role] [allow/deny] [perm]',
  permission: 'admin',
  
  async execute(message: Message, args: string[], botClient: BotClient) {
    if (args.length < 4) {
      await message.reply(`Incorrect usage. Syntax: ${this.usage}`);
      return;
    }
    
    // Get channel
    const channelMention = args[0];
    const channelId = channelMention.replace(/[<#>]/g, '');
    const channel = message.guild!.channels.cache.get(channelId);
    
    if (!channel) {
      await message.reply('Channel not found. Please mention a valid channel.');
      return;
    }
    
    // Get role
    const roleMention = args[1];
    const roleId = roleMention.replace(/[<@&>]/g, '');
    const role = message.guild!.roles.cache.get(roleId);
    
    if (!role) {
      await message.reply('Role not found. Please mention a valid role.');
      return;
    }
    
    // Get action (allow/deny)
    const action = args[2].toLowerCase();
    if (action !== 'allow' && action !== 'deny') {
      await message.reply('Invalid action. Use `allow` or `deny`.');
      return;
    }
    
    // Get permission
    const permName = args[3].toUpperCase();
    const permissionFlags = Object.keys(PermissionFlagsBits);
    
    if (!permissionFlags.includes(permName)) {
      await message.reply(`Invalid permission. Available permissions: ${permissionFlags.join(', ')}`);
      return;
    }
    
    // Set permission
    try {
      const permValue = PermissionFlagsBits[permName as keyof typeof PermissionFlagsBits];
      
      if (channel.isTextBased()) {
        await channel.permissionOverwrites.edit(role, {
          [permName.toLowerCase()]: action === 'allow'
        });
        
        // Store the permission change in database
        await storage.createChannelPermission({
          guildId: message.guild!.id,
          channelId: channel.id,
          channelName: channel.name,
          roleId: role.id,
          roleName: role.name,
          allow: action === 'allow' ? permName : undefined,
          deny: action === 'deny' ? permName : undefined
        });
        
        await message.reply(`Successfully ${action}ed \`${permName}\` for ${role.name} in ${channel.name}.`);
        
        logger.success(`Permission ${permName} ${action}ed for ${role.name} in ${channel.name} by ${message.author.username}`, {
          guildId: message.guild!.id,
          userId: message.author.id,
          username: message.author.username
        });
      } else {
        await message.reply('Channel is not a text channel.');
      }
    } catch (error) {
      logger.error(`Failed to set permissions: ${error}`, {
        guildId: message.guild!.id,
        userId: message.author.id,
        username: message.author.username
      });
      
      await message.reply(`Failed to set permission: ${error}`);
    }
  }
};
