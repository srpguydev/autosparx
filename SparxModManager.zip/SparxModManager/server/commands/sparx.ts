import { Message } from 'discord.js';
import { BotClient } from '../botClient';
import { logger } from '../logger';
import { getSparxClient, SparxClient } from '../sparx';
import { db } from '../db';
import { sparxAccounts } from '@shared/schema';
import { eq } from 'drizzle-orm';

export const sparxCommand = {
  name: 'sparx',
  description: 'Manage and automate Sparx Maths homework',
  usage: '!sparx [list|add|remove|start] [options]',
  permission: 'SEND_MESSAGES',
  
  async execute(message: Message, args: string[], botClient: BotClient) {
    const subCommand = args[0]?.toLowerCase();
    
    if (!subCommand || subCommand === 'help') {
      return this.showHelp(message);
    }
    
    switch (subCommand) {
      case 'list':
        return this.listAccounts(message);
      case 'add':
        return this.addAccount(message, args.slice(1));
      case 'remove':
        return this.removeAccount(message, args.slice(1));
      case 'start':
        return this.startAutomation(message, args.slice(1));
      default:
        return this.showHelp(message);
    }
  },
  
  /**
   * Show help information for the Sparx command
   */
  async showHelp(message: Message) {
    const helpEmbed = {
      title: 'Sparx Maths Automation Help',
      color: 0x00AAFF,
      description: 'Commands for managing Sparx Maths automation',
      fields: [
        {
          name: '!sparx list',
          value: 'List all Sparx accounts for this server'
        },
        {
          name: '!sparx add username, password',
          value: 'Add a new Sparx account (use in DM for privacy). Separate with commas to support spaces in credentials.'
        },
        {
          name: '!sparx remove <id>',
          value: 'Remove a Sparx account by ID'
        },
        {
          name: '!sparx start <id> [max_questions]',
          value: 'Start automation with the specified account'
        }
      ],
      footer: {
        text: 'For privacy, use DMs when adding accounts'
      }
    };
    
    await message.reply({ embeds: [helpEmbed] });
  },
  
  /**
   * List all Sparx accounts for the guild
   */
  async listAccounts(message: Message) {
    try {
      // Get the guild ID
      const guildId = message.guild?.id;
      
      if (!guildId) {
        return message.reply('This command must be used in a server.');
      }
      
      // Get accounts for this guild
      const accounts = await SparxClient.getAccounts(guildId);
      
      if (accounts.length === 0) {
        return message.reply('No Sparx accounts have been added for this server.');
      }
      
      // Create an embed to display the accounts
      const accountsEmbed = {
        title: 'Sparx Accounts',
        color: 0x00AAFF,
        description: `Found ${accounts.length} account(s) for this server`,
        fields: accounts.map(account => ({
          name: `ID: ${account.id} - ${account.username}`,
          value: `Status: ${account.active ? 'Active' : 'Inactive'}\nLast Login: ${account.lastLogin ? new Date(account.lastLogin).toLocaleString() : 'Never'}`
        })),
        footer: {
          text: 'Use !sparx start <id> to start automation'
        }
      };
      
      await message.reply({ embeds: [accountsEmbed] });
    } catch (error) {
      logger.error(`Error listing Sparx accounts: ${error}`);
      await message.reply('An error occurred while listing Sparx accounts.');
    }
  },
  
  /**
   * Add a new Sparx account
   */
  async addAccount(message: Message, args: string[]) {
    try {
      // Join the arguments to handle the comma-separated format
      const argsText = args.join(' ');
      
      // Split by comma to handle format like "username, password, guildId"
      const parts = argsText.split(',').map(part => part.trim());
      
      if (parts.length < 2) {
        return message.reply('Please provide both username and password. Example: !sparx add username, password');
      }
      
      const username = parts[0];
      const password = parts[1];
      
      // Check if we're in a private channel for security
      if (message.channel.type !== 1) { // 1 is DM channel
        await message.delete().catch(() => {
          logger.warn('Could not delete message with credentials');
        });
        
        return message.reply('For security, please add accounts via DM to protect your credentials.');
      }
      
      // Get the guild ID from the message (for DMs, we need to specify guild ID separately)
      let guildId = parts[2];
      
      if (!guildId) {
        return message.reply('When adding an account via DM, please specify the server ID. Example: !sparx add username, password, serverId');
      }
      
      // Create the account
      const newAccount = await SparxClient.createAccount(guildId, username, password);
      
      if (!newAccount) {
        return message.reply(`Account with username ${username} already exists for this server or could not be created.`);
      }
      
      await message.reply(`Successfully added Sparx account: ${username} (ID: ${newAccount.id})`);
    } catch (error) {
      logger.error(`Error adding Sparx account: ${error}`);
      await message.reply('An error occurred while adding the Sparx account.');
    }
  },
  
  /**
   * Remove a Sparx account
   */
  async removeAccount(message: Message, args: string[]) {
    try {
      // Check if we have enough arguments
      if (args.length < 1) {
        return message.reply('Please provide the account ID. Example: !sparx remove 123');
      }
      
      const accountId = parseInt(args[0]);
      
      if (isNaN(accountId)) {
        return message.reply('Please provide a valid account ID (number).');
      }
      
      // Get the guild ID
      const guildId = message.guild?.id;
      
      if (!guildId) {
        return message.reply('This command must be used in a server.');
      }
      
      // Get the account to verify it belongs to this guild
      const [account] = await db.select()
        .from(sparxAccounts)
        .where(eq(sparxAccounts.id, accountId));
      
      if (!account) {
        return message.reply(`Account with ID ${accountId} not found.`);
      }
      
      if (account.guildId !== guildId) {
        return message.reply(`Account with ID ${accountId} does not belong to this server.`);
      }
      
      // Delete the account
      await db.delete(sparxAccounts)
        .where(eq(sparxAccounts.id, accountId));
      
      await message.reply(`Successfully removed Sparx account: ${account.username} (ID: ${accountId})`);
    } catch (error) {
      logger.error(`Error removing Sparx account: ${error}`);
      await message.reply('An error occurred while removing the Sparx account.');
    }
  },
  
  /**
   * Start Sparx automation
   */
  async startAutomation(message: Message, args: string[]) {
    try {
      // Check if we have enough arguments
      if (args.length < 1) {
        return message.reply('Please provide the account ID. Example: !sparx start 123 [max_questions]');
      }
      
      const accountId = parseInt(args[0]);
      
      if (isNaN(accountId)) {
        return message.reply('Please provide a valid account ID (number).');
      }
      
      // Get the optional max_questions argument
      const maxQuestions = args[1] ? parseInt(args[1]) : 0;
      
      // Get the guild ID
      const guildId = message.guild?.id;
      
      if (!guildId) {
        return message.reply('This command must be used in a server.');
      }
      
      // Get the user ID
      const userId = message.author.id;
      
      // Get the account to verify it belongs to this guild
      const account = await SparxClient.getAccount(accountId);
      
      if (!account) {
        return message.reply(`Account with ID ${accountId} not found.`);
      }
      
      if (account.guildId !== guildId) {
        return message.reply(`Account with ID ${accountId} does not belong to this server.`);
      }
      
      // Check if the account is active
      if (!account.active) {
        return message.reply(`Account ${account.username} is inactive. Please activate it first.`);
      }
      
      // Inform the user that automation is starting
      const statusMessage = await message.reply(`Starting Sparx automation with account ${account.username}...`);
      
      // Get the Sparx client and initialize it
      // Note: In a production environment, you would retrieve the 2CAPTCHA API key from environment variables or a configuration
      const captchaApiKey = process.env.CAPTCHA_API_KEY;
      const client = getSparxClient(captchaApiKey);
      
      // Initialize the client
      await client.initialize();
      
      // Run the automation
      const result = await client.runAutomation(accountId, guildId, userId, maxQuestions);
      
      // Update the status message
      if (result.success) {
        await statusMessage.edit(`Sparx automation completed successfully. ${result.message}`);
      } else {
        await statusMessage.edit(`Sparx automation failed. ${result.message}`);
      }
      
      // Shut down the client
      await client.shutdown();
    } catch (error) {
      logger.error(`Error starting Sparx automation: ${error}`);
      await message.reply('An error occurred while starting Sparx automation.');
    }
  }
};