import { Message, EmbedBuilder } from 'discord.js';
import { storage } from '../storage';
import { logger } from '../logger';
import { commands } from './index';
import type { BotClient } from '../botClient';

export const helpCommand = {
  name: 'help',
  description: 'Show help information',
  usage: '!help [command]',
  permission: 'everyone',
  
  async execute(message: Message, args: string[], botClient: BotClient) {
    try {
      const guildCommands = await storage.getCommands(message.guild!.id);
      
      // If a specific command is requested
      if (args.length > 0) {
        const commandName = args[0].toLowerCase();
        const prefix = '!'; // Get prefix from config if implemented
        
        // Find command in database
        const dbCommand = guildCommands.find(cmd => 
          cmd.name === `${prefix}${commandName}` || cmd.name === commandName
        );
        
        if (!dbCommand) {
          await message.reply(`Command "${commandName}" not found.`);
          return;
        }
        
        // Find command in code collection
        const codeCommand = commands.get(commandName.replace(prefix, ''));
        
        const embed = new EmbedBuilder()
          .setColor('#5865F2')
          .setTitle(`Command: ${dbCommand.name}`)
          .setDescription(dbCommand.description)
          .addFields(
            { name: 'Usage', value: dbCommand.usage },
            { name: 'Permission', value: this.formatPermission(dbCommand.permission) },
            { name: 'Enabled', value: dbCommand.enabled ? 'Yes' : 'No' }
          )
          .setTimestamp();
        
        await message.reply({ embeds: [embed] });
        return;
      }
      
      // Show all commands
      const embed = new EmbedBuilder()
        .setColor('#5865F2')
        .setTitle('SparxCore Bot Commands')
        .setDescription('Here are all available commands for this server:')
        .setTimestamp();
      
      // Group commands by permission and type
      const adminCommands = guildCommands.filter(cmd => cmd.permission === 'admin' && cmd.enabled);
      const modCommands = guildCommands.filter(cmd => cmd.permission === 'mod' && cmd.enabled);
      const everyoneCommands = guildCommands.filter(cmd => 
        cmd.permission === 'everyone' && cmd.enabled && !cmd.name.includes('sparx')
      );
      const sparxCommands = guildCommands.filter(cmd => 
        cmd.name.includes('sparx') && cmd.enabled
      );
      
      if (adminCommands.length > 0) {
        embed.addFields({
          name: '👑 Admin Commands',
          value: adminCommands.map(cmd => `\`${cmd.name}\`: ${cmd.description}`).join('\n')
        });
      }
      
      if (modCommands.length > 0) {
        embed.addFields({
          name: '🛡️ Moderator Commands',
          value: modCommands.map(cmd => `\`${cmd.name}\`: ${cmd.description}`).join('\n')
        });
      }
      
      if (everyoneCommands.length > 0) {
        embed.addFields({
          name: '👥 General Commands',
          value: everyoneCommands.map(cmd => `\`${cmd.name}\`: ${cmd.description}`).join('\n')
        });
      }
      
      if (sparxCommands.length > 0) {
        embed.addFields({
          name: '📚 Sparx Math Commands',
          value: sparxCommands.map(cmd => `\`${cmd.name}\`: ${cmd.description}`).join('\n') +
                 '\n\n*Detailed Sparx usage:*\n`!sparx list` - List all registered accounts\n`!sparx add [username], [password]` - Add a new account\n`!sparx remove [username]` - Remove an account\n`!sparx start [username]` - Start Sparx automation for an account'
        });
      }
      
      embed.addFields({
        name: 'ℹ️ Get More Info',
        value: 'Use `!help [command]` to get more information about a specific command.'
      });
      
      await message.reply({ embeds: [embed] });
      
      logger.info(`Help command used by ${message.author.username}`, {
        guildId: message.guild!.id,
        userId: message.author.id,
        username: message.author.username
      });
    } catch (error) {
      logger.error(`Failed to execute help command: ${error}`, {
        guildId: message.guild!.id,
        userId: message.author.id,
        username: message.author.username
      });
      
      await message.reply(`Failed to show help information: ${error}`);
    }
  },
  
  formatPermission(permission: string): string {
    switch (permission) {
      case 'admin':
        return '👑 Admin';
      case 'mod':
        return '🛡️ Moderator';
      case 'everyone':
      default:
        return '👥 Everyone';
    }
  }
};
