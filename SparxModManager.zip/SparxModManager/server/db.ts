import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { logger } from './logger';

// Create PostgreSQL client
const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error('DATABASE_URL environment variable is not set');
  process.exit(1);
}

// Initialize Postgres client with connection pooling
const client = postgres(connectionString, {
  max: 10, // Max connections in pool
  idle_timeout: 20, // Max seconds connection can be idle
  connect_timeout: 10, // Max seconds to wait for connection
});

// Initialize Drizzle ORM
export const db = drizzle(client);

logger.info('Database connection established');