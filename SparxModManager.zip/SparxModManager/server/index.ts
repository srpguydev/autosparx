import express, { Express, Request, Response, NextFunction } from 'express';
import session from 'express-session';
import MemoryStore from 'memorystore';
import passport from 'passport';
import { registerRoutes } from './routes';
import { setupVite, serveStatic, log } from './vite';
import { Server } from 'http';

const MemoryStoreSession = MemoryStore(session);

let server: Server | null = null;

// Clean up existing server if present
const cleanup = () => {
  if (server) {
    log('Closing existing server');
    server.close();
    server = null;
  }
};

// Graceful shutdown
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

async function main() {
  // Create and configure Express app
  const app: Express = express();
  app.use(express.json());
  
  // Set up session
  app.use(
    session({
      cookie: { maxAge: 86400000 },
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || 'sparxcore-dev-secret'
    })
  );
  
  // Initialize passport middleware
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Register API routes
  server = await registerRoutes(app);
  
  // Setup Vite for development
  if (process.env.NODE_ENV !== 'production') {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  
  // Error handler
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err.stack);
    res.status(500).json({
      error: 'Internal Server Error',
      message: err.message
    });
  });
  
  // Handle 404 for any remaining routes
  app.use((_req: Request, res: Response) => {
    res.status(404).json({ error: 'Not Found' });
  });
}

// Run the application
main().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
