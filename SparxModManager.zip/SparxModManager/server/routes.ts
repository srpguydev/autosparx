import { Express, Request, Response } from 'express';
import { botClient } from './botClient';
import { storage } from './storage';
import { Server } from 'http';
import { logger } from './logger';
import { insertBotConfigSchema, insertRolePatternSchema, insertChannelPermissionSchema, insertCommandSchema, insertSparxAccountSchema } from '@shared/schema';
import { SparxClient, getSparxClient } from './sparx';
import { WebSocketServer } from 'ws';

// Track if the server has already been initialized
let serverInitialized = false;

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize bot client
  try {
    await botClient.initialize();
  } catch (error) {
    logger.error(`Failed to initialize bot client: ${error}`);
  }
  
  // Basic health check endpoint
  app.get('/api/health', (req: Request, res: Response) => {
    res.status(200).json({ status: 'ok' });
  });
  
  // Get server stats
  app.get('/api/stats/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const stats = await storage.getGuildStats(guildId);
      
      if (!stats) {
        return res.status(404).json({ error: 'Guild stats not found' });
      }
      
      res.status(200).json(stats);
    } catch (error) {
      res.status(500).json({ error: `Failed to get guild stats: ${error}` });
    }
  });
  
  // Get all stats (for dev only, would be removed in production)
  app.get('/api/stats', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const stats = await storage.getGuildStats(guildId) || {
        guildId,
        memberCount: 250,
        roleCount: 15,
        commandsUsedToday: 145,
        autoAssignments: 42
      };
      
      res.status(200).json(stats);
    } catch (error) {
      res.status(500).json({ error: `Failed to get guild stats: ${error}` });
    }
  });
  
  // Get role patterns
  app.get('/api/role-patterns/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const patterns = await storage.getRolePatterns(guildId);
      
      res.status(200).json(patterns);
    } catch (error) {
      res.status(500).json({ error: `Failed to get role patterns: ${error}` });
    }
  });
  
  // Get all role patterns (for dev only, would be removed in production)
  app.get('/api/role-patterns', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const patterns = await storage.getRolePatterns(guildId);
      
      res.status(200).json(patterns);
    } catch (error) {
      res.status(500).json({ error: `Failed to get role patterns: ${error}` });
    }
  });
  
  // Create role pattern
  app.post('/api/role-patterns', async (req: Request, res: Response) => {
    try {
      const patternData = insertRolePatternSchema.parse(req.body);
      const pattern = await storage.createRolePattern(patternData);
      
      res.status(201).json(pattern);
    } catch (error) {
      res.status(400).json({ error: `Invalid role pattern data: ${error}` });
    }
  });
  
  // Update role pattern
  app.put('/api/role-patterns/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const patternData = req.body;
      
      const pattern = await storage.updateRolePattern(Number(id), patternData);
      
      if (!pattern) {
        return res.status(404).json({ error: 'Role pattern not found' });
      }
      
      res.status(200).json(pattern);
    } catch (error) {
      res.status(400).json({ error: `Invalid role pattern data: ${error}` });
    }
  });
  
  // Delete role pattern
  app.delete('/api/role-patterns/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteRolePattern(Number(id));
      
      if (!success) {
        return res.status(404).json({ error: 'Role pattern not found' });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: `Failed to delete role pattern: ${error}` });
    }
  });
  
  // Get channel permissions
  app.get('/api/channel-permissions/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const permissions = await storage.getChannelPermissions(guildId);
      
      res.status(200).json(permissions);
    } catch (error) {
      res.status(500).json({ error: `Failed to get channel permissions: ${error}` });
    }
  });
  
  // Get all channel permissions (for dev only, would be removed in production)
  app.get('/api/channel-permissions', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const permissions = await storage.getChannelPermissions(guildId);
      
      res.status(200).json(permissions);
    } catch (error) {
      res.status(500).json({ error: `Failed to get channel permissions: ${error}` });
    }
  });
  
  // Create channel permission
  app.post('/api/channel-permissions', async (req: Request, res: Response) => {
    try {
      const permissionData = insertChannelPermissionSchema.parse(req.body);
      const permission = await storage.createChannelPermission(permissionData);
      
      res.status(201).json(permission);
    } catch (error) {
      res.status(400).json({ error: `Invalid channel permission data: ${error}` });
    }
  });
  
  // Setup automatic channel permissions
  app.post('/api/setup-channel-permissions/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      
      await botClient.setupChannelPermissions(guildId);
      
      res.status(200).json({ success: true, message: 'Channel permissions setup initiated' });
    } catch (error) {
      res.status(500).json({ error: `Failed to setup channel permissions: ${error}` });
    }
  });
  
  // Configure channel permissions for specific channel
  app.post('/api/configure-channel/:guildId/:channelId', async (req: Request, res: Response) => {
    try {
      const { guildId, channelId } = req.params;
      const { channelName } = req.body;
      
      if (!channelName) {
        return res.status(400).json({ error: 'Channel name is required' });
      }
      
      await botClient.configureChannelPermissions(guildId, channelId, channelName);
      
      res.status(200).json({ success: true, message: 'Channel permissions configured' });
    } catch (error) {
      res.status(500).json({ error: `Failed to configure channel permissions: ${error}` });
    }
  });
  
  // Get bot logs
  app.get('/api/logs/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      
      const logs = await storage.getBotLogs(guildId, limit);
      
      res.status(200).json(logs);
    } catch (error) {
      res.status(500).json({ error: `Failed to get bot logs: ${error}` });
    }
  });
  
  // Get all logs (for dev only, would be removed in production)
  app.get('/api/logs', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const logs = await storage.getBotLogs(guildId, 100);
      
      res.status(200).json(logs);
    } catch (error) {
      res.status(500).json({ error: `Failed to get bot logs: ${error}` });
    }
  });
  
  // Get commands
  app.get('/api/commands/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const commands = await storage.getCommands(guildId);
      
      res.status(200).json(commands);
    } catch (error) {
      res.status(500).json({ error: `Failed to get commands: ${error}` });
    }
  });
  
  // Create command
  app.post('/api/commands', async (req: Request, res: Response) => {
    try {
      const commandData = insertCommandSchema.parse(req.body);
      const command = await storage.createCommand(commandData);
      
      res.status(201).json(command);
    } catch (error) {
      res.status(400).json({ error: `Invalid command data: ${error}` });
    }
  });
  
  // Update command
  app.put('/api/commands/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const commandData = req.body;
      
      const command = await storage.updateCommand(Number(id), commandData);
      
      if (!command) {
        return res.status(404).json({ error: 'Command not found' });
      }
      
      res.status(200).json(command);
    } catch (error) {
      res.status(400).json({ error: `Invalid command data: ${error}` });
    }
  });
  
  // Get bot config
  app.get('/api/bot-config/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const config = await storage.getBotConfig(guildId);
      
      if (!config) {
        return res.status(404).json({ error: 'Bot config not found' });
      }
      
      res.status(200).json(config);
    } catch (error) {
      res.status(500).json({ error: `Failed to get bot config: ${error}` });
    }
  });
  
  // Create bot config
  app.post('/api/bot-config', async (req: Request, res: Response) => {
    try {
      const configData = insertBotConfigSchema.parse(req.body);
      const config = await storage.createBotConfig(configData);
      
      res.status(201).json(config);
    } catch (error) {
      res.status(400).json({ error: `Invalid bot config data: ${error}` });
    }
  });
  
  // Update bot config
  app.put('/api/bot-config/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const configData = req.body;
      
      const config = await storage.updateBotConfig(guildId, configData);
      
      if (!config) {
        return res.status(404).json({ error: 'Bot config not found' });
      }
      
      res.status(200).json(config);
    } catch (error) {
      res.status(400).json({ error: `Invalid bot config data: ${error}` });
    }
  });
  
  // ============== SPARX ROUTES ==============
  
  // Get Sparx accounts for a guild
  app.get('/api/sparx/accounts/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const accounts = await SparxClient.getAccounts(guildId);
      
      res.status(200).json(accounts);
    } catch (error) {
      logger.error(`Failed to retrieve Sparx accounts: ${error}`);
      res.status(500).json({ error: `Failed to retrieve Sparx accounts: ${error}` });
    }
  });
  
  // Get all Sparx accounts for testing
  app.get('/api/sparx/accounts', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const accounts = await SparxClient.getAccounts(guildId);
      
      res.status(200).json(accounts);
    } catch (error) {
      logger.error(`Failed to retrieve Sparx accounts: ${error}`);
      res.status(500).json({ error: `Failed to retrieve Sparx accounts: ${error}` });
    }
  });
  
  // Create a new Sparx account
  app.post('/api/sparx/accounts', async (req: Request, res: Response) => {
    try {
      const accountData = insertSparxAccountSchema.parse(req.body);
      
      const account = await SparxClient.createAccount(
        accountData.guildId,
        accountData.userId,
        accountData.schoolName,
        accountData.username,
        accountData.password,
        accountData.homeworkType as 'compulsory' | 'xpboost' | undefined
      );
      
      if (!account) {
        return res.status(400).json({ error: 'Failed to create account. It may already exist.' });
      }
      
      res.status(201).json(account);
    } catch (error) {
      logger.error(`Failed to create Sparx account: ${error}`);
      res.status(400).json({ error: `Failed to create Sparx account: ${error}` });
    }
  });
  
  // Get Sparx sessions for a guild
  app.get('/api/sparx/sessions/:guildId', async (req: Request, res: Response) => {
    try {
      const { guildId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      
      const sessions = await SparxClient.getRecentSessions(guildId, limit);
      
      res.status(200).json(sessions);
    } catch (error) {
      logger.error(`Failed to retrieve Sparx sessions: ${error}`);
      res.status(500).json({ error: `Failed to retrieve Sparx sessions: ${error}` });
    }
  });
  
  // Get all Sparx sessions for testing
  app.get('/api/sparx/sessions', async (req: Request, res: Response) => {
    try {
      // Default for testing
      const guildId = "123456789012345678";
      const limit = 10;
      
      const sessions = await SparxClient.getRecentSessions(guildId, limit);
      
      res.status(200).json(sessions);
    } catch (error) {
      logger.error(`Failed to retrieve Sparx sessions: ${error}`);
      res.status(500).json({ error: `Failed to retrieve Sparx sessions: ${error}` });
    }
  });
  
  // Start a Sparx automation session
  app.post('/api/sparx/automation/start', async (req: Request, res: Response) => {
    try {
      const { accountId, guildId, userId, homeworkType, maxQuestions } = req.body;
      
      // Validate required fields with detailed error messages
      if (!accountId) {
        return res.status(400).json({ error: 'Missing required field: accountId' });
      }
      
      if (!guildId) {
        return res.status(400).json({ error: 'Missing required field: guildId' });
      }
      
      if (!userId) {
        return res.status(400).json({ error: 'Missing required field: userId' });
      }
      
      // Convert accountId to number if it's a string
      const parsedAccountId = typeof accountId === 'string' ? parseInt(accountId, 10) : accountId;
      
      // Validate accountId is a valid number
      if (isNaN(parsedAccountId)) {
        return res.status(400).json({ error: 'Invalid accountId: must be a number' });
      }
      
      // Verify account exists in database
      const account = await SparxClient.getAccountById(parsedAccountId);
      if (!account) {
        return res.status(404).json({ error: `Account with ID ${parsedAccountId} not found` });
      }
      
      // Log the request parameters for debugging
      logger.info(`Starting automation with parameters: accountId=${parsedAccountId}, guildId=${guildId}, userId=${userId}, homeworkType=${homeworkType || 'compulsory'}`);
      
      // Initialize Sparx client
      const sparxClient = getSparxClient();
      await sparxClient.initialize();
      
      // Start the automation in the background
      sparxClient.runAutomation(
        parsedAccountId,
        guildId,
        userId,
        homeworkType || 'compulsory',
        maxQuestions || 0,
        async (progress) => {
          try {
            // Send progress updates via WebSocket
            logger.info(`Automation progress: ${progress.message}`);
            
            // Broadcast progress message to all connected clients
            if ((global as any).wsBroadcast) {
              (global as any).wsBroadcast({
                type: 'automation-progress',
                message: progress.message,
                screenshot: progress.screenshot,
                important: progress.message.includes('completed') || progress.message.includes('error'),
                guildId,
                userId,
                accountId: parsedAccountId
              });
            }
            
            return Promise.resolve();
          } catch (progressError) {
            logger.error(`Error sending progress update: ${progressError}`);
            return Promise.resolve(); // Don't throw error to keep automation running
          }
        }
      ).then((result) => {
        logger.info(`Automation completed: ${result.success ? 'Success' : 'Failed'}, ${result.questionsAnswered} questions answered`);
        
        // Send completion message via WebSocket
        if ((global as any).wsBroadcast) {
          (global as any).wsBroadcast({
            type: 'automation-completed',
            success: result.success,
            questionsAnswered: result.questionsAnswered,
            message: `Automation ${result.success ? 'completed successfully' : 'failed'}`,
            guildId,
            userId,
            accountId: parsedAccountId
          });
        }
      }).catch((error) => {
        logger.error(`Automation error: ${error}`);
        
        // Send error message via WebSocket
        if ((global as any).wsBroadcast) {
          (global as any).wsBroadcast({
            type: 'automation-error',
            message: `Automation error: ${error}`,
            guildId,
            userId,
            accountId: parsedAccountId
          });
        }
      });
      
      // Return success immediately - the automation runs in the background
      res.status(200).json({ 
        success: true, 
        message: 'Automation started. Check sessions endpoint for progress.',
        details: {
          accountId: parsedAccountId,
          guildId,
          userId,
          homeworkType: homeworkType || 'compulsory'
        }
      });
    } catch (error) {
      logger.error(`Failed to start automation: ${error}`);
      res.status(500).json({ error: `Failed to start automation: ${error}` });
    }
  });
  
  // WebSocket setup for real-time updates
  const setupWebSocket = (server: Server) => {
    try {
      // Import WebSocket from ws package - we need both WebSocketServer and WebSocket
      const WebSocket = require('ws').WebSocket;
      
      // Create WebSocket server with explicit path
      const wss = new WebSocketServer({ 
        server, 
        path: '/ws',
        clientTracking: true 
      });
      
      // Store active connections
      const clients = new Set<any>();
      
      // Handle new connections
      wss.on('connection', (ws) => {
        // Add to active connections
        clients.add(ws);
        logger.info('WebSocket client connected');
        
        ws.on('message', (message) => {
          try {
            const data = JSON.parse(message.toString());
            logger.info(`Received message: ${JSON.stringify(data)}`);
            
            // Handle different message types
            if (data.type === 'subscribe') {
              // Subscribe to specific updates
              ws.send(JSON.stringify({ type: 'subscribed', channel: data.channel }));
            }
          } catch (error) {
            logger.error(`WebSocket error processing message: ${error}`);
          }
        });
        
        ws.on('error', (error) => {
          logger.error(`WebSocket client error: ${error}`);
          // Try to close the connection if possible
          try {
            ws.close();
          } catch (e) {
            // Ignore errors when closing an already problematic connection
          }
        });
        
        ws.on('close', () => {
          // Remove from active connections
          clients.delete(ws);
          logger.info('WebSocket client disconnected');
        });
        
        // Send a welcome message
        try {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ 
              type: 'info', 
              message: 'Connected to SparxCore WebSocket server' 
            }));
          }
        } catch (error) {
          logger.error(`Failed to send welcome message: ${error}`);
        }
      });
      
      // Handle server-level errors
      wss.on('error', (error) => {
        logger.error(`WebSocket server error: ${error}`);
      });
      
      // Helper function to broadcast messages to all connected clients
      const broadcastMessage = (message: any) => {
        clients.forEach(client => {
          try {
            // Check if client is open before sending
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(message));
            }
          } catch (error) {
            logger.error(`Failed to broadcast to client: ${error}`);
          }
        });
      };
      
      // Make broadcast function available globally
      (global as any).wsBroadcast = broadcastMessage;
      
      logger.info('WebSocket server initialized at /ws path');
      return wss;
    } catch (error) {
      logger.error(`Failed to setup WebSocket server: ${error}`);
      // Return null if WebSocket setup fails to avoid crashes
      return null;
    }
  };
  
  // Only start the server if it hasn't been started already
  if (!serverInitialized) {
    serverInitialized = true;
    const server = app.listen(5000, () => {
      console.log('API server listening on port 5000');
    });
    
    // Set up WebSocket server
    setupWebSocket(server);
    
    return server;
  } else {
    return null as unknown as Server; // This will never be used in the running code
  }
}
